if (global.jacare_morreu)
{
    instance_destroy();
    exit;
}

velv = 8;
fugindo = true;
morte = false;
animacao_morte = false;
jacare_vulneravel = false;
if (!variable_global_exists("etapa_jacare"))
{
    global.etapa_jacare = 5;
}

if (!variable_global_exists("jacare_morreu"))
{
    global.jacare_morreu = false;
}