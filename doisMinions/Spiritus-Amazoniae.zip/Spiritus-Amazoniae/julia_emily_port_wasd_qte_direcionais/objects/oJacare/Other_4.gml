if (global.jacare_morreu)
{
    instance_destroy();
    exit;
}

if (room == cont17 && global.etapa_jacare >= 18)
{
    instance_destroy();
}

if (room == cont18 && global.etapa_jacare >= 19)
{
    instance_destroy();
}


