if (morte)
{
    global.jacare_morreu = true;

    audio_stop_sound(sndCapivaraCorrendo);

    if (!animacao_morte)
    {
        animacao_morte = true;

        sprite_index = sJacareMorre;
        image_index = 0;
        image_speed = 0.15;
    audio_play_sound(sndCapivaraMorre, 10, false);
    }

    if (image_index >= image_number - 1)
    {
        image_index = image_number - 1;
        image_speed = 0;
    }

    exit;
}


if (global.etapa_jacare < 19)
{
    x += velv;

    sprite_index = sJacareCorrendo;

    if (!audio_is_playing(sndCapivaraCorrendo))
    {
        audio_play_sound(sndCapivaraCorrendo, 5, true);
    }
}


if (global.etapa_jacare >= 19)
{
    if (audio_is_playing(sndCapivaraCorrendo))
    {
        audio_stop_sound(sndCapivaraCorrendo);
    }
}


if (room == cont17 && x >= room_width - 20)
{
    global.etapa_jacare = 18;
}


if (room == cont18 && x >= room_width - 20)
{
    global.etapa_jacare = 19;
}