corra = false;

tempo_pisca = 0;
pisca = false;

fase = 1;

botoes_total = 5;
botoes_acertados = 0;

tempo = 3600;

tiro_confirmado = false;
botao = irandom(3);

resultado = 0;

vezes_x = 0;
vezes_bolinha = 0;
vezes_quadrado = 0;
vezes_triangulo = 0;

esperando_tiro = false;
tempo_tiro = 900;

vida_curupira = 5;

curupira_fugindo = false;
