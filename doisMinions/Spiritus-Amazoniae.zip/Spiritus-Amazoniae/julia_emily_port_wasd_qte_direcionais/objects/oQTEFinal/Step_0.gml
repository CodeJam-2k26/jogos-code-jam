

if (corra)
{
    tempo_pisca += 1;

    if (tempo_pisca >= 8)
    {
        tempo_pisca = 0;
        pisca = !pisca;
    }

    // Quando chegar na room da cutscene
    if (room == cont32)
    {
        instance_destroy();
        exit;
    }

    exit;
}


// ========================================
// SE O CAÇADOR ESTÁ MORRENDO
// ========================================

if (oCacador.morrendo)
{
    exit;
}


// ========================================
// FASE DE TIRO
// ========================================

if (esperando_tiro)
{
    tempo_tiro -= 1;

    // ====================================
    // PROJÉTIL ACERTOU
    // ====================================

    if (tiro_confirmado)
    {
        tiro_confirmado = false;
        esperando_tiro = false;
        tempo_tiro = 0;

        // -------------------------------
        // PRIMEIRA RODADA
        // -------------------------------

        if (fase == 1)
        {
            vida_curupira = 4;

            fase = 2;

            botoes_total = 4;
            botoes_acertados = 0;

            tempo = 3600;

            vezes_x = 0;
            vezes_bolinha = 0;
            vezes_quadrado = 0;
            vezes_triangulo = 0;

            botao = irandom(3);
        }

        // -------------------------------
        // SEGUNDA RODADA
        // -------------------------------

        else if (fase == 2)
        {
            vida_curupira = 3;

            fase = 3;

            botoes_total = 3;
            botoes_acertados = 0;

            tempo = 2700;

            vezes_x = 0;
            vezes_bolinha = 0;
            vezes_quadrado = 0;
            vezes_triangulo = 0;

            botao = irandom(3);
        }

        // -------------------------------
        // TERCEIRA RODADA
        // -------------------------------

        else if (fase == 3)
        {
            // QTE FINAL TERMINOU
            vida_curupira = 0;

            resultado = 2;

            // PARA O QTE
            esperando_tiro = false;
            tiro_confirmado = false;

            // COMEÇA A FUGA
            corra = true;

            tempo_pisca = 0;
            pisca = false;

            // O CURUPIRA JÁ TERMINOU
            global.curupira_fugiu = true;

            exit;
        }
    }


    // ====================================
    // TEMPO PARA ATIRAR ACABOU
    // ====================================

    if (tempo_tiro <= 0)
    {
		
		global.room_morte = room;
        esperando_tiro = false;
        tiro_confirmado = false;

        botoes_acertados = 0;

        if (fase == 1)
        {
            botoes_total = 5;
            tempo = 60;
        }
        else if (fase == 2)
        {
            botoes_total = 4;
            tempo = 45;
        }
        else
        {
            botoes_total = 3;
            tempo = 30;
        }

        vezes_x = 0;
        vezes_bolinha = 0;
        vezes_quadrado = 0;
        vezes_triangulo = 0;

        botao = irandom(3);
    }

    exit;
}


// ========================================
// TEMPO DO QTE
// ========================================

tempo -= 1;


// ========================================
// BOTÃO APERTADO
// ========================================

var apertou = -1;

if ((gamepad_button_check_pressed(4, gp_face1) || keyboard_check_pressed(vk_up)))
{
    apertou = 0;
}
else if ((gamepad_button_check_pressed(4, gp_face2) || keyboard_check_pressed(vk_down)))
{
    apertou = 1;
}
else if ((gamepad_button_check_pressed(4, gp_face3) || keyboard_check_pressed(vk_left)))
{
    apertou = 2;
}
else if ((gamepad_button_check_pressed(4, gp_face4) || keyboard_check_pressed(vk_right)))
{
    apertou = 3;
}


// ========================================
// APERTOU ALGUM BOTÃO
// ========================================
// BOTÃO FOI APERTADO
// ========================================

if (apertou != -1)
{
    // ====================================
    // ACERTOU
    // ====================================

    if (apertou == botao)
    {
        botoes_acertados += 1;

        // =================================
        // AINDA NÃO TERMINOU OS BOTÕES
        // =================================

        if (botoes_acertados < botoes_total)
        {
            botao = irandom(3);

            if (fase == 1)
            {
                tempo = 3600;
            }
            else if (fase == 2)
            {
                tempo = 2700;
            }
            else
            {
                tempo = 1800;
            }
        }

        // =================================
        // TERMINOU A RODADA
        // =================================

        else
        {
            esperando_tiro = true;
            tempo_tiro = 900;
            resultado = 0;
        }
    }

    // ====================================
    // ERROU
    // ====================================

    else
    {
        oCacador.vida -= 1;

        // -------------------------------
        // MORREU
        // -------------------------------

        if (oCacador.vida <= 0)
        {
            global.room_morte = room;

            oCacador.vida = 0;

            oCacador.morrendo = true;
            oCacador.tomando_dano = false;

            oCacador.morte_frame = 0;
            oCacador.morte_timer = 0;
            oCacador.morte_terminou = false;

            instance_destroy();

            exit;
        }

        // -------------------------------
        // PERDEU UMA VIDA
        // -------------------------------

        oCacador.tomando_dano = true;
        oCacador.image_index = 0;

        botoes_acertados = 0;

        if (fase == 1)
        {
            botoes_total = 5;
            tempo = 3600;
        }
        else if (fase == 2)
        {
            botoes_total = 4;
            tempo = 2700;
        }
        else
        {
            botoes_total = 3;
            tempo = 1800;
        }

        vezes_x = 0;
        vezes_bolinha = 0;
        vezes_quadrado = 0;
        vezes_triangulo = 0;

        botao = irandom(3);
    }
}

// ========================================
// TEMPO DO QTE ACABOU
// ========================================

if (tempo <= 0)
{
    oCacador.vida -= 1;

    // ====================================
    // MORREU
    // ====================================

    if (oCacador.vida <= 0)
    {
        oCacador.vida = 0;

        oCacador.morrendo = true;
        oCacador.tomando_dano = false;

        oCacador.morte_frame = 0;
        oCacador.morte_timer = 0;
        oCacador.morte_terminou = false;

        instance_destroy();

        exit;
    }

    // ====================================
    // PERDEU UMA VIDA
    // ====================================

    oCacador.tomando_dano = true;
    oCacador.image_index = 0;

    botoes_acertados = 0;

    if (fase == 1)
    {
        botoes_total = 5;
        tempo = 60;
    }
    else if (fase == 2)
    {
        botoes_total = 4;
        tempo = 45;
    }
    else
    {
        botoes_total = 3;
        tempo = 30;
    }

    vezes_x = 0;
    vezes_bolinha = 0;
    vezes_quadrado = 0;
    vezes_triangulo = 0;

    botao = irandom(3);
}