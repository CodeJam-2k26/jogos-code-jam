

// ========================================
// SE O CAÇADOR ESTÁ MORRENDO
// ========================================

if (oCacador.morrendo)
{
    exit;
}


// ========================================
// VIDA DO CURUPIRA
// ========================================

for (var i = 0; i < vida_curupira; i++)
{
    draw_sprite_ext(
        sVida,
        0,
        750 + (i * 50),
        50,
        1,
        1,
        0,
        c_white,
        1
    );
}


// ========================================
// FASE DE TIRO
// ========================================

if (esperando_tiro)
{
    draw_set_color(c_white);

    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);

    draw_text(
        display_get_gui_width() / 2,
        200,
        "ATIRE!"
    );

    draw_set_halign(fa_left);
    draw_set_valign(fa_top);

    exit;
}


// ========================================
// QTE
// ========================================

draw_set_color(c_white);

if (resultado == 0)
{
    // Ícone de QTE para teclado: tecla correspondente ao comando.
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_set_color(c_black);
    draw_rectangle((300) - 28, (200) - 28, (300) + 28, (200) + 28, false);
    draw_set_color(c_white);
    draw_rectangle((300) - 28, (200) - 28, (300) + 28, (200) + 28, true);
    // Desenha a seta com primitivas gráficas para não depender da fonte Unicode.
    var seta_x = 300;
    var seta_y = 200;
    draw_set_color(c_white);
    if (botao == 0) // CIMA
    {
        draw_line_width(seta_x, seta_y + 10, seta_x, seta_y - 5, 5);
        draw_triangle(seta_x, seta_y - 18, seta_x - 10, seta_y - 4, seta_x + 10, seta_y - 4, false);
    }
    else if (botao == 1) // BAIXO
    {
        draw_line_width(seta_x, seta_y - 10, seta_x, seta_y + 5, 5);
        draw_triangle(seta_x, seta_y + 18, seta_x - 10, seta_y + 4, seta_x + 10, seta_y + 4, false);
    }
    else if (botao == 2) // ESQUERDA
    {
        draw_line_width(seta_x + 10, seta_y, seta_x - 5, seta_y, 5);
        draw_triangle(seta_x - 18, seta_y, seta_x - 4, seta_y - 10, seta_x - 4, seta_y + 10, false);
    }
    else // DIREITA
    {
        draw_line_width(seta_x - 10, seta_y, seta_x + 5, seta_y, 5);
        draw_triangle(seta_x + 18, seta_y, seta_x + 4, seta_y - 10, seta_x + 4, seta_y + 10, false);
    }
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
}

// ========================================
// RESULTADO
// ========================================

if (resultado == 1)
{
    draw_text(300, 200, "ACERTOU!");
}

if (resultado == -1)
{
    draw_text(300, 200, "ERROU!");
}
draw_set_alpha(1);
draw_set_color(c_white);
draw_set_halign(fa_left);
draw_set_valign(fa_top);


if (corra)
{
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);

    draw_set_color(c_white);

    draw_text(
        display_get_gui_width() / 2,
        display_get_gui_height() / 2,
        "CORRA!"
    );

    if (pisca)
    {
        draw_set_alpha(0.5);
        draw_set_color(c_white);

        draw_rectangle(
            0,
            0,
            display_get_gui_width(),
            display_get_gui_height(),
            false
        );

        draw_set_alpha(1);
    }

    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
}
if (oCacador.morrendo)
{
    exit;
}


// ========================================
// VIDA DO CURUPIRA
// ========================================

for (var i = 0; i < vida_curupira; i++)
{
    draw_sprite_ext(
        sVida,
        0,
        750 + (i * 50),
        50,
        1,
        1,
        0,
        c_white,
        1
    );
}


// ========================================
// FASE DE TIRO
// ========================================

if (esperando_tiro)
{
    draw_set_color(c_white);

    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);

    draw_text(
        display_get_gui_width() / 2,
        200,
        "ATIRE!"
    );

    draw_set_halign(fa_left);
    draw_set_valign(fa_top);

    exit;
}


// ========================================
// QTE
// ========================================

draw_set_color(c_white);

if (resultado == 0)
{
    // Ícone de QTE para teclado: tecla correspondente ao comando.
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_set_color(c_black);
    draw_rectangle((300) - 28, (200) - 28, (300) + 28, (200) + 28, false);
    draw_set_color(c_white);
    draw_rectangle((300) - 28, (200) - 28, (300) + 28, (200) + 28, true);
    // Desenha a seta com primitivas gráficas para não depender da fonte Unicode.
    var seta_x = 300;
    var seta_y = 200;
    draw_set_color(c_white);
    if (botao == 0) // CIMA
    {
        draw_line_width(seta_x, seta_y + 10, seta_x, seta_y - 5, 5);
        draw_triangle(seta_x, seta_y - 18, seta_x - 10, seta_y - 4, seta_x + 10, seta_y - 4, false);
    }
    else if (botao == 1) // BAIXO
    {
        draw_line_width(seta_x, seta_y - 10, seta_x, seta_y + 5, 5);
        draw_triangle(seta_x, seta_y + 18, seta_x - 10, seta_y + 4, seta_x + 10, seta_y + 4, false);
    }
    else if (botao == 2) // ESQUERDA
    {
        draw_line_width(seta_x + 10, seta_y, seta_x - 5, seta_y, 5);
        draw_triangle(seta_x - 18, seta_y, seta_x - 4, seta_y - 10, seta_x - 4, seta_y + 10, false);
    }
    else // DIREITA
    {
        draw_line_width(seta_x - 10, seta_y, seta_x + 5, seta_y, 5);
        draw_triangle(seta_x + 18, seta_y, seta_x + 4, seta_y - 10, seta_x + 4, seta_y + 10, false);
    }
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
}

// ========================================
// RESULTADO
// ========================================

if (resultado == 1)
{
    draw_text(300, 200, "ACERTOU!");
}

if (resultado == -1)
{
    draw_text(300, 200, "ERROU!");
}
draw_set_alpha(1);
draw_set_color(c_white);
draw_set_halign(fa_left);
draw_set_valign(fa_top);


if (corra)
{
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);

    draw_set_color(c_white);

    draw_text(
        display_get_gui_width() / 2,
        display_get_gui_height() / 2,
        "CORRA!"
    );

    if (pisca)
    {
        draw_set_alpha(0.5);
        draw_set_color(c_white);

        draw_rectangle(
            0,
            0,
            display_get_gui_width(),
            display_get_gui_height(),
            false
        );

        draw_set_alpha(1);
    }

    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
}