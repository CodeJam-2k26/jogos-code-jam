if (qte_ativo)
{

    // Ícone de QTE para teclado: tecla correspondente ao comando.
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_set_color(c_black);
    draw_rectangle((683) - 28, (300) - 28, (683) + 28, (300) + 28, false);
    draw_set_color(c_white);
    draw_rectangle((683) - 28, (300) - 28, (683) + 28, (300) + 28, true);
    // Desenha a seta com primitivas gráficas para não depender da fonte Unicode.
    var seta_x = 683;
    var seta_y = 300;
    draw_set_color(c_white);
    if (botao_atual == 0) // CIMA
    {
        draw_line_width(seta_x, seta_y + 10, seta_x, seta_y - 5, 5);
        draw_triangle(seta_x, seta_y - 18, seta_x - 10, seta_y - 4, seta_x + 10, seta_y - 4, false);
    }
    else if (botao_atual == 1) // BAIXO
    {
        draw_line_width(seta_x, seta_y - 10, seta_x, seta_y + 5, 5);
        draw_triangle(seta_x, seta_y + 18, seta_x - 10, seta_y + 4, seta_x + 10, seta_y + 4, false);
    }
    else if (botao_atual == 2) // ESQUERDA
    {
        draw_line_width(seta_x + 10, seta_y, seta_x - 5, seta_y, 5);
        draw_triangle(seta_x - 18, seta_y, seta_x - 4, seta_y - 10, seta_x - 4, seta_y + 10, false);
    }
    else // DIREITA
    {
        draw_line_width(seta_x - 10, seta_y, seta_x + 5, seta_y, 5);
        draw_triangle(seta_x + 18, seta_y, seta_x + 4, seta_y - 10, seta_x + 4, seta_y + 10, false);
    }
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
}