direcao_linhas = 1;

ativa = false;
tempo = 0;

// intensidade da tremida da tela
intensidade = 8;
velocidade_efeito = 0.25;

//começa o efeito
iniciar = function()
{
    ativa = true;
    tempo = 0;
};