if (ativa)
{
    var w = display_get_gui_width();
    var h = display_get_gui_height();

    // ========================================
    // BARRAS CINEMATOGRÁFICAS
    // ========================================

    draw_set_color(c_black);

    draw_rectangle(
        0,
        0,
        w,
        h * 0.12,
        false
    );

    draw_rectangle(
        0,
        h * 0.88,
        w,
        h,
        false
    );


    //// ========================================
// LINHAS HORIZONTAIS DE VELOCIDADE
// ========================================

var quantidade_linhas = 30;

draw_set_color(c_white);

for (var i = 0; i < quantidade_linhas; i++)
{
    // Movimento horizontal
var x_linha = ((i * 113 + tempo * 20 * direcao_linhas) mod (w + 300)) - 300;
    // Posição vertical
    var y_linha = h * 0.15 + ((i * 53) mod (h * 0.70));

    // Tamanho da linha
    var tamanho = 40 + ((i * 29) mod 90);

    draw_set_alpha(0.15);

    draw_rectangle(
        x_linha,
        y_linha,
        x_linha + tamanho,
        y_linha + 2,
        false
    );
}



    // ========================================
    // RESTAURAR
    // ========================================

    draw_set_alpha(1);
    draw_set_color(c_white);
}