if (ativa)
{
    tempo++;

    if (oCacador.image_xscale > 0)
    {
        direcao_linhas = 1;
    }
    else
    {
        direcao_linhas = -1;
    }
}
else
{
    tempo = 0;
}