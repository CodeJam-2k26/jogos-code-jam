vida = 5;
persistent=true;
tomando_dano = false;
morrendo = false;
tempo_dano = 0;
sprite_normal = sprite_index;
velh = 0;
vel = 5;
direcao_spawn = 0;
modo_controle = global.modo_controle;
escala_original = abs(image_xscale);
image_xscale = escala_original * 4;
image_yscale = 4;
inventario_aberto = false;
item_selecionado = 0;
municao = 0;
ervas = 0;
comida = 0;

preso_armadilha = false;
tempo_preso = 0;

sprite_index = sCacadorResp;
image_speed = 0.1;
vel_corrida = 8;
correndo = false;
estamina = 100;
estamina_max = 100;
tempo_estamina = 0;
//tiro
balas = 5;
balas_max = 5;
atirando = false;
tiro_feito = false;
//mensagem
mensagem_municao = "";
tempo_mensagem = 0;

//mortre
morte_frame = 0;
morte_timer = 0;
morte_terminou = false;

//capivara
evento_capivara = false;
etapa_evento_capivara = 0;
tempo_evento_capivara = 0;
rugido_tocado = false;
fala_evento = "";
tempo_fala = 0;
mostrar_pista = false;

if (!variable_global_exists("pausado"))
{
    global.pausado = false;
}
if (!variable_global_exists("capivara_morreu"))
{
    global.capivara_morreu = false;
}

if (!variable_global_exists("onca_morreu"))
{
    global.onca_morreu = false;
}

if (!variable_global_exists("jacare_morreu"))
{
    global.jacare_morreu = false;
}

if (!variable_global_exists("jacare_morreu"))
{
    global.iara_morreu = false;
}



if (variable_global_exists("carregando_partida"))
{
    if (global.carregando_partida)
    {
        x = global.x_salvo;
        y = global.y_salvo;

        global.carregando_partida = false;
    }
}


global.mensagem_pista = "";
global.mensagem_timer = 0;

if (variable_global_exists("carregando_partida"))
{
    if (global.carregando_partida)
    {
        municao = global.municao_salva;
        ervas = global.ervas_salvas;
        comida = global.comida_salva;

        global.carregando_partida = false;


    }
}

