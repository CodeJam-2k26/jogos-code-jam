if(room == inicio && global.capivara_morreu)
{
room_goto(inicioCapivara);
    x = 767;
    y = 462;
    direcao_spawn = 0;
exit;

}

if(room == inicioCapivara && global.onca_morreu)
{
room_goto(inicioOnca);
    x = 767;
    y = 462;
    direcao_spawn = 0;
exit;

}

if (variable_global_exists("carregando_partida"))
{
    if (global.carregando_partida)
    {
        x = global.x_salvo;
        y = global.y_salvo;

        global.carregando_partida = false;

        exit;
    }
}

if (room == cont2 && direcao_spawn == 1)
{
    x = 68.19;
    y = 550.43;
    direcao_spawn = 0;
}

if (room == comeco && direcao_spawn == -1)
{
    x = 984.82;
    y = 551.78;
    direcao_spawn = 0;
}

if (room == comeco && direcao_spawn == 1)
{
    x = 323.94;
    y = 547.21;
    direcao_spawn = 0;
}

if (room == inicio && direcao_spawn == -1)
{
    x = 767;
    y = 462;
    direcao_spawn = 0;
}

if (room == inicioCapivara && direcao_spawn == -1)
{
    x = 767;
    y = 462;
    direcao_spawn = 0;
}

if (room == inicioOnca && direcao_spawn == -1)
{
    x = 767;
    y = 462;
    direcao_spawn = 0;
}

if (room == inicioJacare && direcao_spawn == -1)
{
    x = 767;
    y = 462;
    direcao_spawn = 0;
}
if (room == cont2 && direcao_spawn == -1)
{
    x = 941.12;
    y = 550.43;
    direcao_spawn = 0;
}

if (room == cont3 && direcao_spawn == 1)
{
    x = 74.21;
    y = 550.43;
    direcao_spawn = 0;
}

if (room ==cont4 && direcao_spawn == 1)
{ 
	x =54.63;
	y = 550.43;
	direcao_spawn = 0;
}

if (room == cont3 && direcao_spawn == -1)
{
    x = 965.05;
    y = 550.43;
    direcao_spawn = 0;
}

if (room == cont4 && direcao_spawn ==-1)
{
	x = 900.09;
	y= 550.43;
	direcao_spawn = 0;
}

if(room == cont5 && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont5 && direcao_spawn==-1)
{
	x =900;
	y = 550.43;
    direcao_spawn = 0;
}


if(room == cont6 && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont6 && direcao_spawn==-1)
{
	x =900;
	y = 550.43;
    direcao_spawn = 0;
}
if(room == cont7 && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont7 && direcao_spawn==-1)
{
	x =900;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont8 && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont8 && direcao_spawn==-1)
{
	x =900;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont9 && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont9 && direcao_spawn==-1)
{
	x =900;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont10 && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont10 && direcao_spawn==-1)
{
	x =900;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont11 && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont11 && direcao_spawn==-1)
{
	x =900;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont12 && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont12 && direcao_spawn==-1)
{
	x =900;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont13 && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont13 && direcao_spawn==-1)
{
	x =900;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont14 && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont14 && direcao_spawn==-1)
{
	x =900;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont15 && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont15 && direcao_spawn==-1)
{
	x =900;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont16 && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont16 && direcao_spawn==-1)
{
	x =900;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont17 && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont17 && direcao_spawn==-1)
{
	x =900;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont18 && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont18 && direcao_spawn==-1)
{
	x =900;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont19 && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont19 && direcao_spawn==-1)
{
	x =900;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont20 && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont20 && direcao_spawn==-1)
{
	x =900;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == contAcampamento && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == contAcampamento && direcao_spawn==-1)
{
	x =900;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont21 && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont21 && direcao_spawn==-1)
{
	x =900;
	y = 550.43;
    direcao_spawn = 0;
}


 //Teste do curupira quicktime event
if(room == contCurupira && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == contCurupira && direcao_spawn==-1)
{
	x =900;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont22 && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont22 && direcao_spawn==-1)
{
	x =900;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont23 && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont23 && direcao_spawn==-1)
{
	x =900;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont24 && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont24 && direcao_spawn==-1)
{
	x =900;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont25 && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont25 && direcao_spawn==-1)
{
	x =900;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == contIara && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == contIara && direcao_spawn==-1)
{
	x =500;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == contPosIara && direcao_spawn==1)
{
	x =570;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == contPosIara && direcao_spawn==-1)
{
	x =860;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont26 && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont26 && direcao_spawn==-1)
{
	x =900;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont27 && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont27 && direcao_spawn==-1)
{
	x =900;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont28 && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont28 && direcao_spawn==-1)
{
	x =900;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont29 && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont29 && direcao_spawn==-1)
{
	x =900;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont30 && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont30 && direcao_spawn==-1)
{
	x =900;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont29 && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont31 && direcao_spawn==-1)
{
	x =900;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont31 && direcao_spawn==1)
{
	x =70;
	y = 550.43;
    direcao_spawn = 0;
}

if(room == cont32 && direcao_spawn==-1)
{
	x =900;
	y = 550.43;
    direcao_spawn = 0;
}

// =========================
// POSIÇÃO INICIAL DO JOGO
// =========================

if (room == inicio && direcao_spawn == 0)
{
    x = 767;
    y = 462;
}