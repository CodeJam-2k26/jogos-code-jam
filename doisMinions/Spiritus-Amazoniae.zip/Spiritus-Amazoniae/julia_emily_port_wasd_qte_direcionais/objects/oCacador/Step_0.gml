
// ========================================
// ESCONDER O CAÇADOR NOS MENUS
// ========================================

if (room == menu || room == escolha)
{
    visible = false;
}
else
{
    visible = true;
}
// INVENTÁRIO
if ((gamepad_button_check_pressed(4, gp_shoulderr) || keyboard_check_pressed(vk_tab)))
{
    inventario_aberto = !inventario_aberto;
}


// ========================================
// CONTROLES DO INVENTÁRIO
// ========================================

if (inventario_aberto)
{
    // CIMA
    if ((gamepad_button_check_pressed(4, gp_padu) || keyboard_check_pressed(vk_up) || keyboard_check_pressed(ord("W"))))
    {
        item_selecionado -= 1;
    }

    // BAIXO
    if ((gamepad_button_check_pressed(4, gp_padd) || keyboard_check_pressed(vk_down) || keyboard_check_pressed(ord("S"))))
    {
        item_selecionado += 1;
    }


    // IMPEDIR PASSAR DOS ITENS
    if (item_selecionado < 0)
    {
        item_selecionado = 2;
    }

    if (item_selecionado > 2)
    {
        item_selecionado = 0;
    }


    // ========================================
    // USAR ITEM - X
    // ========================================

    if ((gamepad_button_check_pressed(4, gp_face1) || keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space) || keyboard_check_pressed(ord("E"))))
    {
        // MUNIÇÃO
        if (item_selecionado == 0)
        {
            if (municao > 0 && balas < 5)
            {
                var espaco = 5 - balas;

                if (municao >= espaco)
                {
                    municao -= espaco;
                    balas = 5;
                }
                else
                {
                    balas += municao;
                    municao = 0;
                }
            }
        }


        // ERVA
        else if (item_selecionado == 1)
        {
            if (ervas > 0 && vida < 5)
            {
                vida += 1;
                ervas -= 1;
            }
        }


        // COMIDA
        else if (item_selecionado == 2)
        {
            if (comida > 0 && estamina < 100)
            {
                estamina += 25;

                if (estamina > 100)
                {
                    estamina = 100;
                }

                comida -= 1;
            }
        }
    }
}
// ========================================
// RESTAURA POSIÇÃO DA PARTIDA CARREGADA
// ========================================
if (variable_global_exists("carregando_partida")) 
{ 
    if (global.carregando_partida) 
    { 
        x = global.x_salvo; 
        y = global.y_salvo; 

        municao = global.municao_salva;
        ervas = global.ervas_salvas;
        comida = global.comida_salva;

        global.carregando_partida = false; 
    } 
}
// =========================
// MORTE
// =========================

if (morrendo)
{
    // SOM DA MORTE — toca uma única vez
    if (morte_timer == 0 && morte_frame == 0)
    {
        audio_play_sound(sndCacadorMorre, 10, false);
    }

	
    morte_timer += 1;

    // Troca de frame a cada 8 frames
    if (morte_timer >= 8)
    {
        morte_timer = 0;
        morte_frame += 1;
    }

    // Terminou os 8 frames
    if (morte_frame >= 8)
    {
        morte_frame = 7;

        // Cria a tela de morte somente depois
        // da animação terminar
        if (!morte_terminou)
        {
            morte_terminou = true;

            if (!instance_exists(oTelaMorte))
            {
                instance_create_layer(
                    0,
                    0,
                    "Instances",
                    oTelaMorte
                );
            }
        }
    }

    exit;
}
// =========================
// JOGO PAUSADO
// =========================

if (global.pausado)
{
    velh = 0;
    correndo = false;
    exit;
}

// CORRER
if (modo_controle == 0)
{
    correndo = (gamepad_button_check(4, gp_shoulderlb) || keyboard_check(vk_shift));
}
else
{
    correndo = false;
}


// ========================================
// CUTSCENE DE PERSEGUIÇÃO
// ========================================

if (instance_exists(oCutscene))
{
    if (correndo)
    {
        oCutscene.ativa = true;
    }
    else
    {
        oCutscene.ativa = false;
        oCutscene.tempo = 0;
    }
}

//SISTEMA DA ARMADILHA, O CAÇADOR FICA PARADO	
if (preso_armadilha)
{
    tempo_preso -= 1;

    velh = 0;

    if (tempo_preso <= 0)
    {
        tempo_preso = 0;
        preso_armadilha = false;
    }
}


// --- SISTEMA DE MOVIMENTAÇÃO ---

if (modo_controle == 0)
{
    var eixo = gamepad_axis_value(4, 0);
    if (abs(eixo) < 0.2) eixo = keyboard_check(ord("D")) ? 1 : (keyboard_check(ord("A")) ? -1 : 0);

    if (abs(eixo) < 0.2)
    {
        eixo = 0;
    }

// ESTAMINA
if (correndo && eixo != 0 && estamina > 0)
{
    estamina -= 0.5;
}
else if (eixo == 0)
{
    correndo = false;
}


// ACABOU A ESTAMINA
if (estamina <= 0)
{
    estamina = 0;
    correndo = false;
}


// RECUPERAÇÃO DA ESTAMINA
if (!correndo)
{
    tempo_estamina += 1;

    if (tempo_estamina >= 60)
    {
        estamina += 0.5;

        if (estamina > estamina_max)
        {
            estamina = estamina_max;
        }
    }
}
else
{
    tempo_estamina = 0;
}



    // DIREÇÃO
    if (eixo > 0)
    {
        image_xscale = escala_original * 4;
    }
    else if (eixo < 0)
    {
        image_xscale = -escala_original * 4;
    }


    // VELOCIDADE
if (preso_armadilha)
{
    velh = 0;
    correndo = false;
}
else
{
    velh = eixo * (correndo ? vel_corrida : vel);
}
}

// SONS DE MOVIMENTO
if (abs(eixo) > 0.2)
{
    if (correndo)
    {
        if (!audio_is_playing(sndCorrida))
        {
            audio_stop_sound(sndPassos);
            audio_play_sound(sndCorrida, 5, true);
        }
    }
    else
    {
        if (!audio_is_playing(sndPassos))
        {
            audio_stop_sound(sndCorrida);
            audio_play_sound(sndPassos, 5, true);
        }
    }
}
else
{
    audio_stop_sound(sndPassos);
    audio_stop_sound(sndCorrida);
}

    if (!place_meeting(x + velh, y, oParede))
    {
        x += velh;
    }
	
// --- SISTEMA DE TIRO ---

var tiro = (gamepad_button_check_pressed(4, gp_shoulderrb) || keyboard_check_pressed(ord("F")));

if (tiro && !atirando)
{
    if (balas > 0)
    {
        balas -= 1;

        atirando = true;
        tiro_feito = false;

        sprite_index = Sprite35;
        image_index = 0;
        image_speed = 0.2;
    }
}
// Movimento vertical pelo controle somente na inicio
if (room == inicio && modo_controle == 0)
{
    var eixoY = gamepad_axis_value(4, 1);
    if (abs(eixoY) < 0.2) eixoY = keyboard_check(ord("S")) ? 1 : (keyboard_check(ord("W")) ? -1 : 0);

    if (abs(eixoY) < 0.2)
    {
        eixoY = 0;
    }

    var velv = eixoY * vel;
	
	// Som dos passos
if (abs(eixoY) > 0.2 && !audio_is_playing(sndPassos))
{
    audio_play_sound(sndPassos, 5, true);
}
else if (abs(eixoY) <= 0.2 && audio_is_playing(sndPassos))
{
    audio_stop_sound(sndPassos);
}

    if (!place_meeting(x, y + velv, oParede))
    {
        y += velv;
    }
}

// Movimento vertical pelo controle somente na inicioCapivara
if (room == inicioCapivara && modo_controle == 0)
{
    var eixoY = gamepad_axis_value(4, 1);
    if (abs(eixoY) < 0.2) eixoY = keyboard_check(ord("S")) ? 1 : (keyboard_check(ord("W")) ? -1 : 0);

    if (abs(eixoY) < 0.2)
    {
        eixoY = 0;
    }

    var velv = eixoY * vel;

	// Som dos passos
	if (abs(eixoY) > 0.2 && !audio_is_playing(sndPassos))
	{
    audio_play_sound(sndPassos, 5, true);
	}
	else if (abs(eixoY) <= 0.2 && audio_is_playing(sndPassos))
	{
    audio_stop_sound(sndPassos);
	}

    if (!place_meeting(x, y + velv, oParede))
    {
        y += velv;
    }
}

// Movimento vertical pelo controle somente na inicioOnca
if (room == inicioOnca && modo_controle == 0)
{
    var eixoY = gamepad_axis_value(4, 1);
    if (abs(eixoY) < 0.2) eixoY = keyboard_check(ord("S")) ? 1 : (keyboard_check(ord("W")) ? -1 : 0);

    if (abs(eixoY) < 0.2)
    {
        eixoY = 0;
    }

    var velv = eixoY * vel;
	
	// Som dos passos
	if (abs(eixoY) > 0.2 && !audio_is_playing(sndPassos))
	{
    audio_play_sound(sndPassos, 5, true);
	}
	else if (abs(eixoY) <= 0.2 && audio_is_playing(sndPassos))
	{
    audio_stop_sound(sndPassos);
	}

    if (!place_meeting(x, y + velv, oParede))
    {
        y += velv;
    }
}

// Movimento vertical pelo controle somente na inicioJacare
if (room == inicioJacare && modo_controle == 0)
{
    var eixoY = gamepad_axis_value(4, 1);
    if (abs(eixoY) < 0.2) eixoY = keyboard_check(ord("S")) ? 1 : (keyboard_check(ord("W")) ? -1 : 0);

    if (abs(eixoY) < 0.2)
    {
        eixoY = 0;
    }

    var velv = eixoY * vel;

// Som dos passos
	if (abs(eixoY) > 0.2 && !audio_is_playing(sndPassos))
	{
    audio_play_sound(sndPassos, 5, true);
	}
	else if (abs(eixoY) <= 0.2 && audio_is_playing(sndPassos))
	{
    audio_stop_sound(sndPassos);
	}

    if (!place_meeting(x, y + velv, oParede))
    {
        y += velv;
    }
}


// Ir para comeco
if (room == inicio && place_meeting(x, y, oIrComeco))
{
    direcao_spawn = 1;
    room_goto(comeco);
}

// Ir para comeco
if (room == inicioCapivara && place_meeting(x, y, oIrComeco))
{
    direcao_spawn = 1;
    room_goto(comeco);
}

// Voltar para inicio
if (room == comeco && x <= 300)
{
    direcao_spawn = -1;
    room_goto(inicio);
}


// Ir para cont2
if (room == comeco && x >= 984.82)
{
    direcao_spawn = 1;
    room_goto(cont2);
}


// Voltar para comeco
if (room == cont2 && x <= 20)
{
    direcao_spawn = -1;
    room_goto(comeco);
}

// Ir para cont3
if (room == cont2 && x >= 957.67)
{
    direcao_spawn = 1;
    room_goto(cont3);
}

// Voltar para cont2
if (room == cont3 && x <= 47.81)
{
    direcao_spawn = -1;
    room_goto(cont2);
}

//Ir para cont4
if (room == cont3 && x>=965.05)
{
	direcao_spawn = 1;
	room_goto(cont4);
}
	
//Voltar para cont3
if (room ==cont4 && x<=40.96)
{
	direcao_spawn = -1;
	room_goto(cont3);
}
	
//Ir para cont5
if (room == cont4 && x >=968.33)
{
	direcao_spawn = 1;
	room_goto(cont5);
}

//Voltar para cont4
if(room == cont5 && x <= 70.37)
{
	direcao_spawn =-1;
	room_goto(cont4);
}
	

	//Ir para cont6
if (room == cont5 && x >=968.33)
{
	direcao_spawn = 1;
	room_goto(cont6);
}

//Voltar para cont5
if(room == cont6 && x <= 70.37)
{
	direcao_spawn =-1;
	room_goto(cont5);
}

	//Ir para cont7
if (room == cont6 && x >=968.33)
{
	direcao_spawn = 1;
	room_goto(cont7);
}

//Voltar para cont6
if(room == cont7 && x <= 70.37)
{
	direcao_spawn =-1;
	room_goto(cont6);
}

	//Ir para cont8
if (room == cont7 && x >=968.33)
{
	direcao_spawn = 1;
	room_goto(cont8);
}

//Voltar para cont7
if(room == cont8 && x <= 70.37)
{
	direcao_spawn =-1;
	room_goto(cont7);
}

	//Ir para cont9
if (room == cont8 && x >=968.33)
{
	direcao_spawn = 1;
	room_goto(cont9);
}

//Voltar para cont8
if(room == cont9 && x <= 70.37)
{
	direcao_spawn =-1;
	room_goto(cont8);
}	
	
// Ir para cont10
if(room == cont9 && x >= 968.33)
{
	direcao_spawn =1;
	room_goto(cont10);
}

//Voltar para cont9
if(room == cont10 && x <= 70.37)
{
	direcao_spawn =-1;
	room_goto(cont9);
}

// Ir para cont11
if(room == cont10 && x >= 968.33)
{
    if (global.capivara_morreu)
    {
        direcao_spawn = 1;
        room_goto(cont11);
    }
}

//Voltar para cont10
if(room == cont11 && x <= 70.37)
{
	direcao_spawn =-1;
	room_goto(cont10);
}

	//Ir para cont12
if (room == cont11 && x >=968.33)
{
	direcao_spawn = 1;
	room_goto(cont12);
}

//Voltar para cont11
if(room == cont12 && x <= 70.37)
{
	direcao_spawn =-1;
	room_goto(cont11);
}

	//Ir para cont13
if (room == cont12 && x >=968.33)
{
	direcao_spawn = 1;
	room_goto(cont13);
}

//Voltar para cont12
if(room == cont13 && x <= 70.37)
{
	direcao_spawn =-1;
	room_goto(cont12);
}

	//Ir para cont14
if (room == cont13 && x >=968.33)
{
	direcao_spawn = 1;
	room_goto(cont14);
}

//Voltar para cont13
if(room == cont14 && x <= 70.37)
{
	direcao_spawn =-1;
	room_goto(cont13);
}

	//Ir para cont15
if (room == cont14 && x >=968.33)
{
	direcao_spawn = 1;
	room_goto(cont15);
}

//Voltar para cont14
if(room == cont15 && x <= 70.37)
{
	direcao_spawn =-1;
	room_goto(cont14);
}

	//Ir para cont16
if(room == cont15 && x >= 968.33)
{
    if (global.onca_morreu)
    {
        direcao_spawn = 1;
        room_goto(cont16);
    }
}

//Voltar para cont15
if(room == cont16 && x <= 70.37)
{
	direcao_spawn =-1;
	room_goto(cont15);
}

	//Ir para cont17
if (room == cont16 && x >=968.33)
{
	direcao_spawn = 1;
	room_goto(cont17);
}

//Voltar para cont16
if(room == cont17 && x <= 70.37)
{
	direcao_spawn =-1;
	room_goto(cont16);
}

	//Ir para cont18
if (room == cont17 && x >=968.33)
{
	direcao_spawn = 1;
	room_goto(cont18);
}

//Voltar para cont17
if(room == cont18 && x <= 70.37)
{
	direcao_spawn =-1;
	room_goto(cont17);
}

	//Ir para cont19
if (room == cont18 && x >=968.33)
{
	direcao_spawn = 1;
	room_goto(cont19);
}

//Voltar para cont18
if(room == cont19 && x <= 70.37)
{
	direcao_spawn =-1;
	room_goto(cont18);
}

	//Ir para cont20
if(room == cont19 && x >= 968.33)
{
    if (global.jacare_morreu)
    {
        direcao_spawn = 1;
        room_goto(cont20);
    }
}

//Voltar para cont19
if(room == cont20 && x <= 70.37)
{
	direcao_spawn =-1;
	room_goto(cont19);
}

	//Ir para contAcampamento
if (room == cont20 && x >=968.33)
{
	direcao_spawn = 1;
	room_goto(contAcampamento);
}

//Voltar para cont20
if(room == contAcampamento && x <= 70.37)
{
	direcao_spawn =-1;
	room_goto(cont20);
}

	//Ir para cont21
if (room == contAcampamento && x >=968.33)
{
	direcao_spawn = 1;
	room_goto(cont21);
}

//Voltar para cont20
if(room == cont21 && x <= 70.37)
{
	direcao_spawn =-1;
	room_goto(contAcampamento);
}

	//Ir para contCurupira
if (room == cont21 && x >=968.33)
{
	direcao_spawn = 1;
	room_goto(contCurupira);
}

//Voltar para cont21
if(room == contCurupira && x <= 70.37)
{
	direcao_spawn =-1;
	room_goto(cont21);
}

	//Ir para cont22
if(room == contCurupira && x >= 968.33)
{
    if (global.curupira_fugiu)
    {
        direcao_spawn = 1;
        room_goto(cont22);
    }
}

//Voltar para contCurupira
if(room == cont22 && x <= 70.37)
{
	direcao_spawn =-1;
	room_goto(contCurupira);
}

//ir para cont23
if (room == cont22 && x >=968.33)
{
	direcao_spawn = 1;
	room_goto(cont23);
}

//Voltar para cont22
if(room == cont23 && x <= 70.37)
{
	direcao_spawn =-1;
	room_goto(cont22);
}

//ir para cont24
if (room == cont23 && x >=968.33)
{
	direcao_spawn = 1;
	room_goto(cont24);
}

//Voltar para cont23
if(room == cont24 && x <= 70.37)
{
	direcao_spawn =-1;
	room_goto(cont23);
}

//ir para cont25
if (room == cont24 && x >=968.33)
{
	direcao_spawn = 1;
	room_goto(cont25);
}

//Voltar para cont24
if(room == cont25 && x <= 70.37)
{
	direcao_spawn =-1;
	room_goto(cont24);
}

//ir para contIara
if (room == cont25 && x >=968.33)
{
	direcao_spawn = 1;
	room_goto(contIara);
}

//Voltar para cont25
if(room == contIara && x <= 70.37)
{
	direcao_spawn =-1;
	room_goto(cont25);
}

//ir para contPosIara
if(room == contIara && x >=500){
    if (global.iara_morreu)
    {
        direcao_spawn = 1;
        room_goto(contPosIara);
    }
}

//Voltar para contIara
if(room == contPosIara && x <= 544.37)
{
	direcao_spawn =-1;
	room_goto(contIara);
}

//ir para cont26
if (room == contPosIara && x >=968.33)
{
	direcao_spawn = 1;
	room_goto(cont26);
}

//Voltar para contPosIara
if(room == cont26 && x <= 70.37)
{
	direcao_spawn =-1;
	room_goto(contPosIara);
}

//ir para cont27
if (room == cont26 && x >=968.33)
{
	direcao_spawn = 1;
	room_goto(cont27);
}

//Voltar para cont26
if(room == cont27 && x <= 70.37)
{
	direcao_spawn =-1;
	room_goto(cont26);
}

//ir para cont28
if (room == cont27 && x >=968.33)
{
	direcao_spawn = 1;
	room_goto(cont28);
}

//Voltar para cont27
if(room == cont28 && x <= 70.37)
{
	direcao_spawn =-1;
	room_goto(cont27);
}

//ir para cont29
if (room == cont28 && x >=968.33)
{
	direcao_spawn = 1;
	room_goto(cont29);
}

//ir para cont30
if (room == cont29 && x >=968.33)
{
	direcao_spawn = 1;
	room_goto(cont30);
}

//Voltar para cont29
if(room == cont30 && x <= 70.37)
{
	direcao_spawn =-1;
	room_goto(cont29);
}

//ir para cont31
if (room == cont30 && x >=968.33)
{
	direcao_spawn = 1;
	room_goto(cont31);
}

//Voltar para cont30
if(room == cont31 && x <= 70.37)
{
	direcao_spawn =-1;
	room_goto(cont30);
}

//ir para cont32
if (room == cont31 && x >=968.33)
{
	direcao_spawn = 1;
	room_goto(cont32);
}

//Voltar para cont31
if(room == cont32 && x <= 70.37)
{
	direcao_spawn =-1;
	room_goto(cont31);
}

// ANIMAÇÃO PARADO / ANDANDO / CORRENDO / TIRO

if (tomando_dano)
{
    sprite_index = sCacadorDano;
    image_speed = 0.2;

    if (image_index >= image_number - 1)
    {
        tomando_dano = false;
        sprite_index = sCacadorResp;
        image_index = 0;
    }
}
else if (atirando)
{
    sprite_index = Sprite35;
    image_speed = 0.2;

    if (image_index >= 9 && !tiro_feito)
    {
        tiro_feito = true;

        var descolamento_x = 20;
        var descolamento_y = -186;

        var x_tiro = x + (descolamento_x * sign(image_xscale));
        var y_tiro = y + descolamento_y;

        audio_play_sound(sndTiro, 10, false);

        var t = instance_create_layer(x_tiro, y_tiro, layer, oProjetil);
        t.speed = 7;

        if (image_xscale > 0)
        {
            t.direction = 0;
        }
        else
        {
            t.direction = 180;
        }
    }

    if (image_index >= image_number - 1)
    {
        atirando = false;
        tiro_feito = false;
    }
}
else if (estamina <= 0)
{
    correndo = false;

    if (abs(velh) > 0)
    {
        sprite_index = sCacadorAndando;
        image_speed = 0.15;
    }
    else
    {
        sprite_index = sCacadorResp;
        image_speed = 0.1;
    }
}
else if (abs(velh) > 0)
{
    if (correndo)
    {
        sprite_index = sCacadorCorrendo;
        image_speed = 0.2;
    }
    else
    {
        sprite_index = sCacadorAndando;
        image_speed = 0.15;
    }
}
else
{
    sprite_index = sCacadorResp;
    image_speed = 0.1;
}

//mensagens
	if (global.mensagem_timer > 0)
{
    global.mensagem_timer -= 1;
}
else
{
    global.mensagem_pista = "";
}

if (tempo_mensagem > 0)
{
    tempo_mensagem -= 1;
}
else
{
    mensagem_municao = "";
}

// EVENTO DA CAPIVARA
if (global.capivara_morreu && !global.evento_capivara_feito && !evento_capivara)
{
    evento_capivara = true;
    etapa_evento_capivara = 1;
    tempo_evento_capivara = 60;
}
//parte técnica da capivara , aparece a mensagem e o som

if (evento_capivara)
{
    tempo_evento_capivara -= 1;

    if (tempo_evento_capivara <= 0)
    {
if (etapa_evento_capivara == 1)
{
    audio_play_sound(sndRugido, 10, false);

    etapa_evento_capivara = 2;
    tempo_evento_capivara = 120;
}
else if (etapa_evento_capivara == 2)
{
    fala_evento = "O que foi isso...?";
    tempo_fala = 120;

    etapa_evento_capivara = 3;
    tempo_evento_capivara = 120;
}
else if (etapa_evento_capivara == 3)
{
    fala_evento = "Isso nao foi um animal...";
    tempo_fala = 120;

    etapa_evento_capivara = 4;
    tempo_evento_capivara = 120;
}
else if (etapa_evento_capivara == 4)
{
    fala_evento = "";
    tempo_fala = 0;
	
	global.evento_capivara_feito = true;

    etapa_evento_capivara = 0;
    evento_capivara = false;
}
    }
}

// CONTADOR DA FALA
if (tempo_fala > 0)
{
    tempo_fala -= 1;
}
if (room == inicio)
{
    audio_stop_sound(sndSombrio);
    audio_stop_sound(sndFloresta);
}
if (room == cont19
|| room == cont20
|| room == contAcampamento
|| room == cont21
|| room == cont22
|| room == cont23
|| room == cont24
|| room == cont25
|| room == contIara
|| room == contPosIara
|| room == cont26
|| room == cont27
|| room == cont28)
{
    if (!audio_is_playing(sndSombrio))
    {
        audio_play_sound(sndSombrio, 5, true);
    }
}
else
{
    if (audio_is_playing(sndSombrio))
    {
        audio_stop_sound(sndSombrio);
    }
}

if (room == cont2
|| room == cont3
|| room == cont4
|| room == cont5
|| room == cont6
|| room == cont7
|| room == cont8
|| room == cont9
|| room == cont10
|| room == cont11
|| room == cont12)
{
    if (!audio_is_playing(sndFloresta))
    {
        audio_play_sound(sndFloresta, 5, true);
    }
}
else
{
    if (audio_is_playing(sndFloresta))
    {
        audio_stop_sound(sndFloresta);
    }
}

