// MENSAGEM DE MUNIÇÃO
if (tempo_mensagem > 0)
{
    draw_set_alpha(1);
    draw_set_color(c_white);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);

    draw_text(
        25,
        130,
        mensagem_municao
    );
}


// MENSAGEM DE PISTA
if (global.mensagem_timer > 0)
{
    draw_sprite_ext(
        sDialogo,
        0,
        display_get_gui_width() / 2 - 300,
        display_get_gui_height() - 200,
        1,
        1,
        0,
        c_white,
        1
    );

    draw_set_color(c_white);
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);

    draw_text(
        display_get_gui_width() / 2,
        display_get_gui_height() - 120,
        global.mensagem_pista
    );
}


// MENSAGEM DO EVENTO
if (tempo_fala > 0)
{
    draw_sprite_ext(
        sDialogo,
        0,
        display_get_gui_width() / 2 - 270,
        display_get_gui_height() - 200,
        1,
        1,
        0,
        c_white,
        1
    );

    draw_set_color(c_white);
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);

    draw_text(
        display_get_gui_width() / 2,
        display_get_gui_height() - 120,
        fala_evento
    );
}


// RESTAURA
draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_set_color(c_white);
draw_set_alpha(1);