

if (morrendo)
{
    draw_sprite_ext(
        sCacadorMorre,
        morte_frame,
        x,
        y,
        3.5,
        3.5,
        0,
        c_white,
        1
    );
}
else
{
    draw_self();
}
//

draw_set_alpha(1);
draw_set_color(c_white);


// estamina

var largura = 180;
var altura = 14;

var porcentagem = estamina / estamina_max;

// Fundo
draw_set_color(c_black);
draw_rectangle(
    20,
    20,
    20 + largura,
    20 + altura,
    false
);

// Estamina
draw_set_color(c_lime);
draw_rectangle(
    20,
    20,
    20 + (largura * porcentagem),
    20 + altura,
    false
);

// Borda
draw_set_color(c_white);
draw_rectangle(
    20,
    20,
    20 + largura,
    20 + altura,
    true
);

draw_set_color(c_white);

// desenho das munições

var espaco = 28;

for (var i = 0; i < balas; i++)
{
    draw_sprite(sMunicao, 0, 25 + (i * espaco), 130);
}

if (tempo_mensagem > 0)
{
    draw_set_color(c_white);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);

    draw_text(25, 130, mensagem_municao);

    draw_set_color(c_white);
}



//inventario
if (inventario_aberto)
{
    // FUNDO
draw_set_color(c_black);
draw_set_alpha(0.6);

draw_rectangle(
    250,
    100,
    750,
    600,
    false
);

draw_set_alpha(1);


    // ALINHAMENTO
    draw_set_color(c_white);
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);


    // TÍTULO
    draw_text(
        display_get_gui_width() / 2,
        150,
        "INVENTÁRIO"
    );


    // POSIÇÃO DO ITEM SELECIONADO
    var y_selecao = 250 + (item_selecionado * 70);


    // DESTAQUE DO ITEM
    draw_set_color(c_yellow);

    draw_rectangle(
        350,
        y_selecao - 25,
        650,
        y_selecao + 25,
        true
    );


// SPRITE DA MUNIÇÃO
draw_sprite(
    sMunicao,
    0,
    400,
    230
);

draw_text(
    470,
    250,
    "Municao: " + string(municao)
);


// SPRITE DA ERVA
draw_sprite(
    sErva,
    0,
    400,
    307
);

draw_text(
    470,
    320,
    "Ervas: " + string(ervas)
);


// SPRITE DA COMIDA
draw_sprite(
    sComida,
    0,
    400,
    380
);

draw_text(
    470,
    390,
    "Comida: " + string(comida)
);


    // CONTROLES
    draw_text(
        display_get_gui_width() / 2,
        500,
        "↑ ↓ Selecionar     X Usar"
    );


    // RESTAURA ALINHAMENTO
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
}
