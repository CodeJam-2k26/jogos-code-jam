if (instance_exists(oPause))
{
    if (global.pausado)
    {
        visible = true;
    }
    else
    {
        visible = false;
    }
}
else
{
    visible = false;
}