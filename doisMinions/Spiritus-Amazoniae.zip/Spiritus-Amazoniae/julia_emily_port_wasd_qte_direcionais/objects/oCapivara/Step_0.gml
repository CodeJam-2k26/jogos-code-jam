if (morte)
{
    global.capivara_morreu = true;
	
	audio_stop_sound(sndCapivaraCorrendo);

    if (!animacao_morte)
    {

		
        animacao_morte = true;
        sprite_index = sCapivaraMorre;
        image_index = 0;
        image_speed = 0.15;
		    audio_play_sound(sndCapivaraMorre, 10, false);
    }

    if (image_index >= image_number - 1)
    {
        image_index = image_number - 1;
        image_speed = 0;
    }

    exit;
}


// A capivara anda somente até chegar na cont10
if (global.etapa_capivara < 10)
{
    x += velocidade;
    sprite_index = sCapivaraCorrendo;

    if (!audio_is_playing(sndCapivaraCorrendo))
    {
        audio_play_sound(sndCapivaraCorrendo, 5, true);
    }
}

if (global.etapa_capivara >= 10 && audio_is_playing(sndCapivaraCorrendo))
{
    audio_stop_sound(sndCapivaraCorrendo);
}

// CONT5 -> CONT6
if (room == cont5 && x >= room_width - 20)
{
    global.etapa_capivara = 6;

}


// CONT6 -> CONT7
if (room == cont6 && x >= room_width - 20)
{
    global.etapa_capivara = 7;
}


// CONT7 -> CONT8
if (room == cont7 && x >= room_width - 20)
{
    global.etapa_capivara = 8;

}


// CONT8 -> CONT9
if (room == cont8 && x >= room_width - 20)
{
    global.etapa_capivara = 9;

}


// CONT9 -> CONT10
if (room == cont9 && x >= room_width - 20)
{
    global.etapa_capivara = 10;

}