velocidade = 6;
fugindo = true;
morte = false;
animacao_morte = false;

if (!variable_global_exists("etapa_capivara"))
{
    global.etapa_capivara = 5;
}

if (!variable_global_exists("capivara_morreu"))
{
    global.capivara_morreu = false;

}

