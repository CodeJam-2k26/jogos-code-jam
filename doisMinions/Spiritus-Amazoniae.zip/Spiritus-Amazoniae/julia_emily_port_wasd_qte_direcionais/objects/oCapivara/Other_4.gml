if (global.capivara_morreu)
{
    instance_destroy();
    exit;
}

if (room == cont5 && global.etapa_capivara >= 6)
{
    instance_destroy();
}

if (room == cont6 && global.etapa_capivara >= 7)
{
    instance_destroy();
}

if (room == cont7 && global.etapa_capivara >= 8)
{
    instance_destroy();
}

if (room == cont8 && global.etapa_capivara >= 9)
{
    instance_destroy();
}

if (room == cont9 && global.etapa_capivara >= 10)
{

    instance_destroy();
}