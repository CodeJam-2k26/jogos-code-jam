

draw_set_color(c_black);

draw_rectangle(
    0,
    0,
    display_get_gui_width(),
    display_get_gui_height(),
    false
);


draw_set_halign(fa_center);
draw_set_valign(fa_middle);


// =========================
// TÍTULO
// =========================

draw_set_color(c_white);

draw_text(
    display_get_gui_width() / 2,
    200,
    "VOCE MORREU"
);


// =========================
// CONTINUAR
// =========================

if (opcao == 1)
{
    draw_set_color(c_yellow);
}
else
{
    draw_set_color(c_white);
}

draw_text(
    display_get_gui_width() / 2,
    350,
    "CONTINUAR"
);


// =========================
// SAIR
// =========================

if (opcao == 0)
{
    draw_set_color(c_yellow);
}
else
{
    draw_set_color(c_white);
}

draw_text(
    display_get_gui_width() / 2,
    450,
    "SAIR"
);


// =========================
// VOLTAR AO PADRÃO
// =========================

draw_set_color(c_white);
draw_set_halign(fa_left);
draw_set_valign(fa_top);