pode_continuar = false;
opcao = 0;
