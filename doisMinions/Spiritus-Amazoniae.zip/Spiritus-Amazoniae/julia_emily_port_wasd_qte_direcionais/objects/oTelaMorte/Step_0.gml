
if ((gamepad_button_check_pressed(4, gp_padu) || keyboard_check_pressed(vk_up) || keyboard_check_pressed(ord("W"))))
{
    opcao = 1;
}


// =========================
// SETA PARA BAIXO
// =========================

if ((gamepad_button_check_pressed(4, gp_padd) || keyboard_check_pressed(vk_down) || keyboard_check_pressed(ord("S"))))
{
    opcao = 0;
}


// =========================
// CONFIRMAR
// =========================

if ((gamepad_button_check_pressed(4, gp_face1) || keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space)))
{
    // =========================
    // SAIR
    // =========================

    if (opcao == 0)
    {
        // Destrói o jogador morto
        if (instance_exists(oCacador))
        {
            with (oCacador)
            {
                instance_destroy();
            }
        }

        instance_destroy();

        room_goto(menu);
    }


    // =========================
    // CONTINUAR
    // =========================
if (opcao == 1)
{
    if (instance_exists(oCacador))
    {
        with (oCacador)
        {
            vida = 5;

            morrendo = false;
            tomando_dano = false;

            morte_frame = 0;
            morte_timer = 0;
            morte_terminou = false;

            sprite_index = sCacadorResp;
            image_index = 0;
            image_speed = 0.1;

            atirando = false;
            tiro_feito = false;
            correndo = false;
            velh = 0;
        }
    }

    instance_destroy();

    room_goto(global.room_morte);
}
}