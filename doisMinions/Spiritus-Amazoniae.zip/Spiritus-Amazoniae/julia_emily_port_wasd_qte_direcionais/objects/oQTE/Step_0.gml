// ========================================
// CURUPIRA FUGIU
// ========================================

if (curupira_fugindo)
{
    exit;
}


// ========================================
// CAÇADOR MORRENDO
// ========================================

if (oCacador.morrendo)
{
    exit;
}

if (instance_exists(oCurupira))
{
    if (esperando_tiro)
    {
        oCurupira.atacando = false;
    }
    else if (tempo_ataque > 0)
    {
        oCurupira.atacando = true;
    }
    else
    {
        oCurupira.atacando = false;
    }
}

if (tempo_ataque > 0)
{
    tempo_ataque -= 1;
}

// ========================================
// FASE DE TIRO
// ========================================

if (esperando_tiro)
{
    tempo_tiro -= 1;

    // PROJÉTIL ACERTOU
    if (tiro_confirmado)
    {
        tiro_confirmado = false;
        esperando_tiro = false;
        tempo_tiro = 0;

        // PRIMEIRA RODADA
        if (fase == 1)
        {
            vida_curupira = 4;
            fase = 2;

            botoes_total = 4;
            botoes_acertados = 0;
            tempo = 45;

            vezes_x = 0;
            vezes_bolinha = 0;
            vezes_quadrado = 0;
            vezes_triangulo = 0;

            botao = irandom(3);
        }

        // SEGUNDA RODADA
        else if (fase == 2)
        {
            vida_curupira = 3;
            fase = 3;

            botoes_total = 3;
            botoes_acertados = 0;
            tempo = 45;

            vezes_x = 0;
            vezes_bolinha = 0;
            vezes_quadrado = 0;
            vezes_triangulo = 0;

            botao = irandom(3);
        }

        // TERCEIRA RODADA
     else if (fase == 3)
{
    vida_curupira = 0;

    resultado = 2;

    esperando_tiro = false;
    tiro_confirmado = false;

    curupira_fugindo = true;
    global.curupira_fugiu = true;

    // Encerra o primeiro QTE
    instance_destroy();
    exit;
}
    }


    // TEMPO PARA ATIRAR ACABOU
if (tempo_tiro <= 0)
{
    tempo_ataque = 30;
    esperando_tiro = false;
        tiro_confirmado = false;

        botoes_acertados = 0;

        if (fase == 1)
        {
            botoes_total = 5;
            tempo = 45;
        }
        else if (fase == 2)
        {
            botoes_total = 4;
            tempo = 45;
        }
        else
        {
            botoes_total = 3;
            tempo = 45;
        }

        vezes_x = 0;
        vezes_bolinha = 0;
        vezes_quadrado = 0;
        vezes_triangulo = 0;

        botao = irandom(3);
    }

    exit;
}


// ========================================
// TEMPO DO QTE
// ========================================

tempo -= 1;


// ========================================
// BOTÃO APERTADO
// ========================================

var apertou = -1;

if ((gamepad_button_check_pressed(gamepad, gp_face1) || keyboard_check_pressed(vk_up)))
{
    apertou = 0;
}
else if ((gamepad_button_check_pressed(gamepad, gp_face2) || keyboard_check_pressed(vk_down)))
{
    apertou = 1;
}
else if ((gamepad_button_check_pressed(gamepad, gp_face3) || keyboard_check_pressed(vk_left)))
{
    apertou = 2;
}
else if ((gamepad_button_check_pressed(gamepad, gp_face4) || keyboard_check_pressed(vk_right)))
{
    apertou = 3;
}


// ========================================
// APERTOU ALGUM BOTÃO
// ========================================

if (apertou != -1)
{
    // ====================================
    // ACERTOU
    // ====================================

    if (apertou == botao)
    {
        botoes_acertados += 1;

        if (botoes_acertados >= botoes_total)
        {
            esperando_tiro = true;
            tempo_tiro = 900;
            resultado = 0;
        }
        else
        {
            var novo_botao = irandom(3);

            botao = novo_botao;

            if (fase == 1)
            {
                tempo = 45;
            }
            else if (fase == 2)
            {
                tempo = 45;
            }
            else
            {
                tempo = 45;
            }
        }
    }

    // ====================================
    // ERROU
    // ====================================

else
{
    tempo_ataque = 30;

    oCacador.vida -= 1;
        audio_play_sound(sndDano, 10, false);

        if (oCacador.vida <= 0)
        {
            oCacador.vida = 0;
			
			global.room_morte = room;

            oCacador.morrendo = true;
            oCacador.tomando_dano = false;

            oCacador.morte_frame = 0;
            oCacador.morte_timer = 0;
            oCacador.morte_terminou = false;

            instance_destroy();
            exit;
        }

        oCacador.tomando_dano = true;
        oCacador.image_index = 0;

        botoes_acertados = 0;

        if (fase == 1)
        {
            botoes_total = 5;
            tempo = 45;
        }
        else if (fase == 2)
        {
            botoes_total = 4;
            tempo = 45;
        }
        else
        {
            botoes_total = 3;
            tempo = 45;
        }

        vezes_x = 0;
        vezes_bolinha = 0;
        vezes_quadrado = 0;
        vezes_triangulo = 0;

        botao = irandom(3);
    }
}


// ========================================
// TEMPO DO QTE ACABOU
// ========================================
if (tempo <= 0)
{
    tempo_ataque = 30;
    oCacador.vida -= 1;
    audio_play_sound(sndDano, 10, false);

    if (oCacador.vida <= 0)
    {
        oCacador.vida = 0;
		
		global.room_morte = room;

        oCacador.morrendo = true;
        oCacador.tomando_dano = false;

        oCacador.morte_frame = 0;
        oCacador.morte_timer = 0;
        oCacador.morte_terminou = false;

        instance_destroy();
        exit;
    }

    oCacador.tomando_dano = true;
    oCacador.image_index = 0;

    botoes_acertados = 0;

    if (fase == 1)
    {
        botoes_total = 5;
        tempo = 45;
    }
    else if (fase == 2)
    {
        botoes_total = 4;
        tempo = 45;
    }
    else
    {
        botoes_total = 3;
        tempo = 45;
    }

    vezes_x = 0;
    vezes_bolinha = 0;
    vezes_quadrado = 0;
    vezes_triangulo = 0;

    botao = irandom(3);
}