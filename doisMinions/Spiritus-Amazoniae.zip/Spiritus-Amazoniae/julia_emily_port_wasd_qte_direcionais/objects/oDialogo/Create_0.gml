mensagem = "";
mostrar = false;

if (!variable_global_exists("dialogo_inicio"))
{
    global.dialogo_inicio = 0;
}

mensagem_jacare = "";
mostrar_jacare = false;
if (!variable_global_exists("jacare_mensagem_feita"))
{
    global.jacare_mensagem_feita = false;
}