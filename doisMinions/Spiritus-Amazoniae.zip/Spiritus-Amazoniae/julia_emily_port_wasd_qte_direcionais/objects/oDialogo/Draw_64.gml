if (mostrar)
{
    // =============================
    // CAIXA DE DIÁLOGO
    // =============================

    draw_sprite_ext(
        sDialogo,
        0,
        display_get_gui_width() / 2 - 200,
        display_get_gui_height() - 200,
        1,
        1,
        0,
        c_white,
        1
    );


    // =============================
    // TEXTO
    // =============================

    draw_set_color(c_white);

    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);

    draw_text(
        display_get_gui_width() / 2,
        display_get_gui_height() - 120,
        mensagem
    );

//mensagem2
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_color(c_white);
	
	
    draw_set_color(c_white);

    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);

    draw_text(
        display_get_gui_width() / 2 -100,
        display_get_gui_height() - 180,
        mensagem2
    );


    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_color(c_white);
}
//jacare
if (mostrar_jacare)
{
    // CAIXA DE DIÁLOGO
    draw_sprite_ext(
        sDialogo,
        0,
        display_get_gui_width() / 2 - 270,
        display_get_gui_height() - 200,
        1,
        1,
        0,
        c_white,
        1
    );

    // TEXTO
    draw_set_color(c_white);
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);

    draw_text(
        display_get_gui_width() / 2,
        display_get_gui_height() - 120,
        mensagem_jacare
    );

    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_color(c_white);
}