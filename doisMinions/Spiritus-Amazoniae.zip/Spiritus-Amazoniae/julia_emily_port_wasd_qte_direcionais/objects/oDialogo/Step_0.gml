if (room == inicio && global.dialogo_inicio == 0)
{
    mensagem = "Explore a floresta e siga em frente.";
	mensagem2 = "???";
    mostrar = true;
}
if (mostrar)
{
    if ((gamepad_button_check_pressed(4, gp_face1) || keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space)))
    {
        mostrar = false;
        global.dialogo_inicio = 1;
    }
}

if (global.jacare_morreu && !global.jacare_mensagem_feita && !mostrar_jacare)
{
    mensagem_jacare = "Voce irritou o espirito da floresta, agora ele ira te buscar";
    mostrar_jacare = true;
}

if (mostrar_jacare)
{
    if ((gamepad_button_check_pressed(4, gp_face1) || keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space)))
    {
        mostrar_jacare = false;
        global.jacare_mensagem_feita = true;
    }
}