if (variable_global_exists("veio_da_tela_final")) 
{ 
    if (global.veio_da_tela_final) 
    { 
        if (!(gamepad_button_check(4, gp_face1) || keyboard_check(vk_enter) || keyboard_check(vk_space))) 
        { 
            global.veio_da_tela_final = false; 
        } 
 
        exit; 
    } 
} 
 
if (room == menu) 
{ 
    if ((gamepad_button_check_pressed(4, gp_padd) || keyboard_check_pressed(vk_down) || keyboard_check_pressed(ord("S")))) 
    { 
        opcao = 1; 
        audio_play_sound(sndMenu, 10, false); 
    } 
 
    if ((gamepad_button_check_pressed(4, gp_padu) || keyboard_check_pressed(vk_up) || keyboard_check_pressed(ord("W")))) 
    { 
        opcao = 0; 
        audio_play_sound(sndMenu, 10, false); 
    } 
 
    if ((gamepad_button_check_pressed(4, gp_face1) || keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space))) 
    { 
        if (opcao == 0) 
        { 
            room_goto(escolha); 
        } 
    } 
}