opcao = 0;
global.modo_controle = 0;

if (!variable_global_exists("veio_da_tela_final"))
{
    global.veio_da_tela_final = false;
}