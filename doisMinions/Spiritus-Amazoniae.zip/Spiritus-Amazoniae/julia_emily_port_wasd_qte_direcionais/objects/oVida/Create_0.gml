
max_vida = 5;