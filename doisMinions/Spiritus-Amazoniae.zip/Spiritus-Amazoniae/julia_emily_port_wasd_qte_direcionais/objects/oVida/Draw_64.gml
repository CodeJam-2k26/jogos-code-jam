

for (var i = 0; i < oCacador.vida; i++)
{
    draw_sprite(sVida, 0, 50 + (i * 50), 50);
}