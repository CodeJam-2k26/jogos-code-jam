coletada = false;

id_comida =
    room_get_name(room)
    + "_"
    + string(x)
    + "_"
    + string(y);


if (variable_global_exists("comidas_coletadas"))
{


    for (var i = 0; i < array_length(global.comidas_coletadas); i++)
    {


        if (global.comidas_coletadas[i] == id_comida)
        {
            instance_destroy();
            break;
        }
    }
}