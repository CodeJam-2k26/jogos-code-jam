if (place_meeting(x, y, oCacador))
{
    oCacador.comida += 1;



    oCacador.mensagem_comida = "+1 comida";
    oCacador.tempo_mensagem = 120;

    array_push(
        global.comidas_coletadas,
        id_comida
    );


    instance_destroy();
    exit;
}