if ((gamepad_button_check_pressed(4, gp_select) || keyboard_check_pressed(vk_escape) || keyboard_check_pressed(ord("P"))))
{
    global.pausado = !global.pausado;
}

if (global.pausado)
{
    if ((gamepad_button_check_pressed(4, gp_padd) || keyboard_check_pressed(vk_down) || keyboard_check_pressed(ord("S"))))
    {
        opcao = 1;
        audio_play_sound(sndMenu, 10, false);
    }

    if ((gamepad_button_check_pressed(4, gp_padu) || keyboard_check_pressed(vk_up) || keyboard_check_pressed(ord("W"))))
    {
        opcao = 0;
        audio_play_sound(sndMenu, 10, false);
    }

    if ((gamepad_button_check_pressed(4, gp_face1) || keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space)))
    {
        audio_play_sound(sndMenu, 10, false);

        if (opcao == 0)
        {
            global.pausado = false;
        }

        if (opcao == 1)
        {
            if (global.partida_atual != -1)
            {
                oSave.salvar_partida(global.partida_atual);
            }

            audio_stop_sound(sndFloresta);
            audio_stop_sound(sndSombrio);

            room_goto(menu);
        }
    }
}