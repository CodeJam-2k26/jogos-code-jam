global.pausado = false;
opcao = 0;