
if (room != cont29 && global.curupira_fugiu)
{
    fugindo = true;

    if (!som_fuga_tocado)
    {
        audio_play_sound(sndCurupira, 10, false);
        som_fuga_tocado = true;
    }
}

// ========================================
// CURUPIRA FUGINDO
// ========================================

if (fugindo)
{
    if (sprite_index != sCurupiraCorre)
    {
        sprite_index = sCurupiraCorre;
        image_index = 0;
    }

    image_speed = 0.30;
    image_xscale = -4;
	image_yscale = 4;

    x += velocidade_fuga;

    if (x >= 900)
    {
        global.curupira_fugiu = true;
        instance_destroy();
        exit;
    }
}

// ========================================
// CURUPIRA ATACANDO
// ========================================

else if (atacando)
{
    if (sprite_index != sCurupiraAtacando)
    {
        sprite_index = sCurupiraAtacando;
        image_index = 0;
    }

    image_speed = 0.30;
}

// ========================================
// CURUPIRA PARADO
// ========================================

else
{
    // Troque sCurupiraParado pelo nome
    if (sprite_index != sCuruRespirando)
    {
        sprite_index = sCuruRespirando;
        image_index = 0;
    }

    image_speed = 0.30;
}

