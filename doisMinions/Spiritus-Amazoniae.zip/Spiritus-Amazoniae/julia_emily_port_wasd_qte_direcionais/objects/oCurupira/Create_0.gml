velocidade_fuga = 6;
fugindo = false;
som_fuga_tocado = false;
atacando = false;
// ========================================
// CONTROLE DA FUGA NORMAL
// ========================================

if (!variable_global_exists("curupira_fugiu"))
{
    global.curupira_fugiu = false;
}

// ========================================
// NÃO DESTRUIR O CURUPIRA NAS ROOMS FINAIS
// ========================================

if (room != cont29 && room != cont32)
{
    if (global.curupira_fugiu)
    {
        instance_destroy();
        exit;
    }
}