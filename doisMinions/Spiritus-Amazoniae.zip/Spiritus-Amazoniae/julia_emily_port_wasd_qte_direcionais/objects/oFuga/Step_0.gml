tempo += 1;


// ========================================
// COMEÇA UM FLASH
// ========================================

if (!flash && tempo >= intervalo_flash)
{
    tempo = 0;

    flash = true;

    flashes_feitos += 1;

    // 1 chance em 3 de aparecer
    curupira_aparece = (irandom(2) == 0);

    if (curupira_aparece)
    {
        x_curupira = posicoes_x[global.posicao_curupira];
        y_curupira = posicoes_y[global.posicao_curupira];

        // Avança para a próxima posição
        global.posicao_curupira += 1;

        // Não passa da última posição
        if (global.posicao_curupira >= array_length(posicoes_x))
        {
            global.posicao_curupira = array_length(posicoes_x) - 1;
        }
    }
}


// ========================================
// TERMINA O FLASH
// ========================================

if (flash && tempo >= duracao_flash)
{
    flash = false;
    curupira_aparece = false;

    tempo = 0;
}


// ========================================
// TERMINOU OS FLASHES DA ROOM
// ========================================

if (flashes_feitos >= max_flashes && !flash)
{
    instance_destroy();
}