tempo = 0;

flash = false;
curupira_aparece = false;

duracao_flash = 8;
intervalo_flash = 20;

flashes_feitos = 0;
max_flashes = 8;


// POSIÇÕES DO CURUPIRA
posicoes_x = [900, 750, 650, 550, 500];
posicoes_y = [450, 450, 450, 450, 450];


// CRIA O CONTROLE GLOBAL UMA ÚNICA VEZ
if (!variable_global_exists("posicao_curupira"))
{
    global.posicao_curupira = 0;
}