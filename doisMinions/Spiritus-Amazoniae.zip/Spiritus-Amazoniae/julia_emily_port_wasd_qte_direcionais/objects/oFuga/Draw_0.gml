if (curupira_aparece)
{
    draw_sprite(
        sCurupira,
        0,
        x_curupira,
        y_curupira
    );
}