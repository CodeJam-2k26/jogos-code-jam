// Não desenhar fora da sala comeco
if (room != comeco)
{
    exit;
}

// Não desenhar se estiver concluído
if (global.tutorial_concluido || !ativo)
{
    exit;
}

// Configuração do texto
draw_set_halign(fa_center);
draw_set_valign(fa_middle);
draw_set_color(c_white);

// Texto de cada etapa
var texto = "";

switch (etapa)
{
    case 0:
        texto = "MOVIMENTE O ANALÓGICO ESQUERDO";
        break;

    case 1:
        texto = "APERTE SHARE PARA PAUSAR";
        break;

    case 2:
        texto = "SEGURE LB PARA CORRER";
        break;

    case 3:
        texto = "APERTE RB PARA ATIRAR";
        break;

    case 4:
        texto = "APERTE R3 PARA ABRIR O INVENTÁRIO";
        break;
}

// Fundo escuro atrás da instrução
draw_set_alpha(0.75);
draw_set_color(c_black);
draw_rectangle(180, 60, 830, 125, false);

// Desenhar a instrução
draw_set_alpha(1);
draw_set_color(c_white);
draw_text(505, 92, texto);

// Restaurar configurações
draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_set_color(c_white);
draw_set_alpha(1);