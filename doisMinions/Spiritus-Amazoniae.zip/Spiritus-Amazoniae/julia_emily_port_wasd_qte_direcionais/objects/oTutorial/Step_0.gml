// Só funciona na sala comeco
if (room != comeco)
{
    exit;
}

// Não mostrar se o tutorial já foi concluído
if (global.tutorial_concluido)
{
    ativo = false;
    exit;
}

// Ativar o tutorial
ativo = true;

// ETAPA 0 — MOVIMENTAR
if (etapa == 0)
{
    var eixo = gamepad_axis_value(4, 0);
    if (abs(eixo) < 0.2) eixo = keyboard_check(ord("D")) ? 1 : (keyboard_check(ord("A")) ? -1 : 0);

    if (abs(eixo) > 0.2)
    {
        etapa = 1;
    }
}

// ETAPA 1 — PAUSAR
else if (etapa == 1)
{
    if ((gamepad_button_check_pressed(4, gp_select) || keyboard_check_pressed(vk_escape) || keyboard_check_pressed(ord("P"))))
    {
        etapa = 2;
    }
}

// ETAPA 2 — CORRER
else if (etapa == 2)
{
    if ((gamepad_button_check(4, gp_shoulderlb) || keyboard_check(vk_shift)))
    {
        etapa = 3;
    }
}

// ETAPA 3 — ATIRAR
else if (etapa == 3)
{
    if ((gamepad_button_check_pressed(4, gp_shoulderrb) || keyboard_check_pressed(ord("F"))))
    {
        etapa = 4;
    }
}

// ETAPA 4 — INVENTÁRIO
else if (etapa == 4)
{
    if ((gamepad_button_check_pressed(4, gp_shoulderr) || keyboard_check_pressed(vk_tab)))
    {
        etapa = 5;
    }
}

// FINALIZAR
else if (etapa == 5)
{
    global.tutorial_concluido = true;
    ativo = false;

}