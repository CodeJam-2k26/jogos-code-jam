etapa = 0;
ativo = false;