if (oCursor.opcao == 0)
{
    image_alpha = 1;
}
else
{
    image_alpha = 0.5;
}