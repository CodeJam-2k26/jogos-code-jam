
if (global.iara_morreu)
{
    instance_destroy();
    exit;
}
sprite_normal = sIara;
sprite_ataque = sIaraAtaque;
sprite_morte = sIaraMorte;

morrendo = false;
atacando = false;
tempo_animacao_ataque = 0;
velocidade_morte = 2;

