
/// INICIALIZAÇÃO DA MORTE


if (global.iara_morreu && !morrendo)
{
    morrendo = true;
    atacando = false;

    // Animação de morte
    sprite_index = sprite_morte;
    image_index = 0;
    image_speed = 0.3;

    // Som da Iara afundando
    audio_play_sound(sndIara, 10, false);
}

/// IARA MORRENDO E AFUNDANDO

if (morrendo)
{
    y += velocidade_morte;

    if (image_index >= image_number - 1)
    {
        instance_destroy();
    }

    exit;
}



/// CONTROLA A ANIMAÇÃO DE ATAQUE

if (atacando)
{
    if (sprite_index != sprite_ataque)
    {
        sprite_index = sprite_ataque;
        image_index = 0;
        tempo_animacao_ataque = 0;
    }

    image_speed = 1;

    // Espera a animação terminar
    if (image_index >= image_number - 1)
    {
        atacando = false;
    }
}
else
{
    if (sprite_index != sprite_normal)
    {
        sprite_index = sprite_normal;
        image_index = 0;
    }

    image_speed = 0.3;
}