if (instance_exists(oPause))
{
    visivel = global.pausado;
}
else
{
    visivel = false;
}