if (visivel)
{
    draw_set_color(c_white);
    draw_set_alpha(1);

    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);

    var alpha_botao = 0.5;

    if (oPause.opcao == 0)
    {
        alpha_botao = 1;
    }

    draw_sprite_ext(
        sContinuar,
        0,
        room_width / 2 - 100,
        room_height / 2 - 150,
        0.3,
        0.3,
        0,
        c_white,
        alpha_botao
    );

    draw_set_alpha(1);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
}