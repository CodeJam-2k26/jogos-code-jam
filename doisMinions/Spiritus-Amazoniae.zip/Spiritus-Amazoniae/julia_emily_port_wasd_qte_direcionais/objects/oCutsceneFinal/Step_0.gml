
if (instance_exists(oCacador))
{
    oCacador.visible = false;
}

tempo += 1;

if (etapa == 0)
{
    alpha_tela += 0.03;

    if (alpha_tela >= 1)
    {
        alpha_tela = 1;
        etapa = 1;
        tempo = 0;
    }
}

if (etapa == 1)
{
    tempo += 1;

    // Fica preto por um momento
    if (tempo >= 45)
    {
        etapa = 2;
        tempo = 0;
    }
}

if (etapa == 2)
{
    alpha_tela -= 0.08;

    // Abre a tela rapidamente
    if (alpha_tela <= 0)
    {
        alpha_tela = 0;
        etapa = 3;
        tempo = 0;
    }
}

if (etapa == 3)
{
    tempo += 1;

    // Mantém a imagem visível por pouco tempo
    if (tempo >= 10)
    {
        etapa = 4;
        tempo = 0;
    }
}

if (etapa == 4)
{
    alpha_tela += 0.08;

    // Fecha novamente
    if (alpha_tela >= 1)
    {
        alpha_tela = 1;
        etapa = 5;
        tempo = 0;
    }
}

if (etapa == 5)
{
    tempo += 1;

    if (tempo >= 35)
    {
        etapa = 6;
        tempo = 0;
    }
}

if (etapa == 6)
{
    alpha_tela -= 0.08;

    if (alpha_tela <= 0)
    {
        alpha_tela = 0;
        etapa = 7;
        tempo = 0;
    }
}

if (etapa == 7)
{
    tempo += 1;

    if (tempo >= 8)
    {
        etapa = 8;
        tempo = 0;
    }
}

if (etapa == 8)
{
    alpha_tela += 0.08;

    if (alpha_tela >= 1)
    {
        alpha_tela = 1;
        etapa = 9;
        tempo = 0;
    }
}

if (etapa == 9)
{
    tempo += 1;

    if (tempo >= 35)
    {
        etapa = 10;
        tempo = 0;
    }
}

if (etapa == 10)
{
    alpha_tela -= 0.08;

    if (alpha_tela <= 0)
    {
        alpha_tela = 0;
        etapa = 11;
        tempo = 0;
    }
}

if (etapa == 11)
{
    tempo += 1;

    if (tempo >= 10)
    {
        etapa = 12;
        tempo = 0;
    }
}

if (etapa == 12)
{
    alpha_tela += 0.08;

    if (alpha_tela >= 1)
    {
        alpha_tela = 1;
        etapa = 13;
        tempo = 0;
    }
}

if (etapa == 13)
{
    tempo += 1;

    if (tempo >= 35)
    {
        etapa = 14;
        tempo = 0;
    }
}

if (etapa == 14)
{
    alpha_tela -= 0.08;

    if (alpha_tela <= 0)
    {
        alpha_tela = 0;
        etapa = 15;
        tempo = 0;
    }
}

if (etapa == 15)
{
    tempo += 1;

    frame_caida = floor(tempo / 5);

    if (frame_caida >= sprite_get_number(sprite_flash4))
    {
        frame_caida = sprite_get_number(sprite_flash4) - 1;
    }

    if (tempo >= 60)
    {
        etapa = 16;
        tempo = 0;
    }
}
if (etapa == 16)
{
    alpha_tela += 0.08;

    if (alpha_tela >= 1)
    {
        alpha_tela = 1;
        etapa = 17;
        tempo = 0;
    }
}

if (etapa == 17)
{
    tempo += 1;

    if (tempo >= 35)
    {
        etapa = 18;
        tempo = 0;
    }
}

if (etapa == 18)
{
    alpha_tela -= 0.08;

    if (alpha_tela <= 0)
    {
        alpha_tela = 0;
        etapa = 19;
        tempo = 0;
    }
}

if (etapa == 19)
{
    tempo += 1;

    if (tempo >= 8)
    {
        etapa = 20;
        tempo = 0;
    }
}

if (etapa == 20)
{
    alpha_tela += 0.08;

    if (alpha_tela >= 1)
    {
        alpha_tela = 1;
        etapa = 21;
        tempo = 0;
    }
}

if (etapa == 21)
{
    alpha_tela -= 0.08;

    if (alpha_tela <= 0)
    {
        alpha_tela = 0;
        etapa = 22;
        tempo = 0;
    }
}
if (etapa == 22)
{
    tempo += 1;

    var cam = view_camera[0];

    // Zoom progressivo da câmera
    var tamanho_cam = lerp(1009, 700, tempo / 120);

    camera_set_view_size(
        cam,
        tamanho_cam,
        tamanho_cam * 569 / 1009
    );
	camera_set_view_pos(
    cam,
    x_cabeca_final - 1009 / 2,
    y_cabeca_final - 569 / 2
);

    if (tempo >= 120)
    {
        etapa = 23;
        tempo = 0;
    }
}


if (etapa == 23)
{
    tempo += 1;

    if (tempo >= 30)
    {
        etapa = 24;
        tempo = 0;
    }
}

if (etapa == 24)
{
    tempo += 1;

    var cam = view_camera[0];

    camera_set_view_size(
        cam,
        700,
        700 * 569 / 1009
    );

    // Câmera acompanha os pés
    camera_set_view_pos(
        cam,
        x_pes_curupira - 500,
        y_pes_curupira - 390
    );

    // Pés andando
    x_pes_curupira -= 1.5;

    if (tempo >= 300)
    {
        etapa = 25;
        tempo = 0;
    }
}
if (etapa == 25)
{
    tempo += 1;

    if (tempo >= 30)
    {
        etapa = 26;
        tempo = 0;
    }
}

if (etapa == 26)
{
    tempo += 1;

    var cam = view_camera[0];

    camera_set_view_size(
        cam,
        700,
        700 * 569 / 1009
    );

    camera_set_view_pos(
        cam,
        x_cabeca_final - 1009 / 2,
        y_cabeca_final - 569 / 2 + 100
    );

    if (tempo >= 90)
    {
        etapa = 27;
        tempo = 0;
    }
}
if (etapa == 27)
{
    tempo += 1;

    if (tempo >= 30)
    {
        etapa = 28;
        tempo = 0;
    }
}
if (etapa == 28)
{
    tempo += 1;

    if (tempo >= 60)
    {
        etapa = 29;
        tempo = 0;
    }
}
if (etapa == 29)
{
    tempo += 1;

    if (tempo >= 30)
    {

        etapa = 30;
        tempo = 0;
    }
}
if (etapa == 30)
{
    tempo += 1;

    x_curupira_final += 2;

    var cam = view_camera[0];

    camera_set_view_size(
        cam,
        700,
        700 * 569 / 1009
    );

    camera_set_view_pos(
        cam,
        x_curupira_final - 500,
        y_curupira_final - 250
    );

    if (tempo >= 300)
    {
        etapa = 31;
        tempo = 0;
    }
}

if (etapa == 31)
{
    tempo += 1;

    if (tempo >= 90)
    {
        etapa = 32;
        tempo = 0;
    }
}

if (etapa == 32)
{
    tempo += 1;

    if (tempo == 1)
    {

        global.partida_finalizada = true;

        if (global.partida_atual != -1)
        {
            oSave.salvar_partida(global.partida_atual);
        }

        room_goto(contFinal);
    }

    if (alpha_final < 1)
    {
        alpha_final += 0.005;
    }
    else
    {
        mensagem_final = true;

        if (alpha_mensagem < 1)
        {
            alpha_mensagem += 0.01;
        }
    }
}
if (mensagem_final)
{
    if (y_texto_final > display_get_gui_height() / 2)
    {
        y_texto_final -= 0.5;
    }
    else
    {
        botao_sair = true;
    }
}
if (botao_sair)
{
    if ((gamepad_button_check_pressed(4, gp_face1) || keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space)))
    {
        global.veio_da_tela_final = true;

        instance_destroy();

        room_goto(menu);
    }
}