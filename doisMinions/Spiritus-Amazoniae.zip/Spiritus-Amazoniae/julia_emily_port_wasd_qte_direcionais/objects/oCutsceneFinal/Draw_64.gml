// ========================================
// ESCURECIMENTO DA CENA
// ========================================

draw_set_alpha(0.45);
draw_set_color(c_black);

draw_rectangle(
    0,
    0,
    display_get_gui_width(),
    display_get_gui_height(),
    false
);

draw_set_alpha(1);
draw_set_color(c_white);


// ========================================
// PISCADAS
// ========================================

if (etapa == 23 || etapa == 25 || etapa == 27 || etapa ==29 || etapa ==31)
{
    draw_set_alpha(1);
    draw_set_color(c_black);

    draw_rectangle(
        0,
        0,
        display_get_gui_width(),
        display_get_gui_height(),
        false
    );

    draw_set_color(c_white);
}



if (etapa == 3 || etapa == 7)
{
    draw_set_alpha(1);

    draw_sprite_ext(
        sprite_curupira,
        0,
        display_get_gui_width() / 2 + 170,
        display_get_gui_height() / 2 + 200,
        4,
        4,
        0,
        c_white,
        1
    );
}
if (etapa == 7)
{
    draw_set_alpha(1);

    draw_sprite_ext(
        sprite_flash2,
        0,
        display_get_gui_width() / 2 + 170,
        display_get_gui_height() / 2 + 200,
        4,
        4,
        0,
        c_white,
        1
    );
}

if (etapa == 11)
{
    draw_set_alpha(1);

    draw_sprite_ext(
        sprite_flash3,
        0,
        display_get_gui_width() / 2 + 170,
        display_get_gui_height() / 2 + 200,
        4,
        4,
        0,
        c_white,
        1
    );
}

if (etapa == 15)
{
    draw_set_alpha(1);

    draw_sprite_ext(
        sprite_flash4,
        frame_caida,
        display_get_gui_width() / 2 -290,
        display_get_gui_height() / 2 - 200,
        4,
        4,
        0,
        c_white,
        1
    );
}
// CABEÇA
if (etapa == 22 || etapa == 26)
{
    draw_sprite_ext(
        sCacadorCabeca,
        0,
        x_cabeca_final,
        y_cabeca_final,
        7,
        7,
        0,
        c_white,
        0.80
    );
}


// PÉS
if (etapa == 24)
{
    draw_sprite_ext(
        sCurupiraPes,
        0,
        x_pes_curupira,
        y_pes_curupira,
        10,
        10,
        0,
        c_white,
        0.80
    );
}


// MÃO
if (etapa == 28)
{
    draw_sprite_ext(
        sCurupiraMao,
        0,
        x_mao_curupira,
        y_mao_curupira,
        8,
        8,
        0,
        c_white,
        0.80
    );
}
if (etapa == 30)
{
    draw_sprite_ext(
        sCurupira,
        0,
        x_curupira_final,
        y_curupira_final,
        7,
        7,
        0,
        c_white,
        0.80
    );
}
draw_set_alpha(alpha_final);
draw_set_color(c_black);

draw_rectangle(
    0,
    0,
    display_get_gui_width(),
    display_get_gui_height(),
    false
);

draw_set_alpha(1);
draw_set_color(c_white);


// ========================================
// TEXTO FINAL
// ========================================

if (mensagem_final)
{
    draw_set_alpha(alpha_mensagem);
    draw_set_color(c_white);

    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);

    draw_text(
        display_get_gui_width() / 2,
        y_texto_final,
        "FIM"
    );

    draw_set_alpha(1);
}


// ========================================
// BOTÃO SAIR
// ========================================

if (botao_sair)
{
    draw_set_alpha(alpha_mensagem);
    draw_set_color(c_white);

    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);

    draw_text(
        display_get_gui_width() / 2,
        display_get_gui_height() / 2 + 100,
        "SAIR"
    );

    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_alpha(1);
    draw_set_color(c_white);
}