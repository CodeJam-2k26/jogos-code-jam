etapa = 0;
tempo = 0;
zoom_final = 1;
sprite_curupira = sCurupira;
camera_trocando = false;
alpha_tela = 0;
flash = 0;
alpha_final = 0;
alpha_mensagem = 0;
mensagem_final = false;
y_texto_final = display_get_gui_height() + 100;
botao_sair = false;
selecionado_sair = true;
global.bloquear_cursor_menu = false;

// Sprites das piscadas
sprite_flash1 = sCurupira;
sprite_flash2 = sCurupira;
sprite_flash3 = sCurupira;
sprite_flash4 = sCacadorMorteSeg;

// Sprites da cena final
sprite_pes_curupira = sCurupiraPes;
sprite_mao_curupira = sCurupiraMao;

// Animação do Caçador caindo
frame_caida = 0;
cabeca_final = false;

// ========================================
// CURUPIRA
// ========================================

x_curupira_final = display_get_gui_width() / 2 +170;
y_curupira_final = display_get_gui_height() / 2 + 200;

velocidade_final = 2;


// ========================================
// CABEÇA
// ========================================

x_cabeca_final = display_get_gui_width() / 2 - 10;
y_cabeca_final = display_get_gui_height() / 2 + 180;


// ========================================
// PÉS DO CURUPIRA
// ========================================

x_pes_curupira = 900;
y_pes_curupira = display_get_gui_height() / 2 + 290;
velocidade_pes = 2;


// ========================================
// MÃO DO CURUPIRA
// ========================================

x_mao_curupira = x_cabeca_final;
y_mao_curupira = y_cabeca_final;