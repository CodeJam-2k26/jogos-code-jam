if (oCursor.opcao == 2)
{
    image_alpha = 1;
}
else
{
    image_alpha = 0.5;
}

draw_self();