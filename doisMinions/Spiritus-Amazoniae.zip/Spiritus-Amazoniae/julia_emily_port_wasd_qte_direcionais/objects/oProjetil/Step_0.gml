if (place_meeting(x, y, oCapivara))
{
    var capivara = instance_place(x, y, oCapivara);

    if (room == cont10)
    {
        capivara.morte = true;
        global.capivara_morreu = true;
    }

    instance_destroy();
}

if (place_meeting(x, y, oOnca))
{
    var onca = instance_place(x, y, oOnca);

    if (room == cont15 && onca.onca_vulneravel)
    {
        onca.morte = true;
    }

    instance_destroy();
}

if (place_meeting(x, y, oJacare))
{
    var jacare = instance_place(x, y, oJacare);

    if (room == cont19 && jacare.jacare_vulneravel)
    {
        jacare.morte = true;
    }

    instance_destroy();
}