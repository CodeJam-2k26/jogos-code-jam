if (room == cont29)
{
    if (instance_exists(oQTEFinal))
    {
        if (oQTEFinal.esperando_tiro)
        {
            oQTEFinal.tiro_confirmado = true;
        }
    }
}
else
{
    if (instance_exists(oQTE))
    {
        if (oQTE.esperando_tiro)
        {
            oQTE.tiro_confirmado = true;
        }
    }
}

instance_destroy();