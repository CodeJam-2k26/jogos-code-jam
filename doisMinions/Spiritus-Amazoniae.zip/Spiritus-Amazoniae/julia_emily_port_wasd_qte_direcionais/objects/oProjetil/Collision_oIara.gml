if (instance_exists(oQTEIara))
{
    if (oQTEIara.esperando_tiro)
    {
        oQTEIara.tiro_confirmado = true;
    }
}

instance_destroy();