if (qte_ativo)
{
    var botao_apertado = -1;

    if ((gamepad_button_check_pressed(4, gp_face1) || keyboard_check_pressed(vk_up)))
    {
        botao_apertado = 0;
    }
    else if ((gamepad_button_check_pressed(4, gp_face2) || keyboard_check_pressed(vk_down)))
    {
        botao_apertado = 1;
    }
    else if ((gamepad_button_check_pressed(4, gp_face3) || keyboard_check_pressed(vk_left)))
    {
        botao_apertado = 2;
    }
    else if ((gamepad_button_check_pressed(4, gp_face4) || keyboard_check_pressed(vk_right)))
    {
        botao_apertado = 3;
    }


    // ========================================
    // TEMPO
    // ========================================

    tempo -= 1;

    if (tempo <= 0)
    {
        reiniciar_rodada();
    }


    // ========================================
    // BOTÃO APERTADO
    // ========================================

    if (botao_apertado != -1)
    {
        if (botao_apertado == botao_atual)
        {
            comandos_feitos += 1;

            tempo = 60;


            // ====================================
            // COMPLETOU A RODADA
            // ====================================

            if (comandos_feitos >= comandos_rodada)
            {
                rodada += 1;

                comandos_feitos = 0;


                // ==================================
                // COMPLETOU AS 2 RODADAS
                // ==================================

                if (rodada > 2)
                {
                    qte_ativo = false;

					oJacare.jacare_vulneravel = true;

                }
                else
                {
                    show_debug_message(
                        "QTE JACARÉ - RODADA "
                        + string(rodada)
                    );

                    sortear_botao();
                }
            }
            else
            {
                sortear_botao();
            }
        }


        // ========================================
        // BOTÃO ERRADO
        // ========================================

        else
        {
            reiniciar_rodada();
        }
    }
}