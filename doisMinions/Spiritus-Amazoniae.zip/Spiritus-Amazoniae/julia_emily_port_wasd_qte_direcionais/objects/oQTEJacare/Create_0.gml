if (global.jacare_morreu)
{
    instance_destroy();
    exit;
}

rodada = 1;

tempo = 60;

botao_atual = -1;

qte_ativo = true;

jacare_vulneravel = false;

ultimo_botao = -1;
vezes_botao = 0;

comandos_rodada = 5;
comandos_feitos = 0;


botao_atual = irandom(3);


sortear_botao = function()
{
    var novo_botao = irandom(3);

    if (novo_botao == ultimo_botao)
    {
        vezes_botao += 1;
    }
    else
    {
        vezes_botao = 1;
    }

    if (vezes_botao > 2)
    {
        repeat (10)
        {
            novo_botao = irandom(3);

            if (novo_botao != ultimo_botao)
            {
                break;
            }
        }

        vezes_botao = 1;
    }

    ultimo_botao = novo_botao;
    botao_atual = novo_botao;
};


reiniciar_rodada = function()
{
    oCacador.vida -= 1;

    audio_play_sound(sndDano, 10, false);

    oCacador.tomando_dano = true;
    oCacador.image_index = 0;

    if (oCacador.vida <= 0)
    {
        oCacador.vida = 0;

        global.room_morte = room;

        oCacador.morrendo = true;

        oCacador.morte_frame = 0;
        oCacador.morte_timer = 0;
        oCacador.morte_terminou = false;

        qte_ativo = false;

        return;
    }

    comandos_feitos = 0;
    tempo = 60;

    sortear_botao();

};