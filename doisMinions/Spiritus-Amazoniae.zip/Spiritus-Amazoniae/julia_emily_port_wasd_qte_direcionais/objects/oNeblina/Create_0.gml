image_alpha = 0.15;
velocidade = 0.3;

if (x < 0)
{
    x = room_width;
}