draw_set_alpha(0.15);

draw_sprite(
    sNeblina,
    0,
    x,
    y
);

draw_set_alpha(1);