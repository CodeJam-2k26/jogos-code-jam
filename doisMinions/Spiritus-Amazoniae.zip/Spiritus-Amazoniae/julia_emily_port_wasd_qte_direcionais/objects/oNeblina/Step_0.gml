x -= velocidade;

if (x <= -sprite_width)
{
    x = room_width;
}