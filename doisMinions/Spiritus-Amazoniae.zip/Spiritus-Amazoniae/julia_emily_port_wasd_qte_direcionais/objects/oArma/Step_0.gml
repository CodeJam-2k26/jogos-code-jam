if (!global.mensagem_arma_vista)
{
    if (place_meeting(x, y, oCacador))
    {
        global.mensagem_pista = "Alguem passou por aqui.";
        global.mensagem_timer = 120;

        global.mensagem_arma_vista = true;
    }
}