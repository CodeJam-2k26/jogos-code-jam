if (!variable_global_exists("mensagem_arma_vista"))
{
    global.mensagem_arma_vista = false;
}