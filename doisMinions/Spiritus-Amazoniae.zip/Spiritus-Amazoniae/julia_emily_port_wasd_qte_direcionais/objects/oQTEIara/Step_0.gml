
// ========================================
// SE O CAÇADOR ESTÁ MORRENDO
// ========================================

if (oCacador.morrendo)
{
    exit;
}

if (global.iara_morreu)
{
    instance_destroy();
    exit;
}


// ========================================
// FASE DE TIRO
// ========================================

if (esperando_tiro)
{
    tempo_tiro -= 1;


    // ====================================
    // O PROJÉTIL ACERTOU O iara
    // ====================================

    if (tiro_confirmado)
    {
        tiro_confirmado = false;
        esperando_tiro = false;
        tempo_tiro = 0;


        // =================================
        // TIRO DA PRIMEIRA RODADA
        // =================================

        if (fase == 1)
        {
            vida_iara = 4;

            fase = 2;

            botoes_total = 4;
            botoes_acertados = 0;

            tempo = 60;

            vezes_x = 0;
            vezes_bolinha = 0;
            vezes_quadrado = 0;
            vezes_triangulo = 0;

            botao = irandom(3);
        }


        // =================================
        // TIRO DA SEGUNDA RODADA
        // =================================

        else if (fase == 2)
        {
            vida_iara = 3;

            fase = 3;

            botoes_total = 3;
            botoes_acertados = 0;

            tempo = 45;

            vezes_x = 0;
            vezes_bolinha = 0;
            vezes_quadrado = 0;
            vezes_triangulo = 0;

            botao = irandom(3);
        }


        // =================================
        // TIRO DA TERCEIRA RODADA
        // =================================


else if (fase == 3)
{
    vida_iara = 0;

    resultado = 2;

    esperando_tiro = false;
    tiro_confirmado = false;

    global.iara_morreu = true;
}

        exit;
    }


    // ====================================
    // TEMPO PARA ATIRAR ACABOU
    // ====================================

    if (tempo_tiro <= 0)
    {
        esperando_tiro = false;
        tiro_confirmado = false;

        // Reinicia SOMENTE a rodada atual
        botoes_acertados = 0;

        if (fase == 1)
        {
            botoes_total = 5;
            tempo = 60;
        }
        else if (fase == 2)
        {
            botoes_total = 4;
            tempo = 45;
        }
        else
        {
            botoes_total = 3;
            tempo = 45;
        }

        vezes_x = 0;
        vezes_bolinha = 0;
        vezes_quadrado = 0;
        vezes_triangulo = 0;

        botao = irandom(3);
    }

    exit;
}



// ========================================
// TEMPO DO QTE
// ========================================

tempo -= 1;


// ========================================
// VER QUAL BOTÃO FOI APERTADO
// ========================================

var apertou = -1;

if ((gamepad_button_check_pressed(4, gp_face1) || keyboard_check_pressed(vk_up)))
{
    apertou = 0;
}
else if ((gamepad_button_check_pressed(4, gp_face2) || keyboard_check_pressed(vk_down)))
{
    apertou = 1;
}
else if ((gamepad_button_check_pressed(4, gp_face3) || keyboard_check_pressed(vk_left)))
{
    apertou = 2;
}
else if ((gamepad_button_check_pressed(4, gp_face4) || keyboard_check_pressed(vk_right)))
{
    apertou = 3;
}

// ========================================
// SE APERTOU ALGUM BOTÃO
// ========================================

if (apertou != -1)
{
    // ====================================
    // ACERTOU
    // ====================================

    if (apertou == botao)
    {
        botoes_acertados += 1;


        // =================================
        // TERMINOU A RODADA
        // =================================

        if (botoes_acertados >= botoes_total)
        {
            // Em vez de ir direto para a
            // próxima rodada, pede para atirar
            esperando_tiro = true;

            tempo_tiro = 320;

            resultado = 0;
			
if (instance_exists(oIara))
{
    oIara.atacando = false;
}
        }


        // =================================
        // AINDA TEM BOTÕES
        // =================================

        else
        {
            repeat (20)
            {
                var novo_botao = irandom(3);

                if (novo_botao == 0 && vezes_x < 2)
                {
                    botao = novo_botao;
                    vezes_x += 1;
                    break;
                }

                if (novo_botao == 1 && vezes_bolinha < 2)
                {
                    botao = novo_botao;
                    vezes_bolinha += 1;
                    break;
                }

                if (novo_botao == 2 && vezes_quadrado < 2)
                {
                    botao = novo_botao;
                    vezes_quadrado += 1;
                    break;
                }

                if (novo_botao == 3 && vezes_triangulo < 2)
                {
                    botao = novo_botao;
                    vezes_triangulo += 1;
                    break;
                }
            }


            if (fase == 1)
            {
                tempo = 60;
            }
            else if (fase == 2)
            {
                tempo = 45;
            }
            else
            {
                tempo = 45;
            }
        }
    }


    // ====================================
    // ERROU
    // ====================================

    else
    {
        oCacador.vida -= 1;
		audio_play_sound(sndDano, 10, false);

		if (instance_exists(oIara))
		{
			oIara.atacando = true;
		}

        if (oCacador.vida <= 0)
        {
             if (room == contIara)
            {
                global.room_morte = cont25;
            }

            oCacador.morrendo = true;
            oCacador.tomando_dano = false;
            oCacador.morte_frame = 0;
            oCacador.morte_timer = 0;
            oCacador.morte_terminou = false;
        }
        else
        {
            oCacador.tomando_dano = true;
            oCacador.image_index = 0;

            // Reinicia a rodada atual
            botoes_acertados = 0;

            if (fase == 1)
            {
                botoes_total = 5;
                tempo = 60;
            }
            else if (fase == 2)
            {
                botoes_total = 4;
                tempo = 45;
            }
            else
            {
                botoes_total = 3;
                tempo = 45;
            }

            vezes_x = 0;
            vezes_bolinha = 0;
            vezes_quadrado = 0;
            vezes_triangulo = 0;

            botao = irandom(3);
        }
    }
}


// ========================================
// TEMPO DO QTE ACABOU
// ========================================

if (tempo <= 0)
{
    oCacador.vida -= 1;
	audio_play_sound(sndDano, 10, false);
	
	if (instance_exists(oIara))
{
    oIara.atacando = true;
}

    if (oCacador.vida <= 0)
    {
         if (room == contIara)
        {
            global.room_morte = cont25;
        }

        oCacador.morrendo = true;
        oCacador.tomando_dano = false;
        oCacador.morte_frame = 0;
        oCacador.morte_timer = 0;
        oCacador.morte_terminou = false;
    }
    else
    {
        oCacador.tomando_dano = true;
        oCacador.image_index = 0;

        // Reinicia a rodada atual
        botoes_acertados = 0;

        if (fase == 1)
        {
            botoes_total = 5;
            tempo = 60;
        }
        else if (fase == 2)
        {
            botoes_total = 4;
            tempo = 45;
        } 
        else
        {
            botoes_total = 3;
            tempo = 45;
        }

        vezes_x = 0;
        vezes_bolinha = 0;
        vezes_quadrado = 0;
        vezes_triangulo = 0;

        botao = irandom(3);
    }
}