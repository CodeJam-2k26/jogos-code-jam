if (!variable_global_exists("iara_morreu"))
{
    global.iara_morreu = false;
}

if (global.iara_morreu)
{
    instance_destroy();
    exit;
}

fase = 1;

botoes_total = 5;
botoes_acertados = 0;

tempo = 60;
tiro_confirmado = false;
botao = irandom(3);

resultado = 0;


// ========================================
// CONTROLE DOS BOTÕES
// ========================================

vezes_x = 0;
vezes_bolinha = 0;
vezes_quadrado = 0;
vezes_triangulo = 0;


// ========================================
// SISTEMA DE TIRO
// ========================================

esperando_tiro = false;
tempo_tiro = 320;


// ========================================
// VIDA DO CURUPIRA
// ========================================

vida_iara = 7;


