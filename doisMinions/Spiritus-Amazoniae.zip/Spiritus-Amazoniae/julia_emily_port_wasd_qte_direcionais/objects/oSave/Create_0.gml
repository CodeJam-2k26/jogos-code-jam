
if (!variable_global_exists("jacare_mensagem_feita"))
{
    global.jacare_mensagem_feita = false;
}

if (!variable_global_exists("mensagem_arma_vista"))
{
    global.mensagem_arma_vista = false;
}
if (!variable_global_exists("partida_atual"))
{
    global.partida_atual = -1;
}

if (!variable_global_exists("municoes_coletadas"))
{
    global.municoes_coletadas = [];
}

if (!variable_global_exists("ervas_coletadas"))
{
    global.ervas_coletadas = [];
}

if (!variable_global_exists("comidas_coletadas"))
{
    global.comidas_coletadas = [];
}

if (!variable_global_exists("evento_capivara_feito"))
{
    global.evento_capivara_feito = false;
}

if (!variable_global_exists("iara_morreu"))
{
    global.iara_morreu = false;
}

if (!variable_global_exists("curupira_fugiu"))
{
    global.curupira_fugiu = false;
}

if (!variable_global_exists("partida_finalizada"))
{
    global.partida_finalizada = false;
}
global.room_morte = inicio;



// =====================================================
// SALVAR PARTIDA
// =====================================================

salvar_partida = function(slot)
{
    var arquivo = "partida" + string(slot) + ".ini";

if (!instance_exists(oCacador))
{
    return false;
}

    ini_open(arquivo);

    // ROOM ATUAL
    ini_write_string(
        "Jogo",
        "sala",
        room_get_name(room)
    );

    // POSIÇÃO DO JOGADOR
    ini_write_real(
        "Jogo",
        "x",
        oCacador.x
    );

    ini_write_real(
        "Jogo",
        "y",
        oCacador.y
    );
	
	//itens acháveis
	ini_write_real(
    "Inventario",
    "municao",
    oCacador.municao
);

var texto_municoes = "";

for (var i = 0; i < array_length(global.municoes_coletadas); i++)
{
    if (i > 0)
    {
        texto_municoes += "|";
    }

    texto_municoes += string(global.municoes_coletadas[i]);
}

ini_write_string(
    "Coletaveis",
    "municoes",
    texto_municoes
);

var texto_ervas = "";

for (var i = 0; i < array_length(global.ervas_coletadas); i++)
{
    if (i > 0)
    {
        texto_ervas += "|";
    }

    texto_ervas += string(global.ervas_coletadas[i]);
}

ini_write_string(
    "Coletaveis",
    "ervas",
    texto_ervas
);

var texto_comidas = "";

for (var i = 0; i < array_length(global.comidas_coletadas); i++)
{
    if (i > 0)
    {
        texto_comidas += "|";
    }

    texto_comidas += string(global.comidas_coletadas[i]);
}

ini_write_string(
    "Coletaveis",
    "comidas",
    texto_comidas
);



ini_write_real(
    "Inventario",
    "ervas",
    oCacador.ervas
);

ini_write_real(
    "Inventario",
    "comida",
    oCacador.comida
);

ini_write_real(
	"Inventario",
	"vida",
	oCacador.vida
);

ini_write_real(
	"Inventario",
	"balas",
	oCacador.balas
);

    // ANIMAIS MORTOS
    ini_write_real(
        "Animais",
        "capivara",
        global.capivara_morreu
    );
	
	ini_write_real(
    "Eventos",
    "capivara",
    global.evento_capivara_feito
);

    ini_write_real(
        "Animais",
        "onca",
        global.onca_morreu
    );

    ini_write_real(
        "Animais",
        "jacare",
        global.jacare_morreu
    );


ini_write_real(
    "Animais",
    "curupira_fugiu",
    global.curupira_fugiu
);

	ini_write_real(
    "Animais",
    "iara",
    global.iara_morreu
);

ini_write_real(
    "Jogo",
    "finalizada",
    global.partida_finalizada
);

ini_write_real(
    "Jogo",
    "tutorial_concluido",
    global.tutorial_concluido
);

var texto_municoes = "";

for (var i = 0; i < array_length(global.municoes_coletadas); i++)
{
    if (i > 0)
    {
        texto_municoes += "|";
    }

    texto_municoes += string(global.municoes_coletadas[i]);
}

ini_write_string(
    "Coletaveis",
    "municoes",
    texto_municoes
);

ini_write_real(
    "Mensagens",
    "jacare",
    global.jacare_mensagem_feita
);

ini_write_real(
    "Mensagens",
    "arma",
    global.mensagem_arma_vista
);

    ini_close();

    global.partida_atual = slot;

    show_debug_message(
        "PARTIDA SALVA COM SUCESSO!"
    );
	return true;
};


// =====================================================
// CARREGAR PARTIDA
// =====================================================

carregar_partida = function(slot)
{
    var arquivo = "partida" + string(slot) + ".ini";

    if (!file_exists(arquivo))
    {

        return false;
    }

    ini_open(arquivo);
	
	var texto_municoes = ini_read_string(
    "Coletaveis",
    "municoes",
    ""
);

global.municoes_coletadas = [];

if (string_length(texto_municoes) > 0)
{
    global.municoes_coletadas = string_split(
        texto_municoes,
        "|"
    );
}

var texto_ervas = ini_read_string(
    "Coletaveis",
    "ervas",
    ""
);

global.ervas_coletadas = [];

if (string_length(texto_ervas) > 0)
{
    global.ervas_coletadas = string_split(
        texto_ervas,
        "|"
    );
}

var texto_comidas = ini_read_string(
    "Coletaveis",
    "comidas",
    ""
);

global.comidas_coletadas = [];


if (string_length(texto_comidas) > 0)
{
    global.comidas_coletadas = string_split(
        texto_comidas,
        "|"
    );
}


// itens acháveis
global.municao_salva = ini_read_real(
    "Inventario",
    "municao",
    0
);

global.ervas_salvas = ini_read_real(
    "Inventario",
    "ervas",
    0
);

global.comida_salva = ini_read_real(
    "Inventario",
    "comida",
    0
);

global.balas_salvas = ini_read_real(
    "Inventario",
    "balas",
    5
);

global.vida_salva = ini_read_real(
    "Inventario",
    "vida",
    5
);
if (instance_exists(oCacador))
{
    oCacador.municao = global.municao_salva;
    oCacador.ervas = global.ervas_salvas;
    oCacador.comida = global.comida_salva;
	oCacador.balas = global.balas_salvas;
    oCacador.vida = global.vida_salva;
}


    // ANIMAIS MORTOS
    global.capivara_morreu = ini_read_real(
        "Animais",
        "capivara",
        false
    );

	global.evento_capivara_feito = ini_read_real(
    "Eventos",
    "capivara",
    false
);

    global.onca_morreu = ini_read_real(
        "Animais",
        "onca",
        false
    );

    global.jacare_morreu = ini_read_real(
        "Animais",
        "jacare",
        false
    );

global.curupira_fugiu = ini_read_real(
    "Animais",
    "curupira_fugiu",
    false
);

global.iara_morreu = ini_read_real(
    "Animais",
    "iara",
    false
);



    // ROOM SALVA
    global.sala_salva = ini_read_string(
        "Jogo",
        "sala",
        "inicio"
    );

    // POSIÇÃO SALVA
    global.x_salvo = ini_read_real(
        "Jogo",
        "x",
        767
    );

    global.y_salvo = ini_read_real(
        "Jogo",
        "y",
        462
    );
	
	global.partida_finalizada = ini_read_real(
    "Jogo",
    "finalizada",
    false
);

global.tutorial_concluido = ini_read_real(
    "Jogo",
    "tutorial_concluido",
    false
);

global.jacare_mensagem_feita =
    ini_read_real(
        "Mensagens",
        "jacare",
        0
    );

global.mensagem_arma_vista =
    ini_read_real(
        "Mensagens",
        "arma",
        0
    );

    ini_close();

global.partida_atual = slot;

global.carregando_partida = true;

var sala = asset_get_index(global.sala_salva);

if (sala != -1)
{
    room_goto(sala);
}
else
{
    show_debug_message(
        "ERRO: ROOM NAO ENCONTRADA!"
    );
}

return true;
};


// =====================================================
// NOVA PARTIDA
// =====================================================

nova_partida = function(slot)
{
    var arquivo = "partida" + string(slot) + ".ini";

    ini_open(arquivo);

    // COMEÇO DA PARTIDA
    ini_write_string(
        "Jogo",
        "sala",
        "inicio"
    );

    ini_write_real(
        "Jogo",
        "x",
        767
    );

    ini_write_real(
        "Jogo",
        "y",
        462
    );

    // ANIMAIS
    ini_write_real(
        "Animais",
        "capivara",
        0
    );
	
	ini_write_real(
    "Eventos",
    "capivara",
    false
);

    ini_write_real(
        "Animais",
        "onca",
        0
    );

    ini_write_real(
        "Animais",
        "jacare",
        false
    );


ini_write_real(
    "Animais",
    "curupira_fugiu",
    false
);

ini_write_real(
    "Animais",
    "iara",
    false
);

ini_write_real(
    "Jogo",
    "finalizada",
    false
);

ini_write_real("Inventario","ervas",0);

ini_write_string(
    "Coletaveis",
    "ervas",
    ""
);

ini_write_real("Inventario","comida",0);

ini_write_string(
    "Coletaveis",
    "comidas",
    ""
);

ini_write_real(
    "Mensagens",
    "jacare",
    false
);

ini_write_real(
    "Mensagens",
    "arma",
    false
);

ini_write_real("Inventario", "municao", 0);
ini_write_real("Inventario", "ervas", 0);
ini_write_real("Inventario", "comida", 0);
ini_write_real("Inventario", "balas", 5);
ini_write_real("Inventario", "vida", 5);


    ini_close();

    // CONFIGURA A PARTIDA ATUAL
    global.partida_atual = slot;

    global.capivara_morreu = false;
	global.evento_capivara_feito = false;
    global.onca_morreu = false;
    global.jacare_morreu = false;
	global.curupira_fugiu = false;
	global.iara_morreu = false;
	global.municao_salva = 0;
	global.ervas_salvas = 0;
	global.comida_salva = 0;
	global.ervas_coletadas = [];
	global.comidas_coletadas = [];
    global.carregando_partida = false;
	global.partida_finalizada = false;
	global.tutorial_concluido = false;
	global.jacare_mensagem_feita = false;
	global.mensagem_arma_vista = false;
	
if (instance_exists(oCacador))
{
    oCacador.municao = 0;
    oCacador.ervas = 0;
    oCacador.comida = 0;

    oCacador.balas = 5;
    oCacador.vida = 5;
}

    room_goto(inicio);
};


// =====================================================
// APAGAR PARTIDA
// =====================================================

apagar_partida = function(slot)
{
    var arquivo = "partida" + string(slot) + ".ini";

    if (file_exists(arquivo))
    {
        file_delete(arquivo);
    }

    if (global.partida_atual == slot)
    {
        global.partida_atual = -1;
    }
};
if (!variable_global_exists("municoes_coletadas"))
{
    global.municoes_coletadas = [];
}