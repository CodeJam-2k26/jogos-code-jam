if (place_meeting(x, y, oCacador))
{
    oCacador.ervas += 1;

    oCacador.mensagem_erva = "+1 erva";
    oCacador.tempo_mensagem = 120;

    array_push(
        global.ervas_coletadas,
        id_erva
    );

    instance_destroy();
    exit;
}