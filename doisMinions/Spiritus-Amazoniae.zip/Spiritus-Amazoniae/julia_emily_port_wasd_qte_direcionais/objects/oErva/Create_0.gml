coletada = false;

id_erva =
    room_get_name(room)
    + "_"
    + string(x)
    + "_"
    + string(y);


if (variable_global_exists("ervas_coletadas"))
{


    for (var i = 0; i < array_length(global.ervas_coletadas); i++)
    {

        if (global.ervas_coletadas[i] == id_erva)
        {
            instance_destroy();
            break;
        }
    }
}