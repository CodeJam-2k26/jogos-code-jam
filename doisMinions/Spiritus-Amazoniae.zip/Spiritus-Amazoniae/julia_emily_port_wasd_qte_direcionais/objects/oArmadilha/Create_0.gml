ativada = false;
qte_ativo = false;
inutilizada = false;
animando = false;