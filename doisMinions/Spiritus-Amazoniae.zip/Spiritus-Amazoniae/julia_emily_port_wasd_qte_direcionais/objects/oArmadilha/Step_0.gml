if (!ativada && !inutilizada)
{
    if (place_meeting(x, y, oCacador))
    {
        ativada = true;
        qte_ativo = true;

        if (!instance_exists(oQTEArmadilha))
        {
            instance_create_layer(
                0,
                0,
                "Instances",
                oQTEArmadilha
            );
        }
    }
}


// ========================================
// VERIFICAR RESULTADO DO QTE
// ========================================

if (qte_ativo && instance_exists(oQTEArmadilha))
{
    if (oQTEArmadilha.sucesso)
    {
        qte_ativo = false;

    }

    if (oQTEArmadilha.falhou)
    {
        qte_ativo = false;
        animando = true;
		
		oCacador.preso_armadilha = true;
		oCacador.tempo_preso = 45;

        sprite_index = sArmadilhaCrec;
        image_index = 0;
        image_speed = 0.2;


    }
}


// ========================================
// ANIMAÇÃO DA ARMADILHA
// ========================================

if (animando)
{
    if (image_index >= image_number - 1)
    {
        image_index = image_number - 1;
        image_speed = 0;

        animando = false;
        inutilizada = true;

    }
}