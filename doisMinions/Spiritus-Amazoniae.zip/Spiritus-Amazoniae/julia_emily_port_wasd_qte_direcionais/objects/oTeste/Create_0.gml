if (!variable_global_exists("item_armadilha"))
{
    global.item_armadilha = false;
}