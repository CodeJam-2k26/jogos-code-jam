if (oCacador.preso_armadilha)
{
    global.item_armadilha = true;

    show_debug_message("ITEM DE ARMADILHA DESBLOQUEADO!");
}