if (!ativo)
{
    return;
}
if (!ativo)
{
    return;
}

tempo -= 1;


// =============================
// VERIFICAR BOTÃO
// =============================

var apertou = false;

if (botao == 0)
{
    if ((gamepad_button_check_pressed(4, gp_face1) || keyboard_check_pressed(vk_up)))
    {
        apertou = true;
    }
}
else if (botao == 1)
{
    if ((gamepad_button_check_pressed(4, gp_face2) || keyboard_check_pressed(vk_down)))
    {
        apertou = true;
    }
}
else if (botao == 2)
{
    if ((gamepad_button_check_pressed(4, gp_face3) || keyboard_check_pressed(vk_left)))
    {
        apertou = true;
    }
}
else if (botao == 3)
{
    if ((gamepad_button_check_pressed(4, gp_face4) || keyboard_check_pressed(vk_right)))
    {
        apertou = true;
    }
}


// =============================
// ACERTOU
// =============================

if (apertou)
{
    sucesso = true;
    ativo = false;

}


// =============================
// ERROU / ACABOU O TEMPO
// =============================

if (tempo <= 0 && ativo)
{
    falhou = true;
    ativo = false;

oCacador.vida -= 1;

audio_play_sound(sndDano, 10, false);

oCacador.tomando_dano = true;
oCacador.sprite_index = sCacadorDano;
oCacador.image_index = 0;
oCacador.image_speed = 0.2;


if (oCacador.vida <= 0)
{
    oCacador.vida = 0;

    global.room_morte = room;

    oCacador.morrendo = true;

    oCacador.morte_frame = 0;
    oCacador.morte_timer = 0;
    oCacador.morte_terminou = false;

    ativo = false;

    show_debug_message(
        "ARMADILHA - JOGADOR MORREU!"
    );

    return;
}
}