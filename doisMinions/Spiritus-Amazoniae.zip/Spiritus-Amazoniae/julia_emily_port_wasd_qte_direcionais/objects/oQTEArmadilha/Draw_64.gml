if (ativo)
{
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_set_color(c_white);

    draw_text(
        display_get_gui_width() / 2,
        250,
        "APERTE"
    );

    // Mostra a tecla de teclado correspondente ao botão do QTE.
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_set_color(c_black);
    draw_rectangle(272, 172, 328, 228, false);
    draw_set_color(c_white);
    draw_rectangle(272, 172, 328, 228, true);
    // Desenha a seta com primitivas gráficas para não depender da fonte Unicode.
    var seta_x = 300;
    var seta_y = 200;
    draw_set_color(c_white);
    if (botao == 0) // CIMA
    {
        draw_line_width(seta_x, seta_y + 10, seta_x, seta_y - 5, 5);
        draw_triangle(seta_x, seta_y - 18, seta_x - 10, seta_y - 4, seta_x + 10, seta_y - 4, false);
    }
    else if (botao == 1) // BAIXO
    {
        draw_line_width(seta_x, seta_y - 10, seta_x, seta_y + 5, 5);
        draw_triangle(seta_x, seta_y + 18, seta_x - 10, seta_y + 4, seta_x + 10, seta_y + 4, false);
    }
    else if (botao == 2) // ESQUERDA
    {
        draw_line_width(seta_x + 10, seta_y, seta_x - 5, seta_y, 5);
        draw_triangle(seta_x - 18, seta_y, seta_x - 4, seta_y - 10, seta_x - 4, seta_y + 10, false);
    }
    else // DIREITA
    {
        draw_line_width(seta_x - 10, seta_y, seta_x + 5, seta_y, 5);
        draw_triangle(seta_x + 18, seta_y, seta_x + 4, seta_y - 10, seta_x + 4, seta_y + 10, false);
    }

    draw_text(
        display_get_gui_width() / 2,
        350,
        string(ceil(tempo / 60))
    );

    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
}