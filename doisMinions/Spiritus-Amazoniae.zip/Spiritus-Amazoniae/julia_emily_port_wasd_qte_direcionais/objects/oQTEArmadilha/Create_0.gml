ativo = true;

tempo = 60;

// 0 = X
// 1 = bolinha
// 2 = quadrado
// 3 = triângulo
botao = irandom(3);

sucesso = false;
falhou = false;