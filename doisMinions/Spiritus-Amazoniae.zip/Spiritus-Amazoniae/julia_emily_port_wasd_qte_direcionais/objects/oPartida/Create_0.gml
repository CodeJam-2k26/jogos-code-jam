show_debug_message(
    "CREATE oPartidas | ROOM: " + room_get_name(room)
);
opcao = 0;
modo_apagar = false;
opcao_apagar = 0;
partida_existe = [false, false, false];
partida_finalizada = [false, false, false];

for (var i = 0; i < 3; i++)
{
    var arquivo = "partida" + string(i + 1) + ".ini";

    partida_existe[i] = file_exists(arquivo);

    if (partida_existe[i])
    {
        ini_open(arquivo);

        partida_finalizada[i] = ini_read_real(
            "Jogo",
            "finalizada",
            false
        );

        ini_close();
    }
}

if (!instance_exists(oCacador))
{
    var cacador = instance_create_layer(
        767,
        462,
        "Instances",
        oCacador
    );

    cacador.visible = false;
}

