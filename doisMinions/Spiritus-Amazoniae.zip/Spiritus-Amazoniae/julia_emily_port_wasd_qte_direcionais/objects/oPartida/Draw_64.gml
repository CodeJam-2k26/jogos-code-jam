var cx = display_get_gui_width() / 2;

draw_set_color(c_white);
// ========================================
// TELA DE APAGAR PARTIDA
// ========================================

if (modo_apagar)
{
    draw_set_color(c_white);

    draw_text(
        cx,
        100,
        "APAGAR PARTIDA"
    );


    // PARTIDA 1
    if (opcao_apagar == 0)
    {
        draw_set_color(c_yellow);
    }
    else
    {
        draw_set_color(c_white);
    }

    draw_text(
        cx,
        220,
        "PARTIDA 1"
    );


    // PARTIDA 2
    if (opcao_apagar == 1)
    {
        draw_set_color(c_yellow);
    }
    else
    {
        draw_set_color(c_white);
    }

    draw_text(
        cx,
        300,
        "PARTIDA 2"
    );


    // PARTIDA 3
    if (opcao_apagar == 2)
    {
        draw_set_color(c_yellow);
    }
    else
    {
        draw_set_color(c_white);
    }

    draw_text(
        cx,
        380,
        "PARTIDA 3"
    );


    // INSTRUÇÃO
    draw_set_color(c_gray);

    draw_text(
        cx,
        500,
        "X - APAGAR    CIRCULO - VOLTAR"
    );

    draw_set_halign(fa_left);
    draw_set_valign(fa_top);

    exit;
}


// ========================================
// DAQUI PARA BAIXO É SUA TELA NORMAL
// ========================================

// =========================
// CONFIGURAÇÕES
// =========================

draw_set_halign(fa_center);
draw_set_valign(fa_middle);



// =========================
// TÍTULO
// =========================

draw_set_color(c_white);

draw_text(
    cx,
    80,
    "PARTIDAS"
);


// =========================
// PARTIDA 1
// =========================

if (opcao == 0)
{
    draw_set_color(c_yellow);
}
else
{
    draw_set_color(c_white);
}

draw_text(
    cx,
    180,
    "PARTIDA 1"
);

if (partida_existe[0])
{
    draw_set_color(c_white);

    if (partida_finalizada[0])
    {
        draw_text(
            cx,
            205,
            "FINALIZADA"
        );
    }
    else
    {
        draw_text(
            cx,
            205,
            "CONTINUAR"
        );
    }
}
else
{
    draw_set_color(c_gray);

    draw_text(
        cx,
        205,
        "VAZIO"
    );
}


// =========================
// PARTIDA 2
// =========================

if (opcao == 1)
{
    draw_set_color(c_yellow);
}
else
{
    draw_set_color(c_white);
}

draw_text(
    cx,
    270,
    "PARTIDA 2"
);

if (partida_existe[1])
{
    draw_set_color(c_white);

    if (partida_finalizada[1])
    {
        draw_text(
            cx,
            295,
            "FINALIZADA"
        );
    }
    else
    {
        draw_text(
            cx,
            295,
            "CONTINUAR"
        );
    }
}
else
{
    draw_set_color(c_gray);

    draw_text(
        cx,
        295,
        "VAZIO"
    );
}


// =========================
// PARTIDA 3
// =========================

if (opcao == 2)
{
    draw_set_color(c_yellow);
}
else
{
    draw_set_color(c_white);
}

draw_text(
    cx,
    360,
    "PARTIDA 3"
);

if (partida_existe[2])
{
    draw_set_color(c_white);

    if (partida_finalizada[2])
    {
        draw_text(
            cx,
            385,
            "FINALIZADA"
        );
    }
    else
    {
        draw_text(
            cx,
            385,
            "CONTINUAR"
        );
    }
}
else
{
    draw_set_color(c_gray);

    draw_text(
        cx,
        385,
        "VAZIO"
    );
}


// =========================
// NOVA PARTIDA
// =========================

if (opcao == 3)
{
    draw_set_color(c_yellow);
}
else
{
    draw_set_color(c_white);
}

draw_text(
    cx,
    470,
    "NOVA PARTIDA"
);


// =========================
// APAGAR PARTIDA
// =========================

if (opcao == 4)
{
    draw_set_color(c_yellow);
}
else
{
    draw_set_color(c_white);
}

draw_text(
    cx,
    500,
    "APAGAR PARTIDA"
);

// =========================
// VOLTAR
// =========================

if (opcao == 5)
{
    draw_set_color(c_yellow);
}
else
{
    draw_set_color(c_white);
}

draw_text(
    cx,
    550,
    "VOLTAR"
);


// =========================
// RESET
// =========================

draw_set_color(c_white);
draw_set_halign(fa_left);
draw_set_valign(fa_top);
