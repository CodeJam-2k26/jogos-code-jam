
// ========================================
// SÓ FUNCIONA NA ROOM ESCOLHA
// ========================================

if (room != escolha)
{
    exit;
}


// ========================================
// VERIFICA QUAIS PARTIDAS EXISTEM
// ========================================

partida_existe = [false, false, false];
partida_finalizada = [false, false, false];

for (var i = 0; i < 3; i++)
{
    var arquivo = "partida" + string(i + 1) + ".ini";

    partida_existe[i] = file_exists(arquivo);

    if (partida_existe[i])
    {
        ini_open(arquivo);

        partida_finalizada[i] = ini_read_real(
            "Jogo",
            "finalizada",
            false
        );

        ini_close();
    }
}

// ========================================
// MODO APAGAR
// ========================================

if (modo_apagar)
{
    if ((gamepad_button_check_pressed(4, gp_padd) || keyboard_check_pressed(vk_down) || keyboard_check_pressed(ord("S"))))
    {
        opcao_apagar += 1;

        if (opcao_apagar > 2)
        {
            opcao_apagar = 0;
        }
		
		    audio_play_sound(sndMenu, 10, false);
    }

    if ((gamepad_button_check_pressed(4, gp_padu) || keyboard_check_pressed(vk_up) || keyboard_check_pressed(ord("W"))))
    {
        opcao_apagar -= 1;

        if (opcao_apagar < 0)
        {
            opcao_apagar = 2;
        }
		
		    audio_play_sound(sndMenu, 10, false);
    }


    // ====================================
    // BOTÃO X - APAGAR
    // ====================================

    if ((gamepad_button_check_pressed(4, gp_face1) || keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space)))
    {
		audio_play_sound(sndMenu, 10, false);
		
        var slot = opcao_apagar + 1;

        if (partida_existe[opcao_apagar])
        {
            oSave.apagar_partida(slot);

            show_debug_message(
                "PARTIDA " + string(slot) + " APAGADA!"
            );

            partida_existe[opcao_apagar] = false;

            modo_apagar = false;
            opcao = 0;
        }
        else
        {
            show_debug_message(
                "PARTIDA " + string(slot) + " ESTA VAZIA!"
            );
        }
    }


    // ====================================
    // BOTÃO CÍRCULO - VOLTAR
    // ====================================

    if ((gamepad_button_check_pressed(4, gp_face2) || keyboard_check_pressed(vk_escape) || keyboard_check_pressed(vk_backspace)))
    {
		audio_play_sound(sndMenu, 10, false);
		
        modo_apagar = false;
        opcao = 0;
    }

    exit;
}


// ========================================
// MENU NORMAL
// ========================================

// BAIXO
if ((gamepad_button_check_pressed(4, gp_padd) || keyboard_check_pressed(vk_down) || keyboard_check_pressed(ord("S"))))
{
    opcao += 1;

    if (opcao > 5)
    {
        opcao = 0;
    }
	
	audio_play_sound(sndMenu, 10, false);
}


// CIMA
if ((gamepad_button_check_pressed(4, gp_padu) || keyboard_check_pressed(vk_up) || keyboard_check_pressed(ord("W"))))
{
    opcao -= 1;

    if (opcao < 0)
    {
        opcao = 5;
    }

    audio_play_sound(sndMenu, 10, false);
}


// ========================================
// BOTÃO X
// ========================================

if ((gamepad_button_check_pressed(4, gp_face1) || keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space)))
{
    audio_play_sound(sndMenu, 10, false);

    // ====================================
    // PARTIDA 1
    // ====================================

if (opcao == 0)
{
    if (partida_existe[0])
    {
        if (partida_finalizada[0])
        {
            show_debug_message("PARTIDA 1 JA FOI FINALIZADA!");
        }
        else
        {
            oSave.carregar_partida(1);
        }
    }
    else
    {
        show_debug_message("PARTIDA 1 ESTA VAZIA");
    }
}


    // ====================================
    // PARTIDA 2
    // ====================================

else if (opcao == 1)
{
    if (partida_existe[1])
    {
        if (partida_finalizada[1])
        {
            show_debug_message("PARTIDA 2 JA FOI FINALIZADA!");
        }
        else
        {
            oSave.carregar_partida(2);
        }
    }
    else
    {
        show_debug_message("PARTIDA 2 ESTA VAZIA");
    }
}


    // ====================================
    // PARTIDA 3
    // ====================================
else if (opcao == 2)
{
    if (partida_existe[2])
    {
        if (partida_finalizada[2])
        {
            show_debug_message("PARTIDA 3 JA FOI FINALIZADA!");
        }
        else
        {
            oSave.carregar_partida(3);
        }
    }
    else
    {
        show_debug_message("PARTIDA 3 ESTA VAZIA");
    }
}

    // ====================================
    // NOVA PARTIDA
    // ====================================

    else if (opcao == 3)
    {
        if (!partida_existe[0])
        {
            oSave.nova_partida(1);
        }
        else if (!partida_existe[1])
        {
            oSave.nova_partida(2);
        }
        else if (!partida_existe[2])
        {
            oSave.nova_partida(3);
        }
        else
        {
            show_debug_message(
                "TODOS OS SLOTS ESTAO OCUPADOS"
            );
        }
    }


    // ====================================
    // APAGAR PARTIDA
    // ====================================

    else if (opcao == 4)
    {
        modo_apagar = true;
        opcao_apagar = 0;

        show_debug_message(
            "MODO APAGAR ATIVADO"
        );
    }
else if (opcao == 5)
{
    global.veio_da_tela_final = true;

    if (instance_exists(oCutsceneFinal))
    {
        instance_destroy(oCutsceneFinal);
    }

    room_goto(menu);
}
}


