

if (global.onca_morreu)
{
    instance_destroy();
    exit;
}

if (room == cont12 && global.etapa_onca >= 13)
{
    instance_destroy();
}

if (room == cont13 && global.etapa_onca >= 14)
{
    instance_destroy();
}

if (room == cont14 && global.etapa_onca >= 15)
{
    instance_destroy();
}




