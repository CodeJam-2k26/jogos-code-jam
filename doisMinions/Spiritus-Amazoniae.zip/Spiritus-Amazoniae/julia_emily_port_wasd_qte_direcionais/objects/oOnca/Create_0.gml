velv = 7;
fugindo = true;
morte = false;
onca_vulneravel = false;
morrendo = false;
timer_morte = 0;
velocidade_morte = 2;
if (!variable_global_exists("etapa_onca"))
{
    global.etapa_onca = 5;
}

if (!variable_global_exists("onca_morreu"))
{
    global.onca_morreu = false;
}

if (room == cont15)
{
    sprite_index = sOncaResp;
	image_speed = 0.3;
    image_index = 0;
}
else
{
    sprite_index = sOncaCorre;
    image_speed = 0.3;
}
image_xscale = 3;
image_yscale = 3;
sprite_morte = sOncaMorre;
sprite_parada = sOncaResp;
sprite_correndo = sOncaCorre;
qte_ja_parou = false;
debug_sprite_resp = false;