
// Começar a animação de morte
if (morte && !morrendo)
{
    morrendo = true;
    global.onca_morreu = true;

    sprite_index = sprite_morte;
    image_index = 0;
    image_speed = 1;
	y -= 180;
	    audio_play_sound(sndCacadorMorre, 10, false);

    if (instance_exists(oQTEOnca))
    {
        with (oQTEOnca)
        {
            instance_destroy();
        }
    }
}


// Enquanto estiver morrendo
if (morrendo)
{
    if (image_index >= image_number - 1)
    {
        oSave.salvar_partida(global.partida_atual);
        instance_destroy();
		audio_play_sound(sndIara, 10, false);
    }

    exit;
}

// Avançar o progresso das salas anteriores
if (room == cont12 && x >= room_width - 20)
{
    global.etapa_onca = 13;
}

if (room == cont13 && x >= room_width - 20)
{
    global.etapa_onca = 14;
}


// Movimento da Onça

if (room == cont15)
{
    fugindo = false;

    if (sprite_index != sprite_parada)
    {
        sprite_index = sprite_parada;
        image_index = 0;
    }

    // Animar a onça respirando enquanto fica parada
    image_speed = 0.3;

    visible = true;
    image_alpha = 1;
    image_xscale = 3;
    image_yscale = 3;
}
else
{
    fugindo = true;

    if (sprite_index != sprite_correndo)
    {
        sprite_index = sprite_correndo;
        image_index = 0;
    }

    image_speed = 0.3;

    x += velv;
}

