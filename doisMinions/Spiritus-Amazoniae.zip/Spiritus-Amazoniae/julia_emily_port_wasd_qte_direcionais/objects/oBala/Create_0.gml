coletada = false;

id_municao =
    room_get_name(room)
    + "_"
    + string(x)
    + "_"
    + string(y);

show_debug_message(
    "MUNICAO CRIADA: " + id_municao
);

if (variable_global_exists("municoes_coletadas"))
{
    show_debug_message(
        "QUANTIDADE NA LISTA: "
        + string(array_length(global.municoes_coletadas))
    );

    for (var i = 0; i < array_length(global.municoes_coletadas); i++)
    {
        show_debug_message(
            "LISTA[" + string(i) + "]: "
            + string(global.municoes_coletadas[i])
        );

        if (global.municoes_coletadas[i] == id_municao)
        {
            instance_destroy();
            break;
        }
    }
}