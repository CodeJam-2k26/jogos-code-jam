if (place_meeting(x, y, oCacador))
{
    oCacador.municao += 1;
show_debug_message(
    "MUNICAO NO INVENTARIO APOS COLETAR: "
    + string(oCacador.municao)
);
    oCacador.mensagem_municao = "+1 munição";
    oCacador.tempo_mensagem = 120;

    array_push(
        global.municoes_coletadas,
        id_municao
    );

    show_debug_message(
        "MUNICAO COLETADA: " + id_municao
    );

    instance_destroy();
    exit;
}