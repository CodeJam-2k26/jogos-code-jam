velocidade = 3;
fugindo = false;

image_speed = 0;