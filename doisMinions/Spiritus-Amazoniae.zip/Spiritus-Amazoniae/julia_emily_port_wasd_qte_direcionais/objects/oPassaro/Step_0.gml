// Verifica se existe um tiro na sala
if (!fugindo && instance_exists(oProjetil))
{
    fugindo = true;
}

if (fugindo)
{
    // Animação do voo
    sprite_index = sPassVoa;
    image_speed = 0.25;

    // Foge para o lado contrário do caçador
    if (oCacador.x < x)
    {
        x += velocidade;
        image_xscale = 1;
    }
    else
    {
        x -= velocidade;
        image_xscale = -1;
    }
}
else
{
    // Fica parado
    image_speed = 0;
    image_index = 0;
	sprite_index = sPassaro;
}