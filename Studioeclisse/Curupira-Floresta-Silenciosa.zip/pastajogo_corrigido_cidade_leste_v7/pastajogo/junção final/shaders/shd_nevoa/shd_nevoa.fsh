varying vec2 v_vTexcoord;
varying vec4 v_vColour;

precision mediump float;                                                  

uniform float u_time;
uniform vec2 u_resolution;

float hash(vec2 p) {
    p = vec2(dot(p, vec2(127.1, 311.7)), dot(p, vec2(269.5, 183.3)));
    return fract(sin(p.x + p.y) * 43758.5453123);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
    float v = 0.0;
    float a = 0.5;
    vec2 shift = vec2(100.0);
    for (int i = 0; i < 4; ++i) {
        v += a * noise(p);
        p = p * 2.0 + shift;
        a *= 0.5;
    }
    return v;
}

void main() {
                                                                        
    vec2 st = v_vTexcoord * 3.0; 
    
                                               
    vec2 q = vec2(0.0);
    q.x = fbm(st + 0.1 * u_time);
    q.y = fbm(st + vec2(1.0));

    vec2 r = vec2(0.0);
    r.x = fbm(st + 1.0 * q + vec2(1.7, 9.2) + 0.15 * u_time);
    r.y = fbm(st + 1.0 * q + vec2(8.3, 2.8) + 0.1 * u_time);

    float f = fbm(st + r);

                   
    vec3 fog_color = mix(vec3(0.1, 0.15, 0.12), vec3(0.65, 0.72, 0.68), clamp(f * f * 3.0, 0.0, 1.0));
    
                                
    float alpha = clamp(f * 0.45, 0.0, 0.55);

                                                  
    vec4 texColor = texture2D(gm_BaseTexture, v_vTexcoord);
    gl_FragColor = vec4(mix(texColor.rgb, fog_color, alpha), texColor.a);
}