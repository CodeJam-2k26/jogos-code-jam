var near_player = distance_to_object(obj_player_unificado) <= interact_range;

if (near_player && keyboard_check_pressed(ord("E"))) {
    room_goto(rm_casa_1);
}