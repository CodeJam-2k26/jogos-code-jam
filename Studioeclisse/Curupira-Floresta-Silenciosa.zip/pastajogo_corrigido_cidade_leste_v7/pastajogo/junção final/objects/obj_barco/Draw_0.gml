draw_set_font(yes);
draw_self();

var near_player = point_distance(x, y, obj_player_unificado.x, obj_player_unificado.y) <= interact_range;

if (near_player) {
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_set_color(c_white);
    if (global.hunters_called >= 3) {
        draw_text(x, y - 50, "Aperte E para embarcar");
    } else {
        draw_text(x, y - 50, "Chame os outros caçadores primeiro (" + string(global.hunters_called) + "/3)");
    }
}
