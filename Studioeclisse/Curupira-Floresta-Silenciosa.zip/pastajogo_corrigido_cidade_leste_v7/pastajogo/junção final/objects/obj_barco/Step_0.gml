var near_player = point_distance(x, y, obj_player_unificado.x, obj_player_unificado.y) <= interact_range;

if (near_player && keyboard_check_pressed(ord("E")) && global.hunters_called >= 3) {
    room_goto(rm_cutscene_parte1b);
}