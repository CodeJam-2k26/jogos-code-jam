
draw_set_font(yes);
draw_set_halign(fa_center);
draw_set_valign(fa_middle);


var alpha_val = (sin(current_time / 300) + 1) / 2;


draw_set_color(c_white);
draw_set_alpha(alpha_val);


var centro_x = display_get_gui_width() / 2;
var centro_y = display_get_gui_height() - 100; 

draw_text(centro_x, centro_y, "Aperte qualquer botão para começar");


draw_set_alpha(1);
draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_set_font(yes);
