draw_set_font(yes);
var gui_w = display_get_gui_width();
var gui_h = display_get_gui_height();


if (sprite_exists(spr_tittle)) {
    draw_sprite_ext(spr_tittle, 0, gui_w / 2, gui_h / 2, 1, 1, 0, c_white, 1);
}


draw_set_font(yes);
draw_set_halign(fa_center);
draw_set_valign(fa_middle);

var alpha_val = (sin(current_time / 300) + 1) / 2;

draw_set_color(c_white);
draw_set_alpha(alpha_val);

draw_text(gui_w / 2, gui_h - 100, "Aperte qualquer botão para começar");


draw_set_alpha(1);
draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_set_font(yes);
