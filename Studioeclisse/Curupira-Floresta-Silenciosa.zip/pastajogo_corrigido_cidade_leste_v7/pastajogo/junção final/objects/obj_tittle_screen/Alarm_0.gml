texto_visivel = !texto_visivel;
alarm[0] = 30;                     