                                                    
texto_visivel = true;
alarm[0] = 30;                                                 
pode_clicar = true;