                                                                   
if (pode_clicar && (keyboard_check_pressed(vk_anykey) || mouse_check_button_pressed(mb_any)))
{
    pode_clicar = false;
    room_goto(rm_cutscene_intro);
}