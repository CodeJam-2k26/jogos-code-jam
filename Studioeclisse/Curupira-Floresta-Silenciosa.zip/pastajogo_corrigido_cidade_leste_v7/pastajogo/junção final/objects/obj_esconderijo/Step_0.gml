var near_player = point_distance(x, y, obj_player_unificado.x, obj_player_unificado.y) <= 60;
if (global.casa_alerta && !global.player_hidden && near_player && keyboard_check_pressed(ord("E"))) {
    global.player_hidden = true;
    obj_player_unificado.visible = false;
    obj_player_unificado.can_move = false;
}