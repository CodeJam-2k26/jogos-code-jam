                                                    
if (!global.em_cutscene) 
{
	                                                             
	var _lay = layer_get_id("Instances");
	if (_lay != -1 && layer != _lay)
	{
    layer = _lay;
    show_debug_message("player movido para Instances | depth " + string(layer_get_depth(_lay)) + " | sala " + room_get_name(room));
}
                        
    if (spawn_lado != "" && room == spawn_room) 
    {
        var _m = 24;
        switch (spawn_lado) 
        {
            case "direita":  x = _m; break;
            case "esquerda": x = room_width - _m; break;
            case "cima":     y = room_height - _m; break;
            case "baixo":    y = _m; break;
        }
        spawn_lado = "";
    }

                                                
    var _key_right = keyboard_check(vk_right);
    var _key_left  = keyboard_check(vk_left);
    var _key_down   = keyboard_check(vk_down);
    var _key_up     = keyboard_check(vk_up);

                      
    var _dir_x = _key_right - _key_left;
    var _dir_y = _key_down - _key_up;

    var _hspd = _dir_x * vel;
    var _vspd = _dir_y * vel;

                                                     
                            
    if (_dir_x != 0 || _dir_y != 0)
    {
        if (_dir_y < 0)
        {
            sprite_index = spr_player_costa_walk;
            dir_olhar = 1;          
        }
        else if (_dir_y > 0)
        {
            sprite_index = spr_player_walk;                              
            dir_olhar = 2;          
        }
        else if (_dir_x < 0)
        {
            sprite_index = spr_player_lado_esquerdo_1_walk;                                 
            dir_olhar = 3;            
        }
        else if (_dir_x > 0)
        {
            sprite_index = spr_player_lado_walk;                                
            dir_olhar = 4;           
        }
    }
                        
    else
    {
        switch (dir_olhar)
        {
            case 1: sprite_index = spr_player_costa; break;                    
            case 2: sprite_index = spr_player_frente; break;                        
            case 3: sprite_index = spr_player_lado_esquerdo; break;                             
            case 4: sprite_index = spr_player_lado; break;                           
        }
    }

                                    
    if (place_meeting(x + _hspd, y, obj_pai_colision))
    {
        while (!place_meeting(x + sign(_hspd), y, obj_pai_colision))
        {
            x = x + sign(_hspd);
        }
        _hspd = 0;
    }
    x += _hspd;

                                  
    if (place_meeting(x, y + _vspd, obj_pai_colision))
    {
        while (!place_meeting(x, y + sign(_vspd), obj_pai_colision))
        {
            y = y + sign(_vspd);
        }
        _vspd = 0;
    }
    y += _vspd;

                                                    
    
                          
    var _porta = instance_nearest(x, y, obj_porta);
    if (_porta != noone && distance_to_object(_porta) < 16)
    {
        if (keyboard_check_pressed(ord("E")))
        {
            room_goto(_porta.proxima_sala);
        }
    }

                                              
    var _cadeira = instance_nearest(x, y, obj_cadeira);
    if (_cadeira != noone && distance_to_object(_cadeira) < 16)
    {
        if (keyboard_check_pressed(ord("E")) && !global.cutscene_bar_feita)
        {
            x = _cadeira.x;
            y = _cadeira.y;
            instance_create_layer(x, y, "Instances", obj_cutscene_bar);
        }
    }

                         
    var _casa = instance_nearest(x, y, obj_casa_player);
    if (_casa != noone && distance_to_object(_casa) < 16)
    {
        if (keyboard_check_pressed(ord("E")))
        {
            room_goto(rm_dentro_casa);
        }
    }
	
	                      
    var _bar = instance_nearest(x, y, obj_bar);
    if (_bar != noone && distance_to_object(_bar) < 16)
    {
        if (keyboard_check_pressed(ord("E")))
        {
            room_goto(rm_cutscene_bar);
        }
    }
	
	                       
    var _casa = instance_nearest(x, y, obj_casa);
    if (_casa != noone && distance_to_object(_casa) < 16)
    {
        if (keyboard_check_pressed(ord("E")))
        {
            room_goto(rm_dentro_casa);
        }
    }
	
	                        
    var _barco = instance_nearest(x, y, obj_barco_vapor);
    if (_barco != noone && distance_to_object(_barco) < 16)
    {
        if (keyboard_check_pressed(ord("E")))
        {
            room_goto(rm_acampamento);
        }
    }
	
	                                   
if (keyboard_check_pressed(ord("E")) || keyboard_check_pressed(vk_space)) {
    

    var _itens = [obj_parafuso, obj_engrenagem, obj_correa];
    
    for (var i = 0; i < array_length(_itens); i++) {
        var _inst = instance_nearest(x, y, _itens[i]);
        
                                                                           
        if (_inst != noone && point_distance(x, y, _inst.x, _inst.y) <= 32) {
            
                                                     
            if (instance_exists(obj_game_controller)) {
                obj_game_controller.itens_coletados += 1;
            }
            
                                              
            instance_destroy(_inst);
            break;                                        
        }
    }
}
	
}
