draw_set_font(yes);

draw_self();


if (!global.em_cutscene)
{

    var _porta   = instance_nearest(x, y, obj_porta);
    var _cadeira = instance_nearest(x, y, obj_cadeira);
   


    var _objeto_perto = noone;

    if (_porta != noone && distance_to_object(_porta) < 20)     _objeto_perto = _porta;
    if (_cadeira != noone && distance_to_object(_cadeira) < 20) _objeto_perto = _cadeira;
   
    if (_objeto_perto != noone)
    {
     
        var _draw_x = _objeto_perto.x;
        var _draw_y = _objeto_perto.y - 25; 

      
        var _hint_text = "Aperte E";
var _hint_scale = 0.75;
        var _hint_w = string_width(_hint_text) * _hint_scale;
var _hint_h = string_height(_hint_text) * _hint_scale;
draw_set_halign(fa_center);
draw_set_valign(fa_middle);
draw_set_alpha(0.75);
draw_set_color(c_black);
draw_roundrect(_draw_x - _hint_w * 0.5 - 2, _draw_y - _hint_h * 0.5 - 1, _draw_x + _hint_w * 0.5 + 2, _draw_y + _hint_h * 0.5 + 1, false);
draw_set_alpha(1);
draw_set_color(c_white);
draw_text_transformed(_draw_x, _draw_y, _hint_text, _hint_scale, _hint_scale, 0);
draw_set_halign(fa_left);
draw_set_valign(fa_top);
    }
}



                                                                          
if (global.txt_aviso > 0)
{
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    
    var _scale = 0.50;
    var _padding_x = 2;
    var _padding_y = 1;
    
                                    
    var _text_w = string_width(mensagem) + (_padding_x * 2);
    var _text_h = string_height(mensagem) + (_padding_y * 2);
    
                                                      
    var _cam_x = camera_get_view_x(view_camera[0]);
    var _cam_y = camera_get_view_y(view_camera[0]);
    var _cam_w = camera_get_view_width(view_camera[0]);
    var _cam_h = camera_get_view_height(view_camera[0]);
    
                                                                        
    var _text_x = _cam_x + (_cam_w / 2);
    var _text_y = _cam_y + _cam_h - (_text_h / 2) - 8;                                  
    
                                      
    var _x1 = _text_x - (_text_w / 2);
    var _y1 = _text_y - (_text_h / 2);
    var _x2 = _text_x + (_text_w / 2);
    var _y2 = _text_y + (_text_h / 2);

                                    
    draw_set_color(c_black);
    draw_set_alpha(0.85);
    draw_roundrect_ext(_x1, _y1, _x2, _y2, 3, 3, false);

                                        
    draw_set_color(c_white);
    draw_set_alpha(1.0);
    draw_roundrect_ext(_x1, _y1, _x2, _y2, 3, 3, true);

                             
    draw_set_color(c_white);
    draw_text_transformed(_text_x, _text_y, mensagem, _scale, _scale, 0);
    
                                     
    global.txt_aviso--;
    
                                   
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
}

draw_self();
