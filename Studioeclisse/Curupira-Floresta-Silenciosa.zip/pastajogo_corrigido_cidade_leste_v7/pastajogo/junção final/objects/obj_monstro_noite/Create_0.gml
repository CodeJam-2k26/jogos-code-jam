estado = 0;                                     
vel_patrulha = 0.5;
vel_investiga = 1.5;
alvo_x = x;
alvo_y = y;
espera = 0;
distracao_timer = 0;

pt_x[0] = 200; pt_y[0] = 150;
pt_x[1] = 500; pt_y[1] = 150;
pt_x[2] = 500; pt_y[2] = 400;
pt_x[3] = 200; pt_y[3] = 400;
pt_n = 4;
pt_i = 0;

visao = 220;
vel_persegue = 1;
image_speed = 0.2;
image_xscale = 1;
