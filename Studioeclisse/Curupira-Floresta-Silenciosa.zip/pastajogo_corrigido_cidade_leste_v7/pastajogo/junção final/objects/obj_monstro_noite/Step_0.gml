if(global.player_morto) exit;

if (!variable_instance_exists(id, "distracao_timer")) distracao_timer = 0;
if (distracao_timer > 0) distracao_timer--;

// O Curupira usa a mesma caixa dos pés que o jogador para não atravessar paredes.
var _monster_blocked = function(_px, _py) {
    var _blocks = [obj_wall, obj_wall_fernando, obj_pai_colision,
        obj_block, obj_block_bar, obj_block_bar2, obj_block_cerca,
        obj_block_cidade, obj_block_cidade_npc];
    for (var _i = 0; _i < array_length(_blocks); _i++) {
        if (collision_rectangle(_px - 5, _py - 5, _px + 5, _py,
            _blocks[_i], true, true) != noone) return true;
    }
    return false;
};

                                            
var dist_p = point_distance(x, y, obj_player_unificado.x, obj_player_unificado.y);
var viu = (dist_p <= visao) && !collision_line(x, y, obj_player_unificado.x, obj_player_unificado.y, obj_wall_fernando, false, true);

                               
if (global.barulho_ativo) {
    global.barulho_ativo = false;
    alvo_x = global.barulho_x;
    alvo_y = global.barulho_y;
    estado = 1;
    // Uma pedra dá tempo de chegar ao barulho e investigá-lo. Durante esse
    // tempo, ver o jogador ou ouvir o conserto não substitui o alvo.
    distracao_timer = game_get_speed(gamespeed_fps) * 5;
}

// Uma pedra deve realmente distrair o Curupira. Sem esse bloqueio, o
// conserto do barco sobrescrevia o alvo da pedra no quadro seguinte.
if (distracao_timer <= 0) {
    if (global.consertando) {
        alvo_x = obj_player_unificado.x;
        alvo_y = obj_player_unificado.y;
        estado = 1;
    }

    if (viu) {
        alvo_x = obj_player_unificado.x;
        alvo_y = obj_player_unificado.y;
        estado = 1;
    }
}

var vel_atual = viu ? vel_persegue : vel_investiga;
var _move_dx = 0;
var _move_dy = 0;

switch (estado) {
    case 0:            
        if (point_distance(x, y, pt_x[pt_i], pt_y[pt_i]) <= vel_patrulha) {
            pt_i = (pt_i + 1) mod pt_n;
        } else {
            var d = point_direction(x, y, pt_x[pt_i], pt_y[pt_i]);
            _move_dx = lengthdir_x(vel_patrulha, d);
            _move_dy = lengthdir_y(vel_patrulha, d);
            if (_move_dx != 0 && !_monster_blocked(x + _move_dx, y)) x += _move_dx;
            if (_move_dy != 0 && !_monster_blocked(x, y + _move_dy)) y += _move_dy;
        }
    break;

    case 1:                        
        if (point_distance(x, y, alvo_x, alvo_y) <= vel_atual) {
            estado = 2;
            espera = game_get_speed(gamespeed_fps);
            if (distracao_timer > 0) espera = max(espera, distracao_timer);
        } else {
            var d = point_direction(x, y, alvo_x, alvo_y);
            _move_dx = lengthdir_x(vel_atual, d);
            _move_dy = lengthdir_y(vel_atual, d);
            if (_move_dx != 0 && !_monster_blocked(x + _move_dx, y)) x += _move_dx;
            if (_move_dy != 0 && !_monster_blocked(x, y + _move_dy)) y += _move_dy;
        }
    break;

    case 2:                                        
        espera--;
        if (espera <= 0) {
            estado = 0;
        }
    break;
}

                                                     
if (abs(_move_dx) + abs(_move_dy) > 0) {
    var _sprite_direcao;
    if (abs(_move_dx) > abs(_move_dy)) {
        _sprite_direcao = (_move_dx < 0) ? spr_inimigo_esquerda : spr_inimigo_direita;
        image_xscale = 1;
    } else if (_move_dy >= 0) {
        _sprite_direcao = spr_inimigo_baixo;
        image_xscale = 1;
    } else {
        _sprite_direcao = spr_inimigo_cima;
        image_xscale = 1;
    }

    if (sprite_index != _sprite_direcao) {
        sprite_index = _sprite_direcao;
        image_index = 0;
    }
    image_speed = 0.2;
} else {
    image_speed = 0;
    image_index = 0;
}

                     
if (point_distance(x, y, obj_player_unificado.x, obj_player_unificado.y) < 24) {
    global.player_morto = true;
    global.consertando = false;
    obj_player_unificado.can_move = false;
}
