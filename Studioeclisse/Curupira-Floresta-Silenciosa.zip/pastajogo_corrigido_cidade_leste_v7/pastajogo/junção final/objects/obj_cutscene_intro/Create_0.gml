depth = -50000; // cutscene sempre acima de HUD, aviso, fader e neblina
story_text[0] = "Brasil, Manaus 1853.";
total_pages = 1;
current_page = 0;
fade_alpha = 1;
fade_state = "in";