                                            
if (exiting) exit;

if (keyboard_check_pressed(vk_space) || keyboard_check_pressed(ord("E"))) {
    current_line += 1;

    if (current_line >= total_lines) {
        exiting = true;
        global.is_night = true;
        global.em_cutscene = false;
        global.estado_jogo = "gameplay";
        global.player_hidden = false;
        if (instance_exists(obj_player_unificado)) {
            with (obj_player_unificado) {
                visible = true;
                image_alpha = 1;
                can_move = true;
            }
        }
        // A RoomCreationCode do acampamento posiciona o jogador no ponto
        // correto. Este guard impede que um segundo input envie para outra sala.
        room_goto(rm_acampamento_noite2);
        exit;
    }
}
