depth = -50000; // cutscene sempre acima de HUD, aviso, fader e neblina
global.em_cutscene = true;
global.estado_jogo = "cutscene";
// Igual à versão que funcionava: a noite só começa ao terminar a fala.
// Assim a camada escura do jogador não cobre a interface da cutscene.
global.is_night = false;
exiting = false;

// A interface persistente desenha uma cópia segura da fala na GUI.
if (!instance_exists(obj_aviso)) {
    instance_create_depth(0, 0, -10000, obj_aviso);
}

if (instance_exists(obj_player_unificado)) {
    with (obj_player_unificado) {
        can_move = false;
        visible = true;
        image_alpha = 1;
    }
}

speaker_name[0] = "Caçador 1";
speaker_text[0] = "Pessoal, acordem! O Caçador 4 sumiu e eu escutei um barulho muito alto vindo da floresta!";
speaker_portrait[0] = spr_cacador1_portrait;

speaker_name[1] = "Caçador 2";
speaker_text[1] = "Então vamos procurar por ele antes que algo ruim aconteça.";
speaker_portrait[1] = spr_cacador2_portrait;

total_lines = 2;
current_line = 0;
