// O HUD não pode herdar transparência/cor de outro Draw GUI.
draw_set_alpha(1);
draw_set_color(c_white);
draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_set_font(yes);

// As cenas do barco usam salas sem cenário. Desenhe a caixa de diálogo por
// esta interface persistente também, para ela não ser encoberta por shaders
// ou por objetos que chegam junto com o jogador persistente.
var _cutscene_barco = noone;
if (instance_exists(obj_cutscene_intro_fernando)) {
    _cutscene_barco = instance_find(obj_cutscene_intro_fernando, 0);
} else if (instance_exists(obj_cutscene_parte2_fernando)) {
    _cutscene_barco = instance_find(obj_cutscene_parte2_fernando, 0);
} else if (instance_exists(obj_cutscene_parte3)) {
    _cutscene_barco = instance_find(obj_cutscene_parte3, 0);
} else if (instance_exists(obj_cutscene_parte4)) {
    _cutscene_barco = instance_find(obj_cutscene_parte4, 0);
}

if (_cutscene_barco != noone) {
    var _gui_w = display_get_gui_width();
    var _gui_h = display_get_gui_height();

    draw_set_alpha(1);
    draw_set_color(c_black);
    draw_rectangle(0, 0, _gui_w, _gui_h, false);

    if (_cutscene_barco.current_page < _cutscene_barco.total_pages) {
        draw_set_color(c_white);
        draw_set_halign(fa_center);
        draw_set_valign(fa_middle);
        draw_text_ext(_gui_w * 0.5, _gui_h * 0.5,
            _cutscene_barco.story_text[_cutscene_barco.current_page], -1, _gui_w * 0.72);

        draw_set_valign(fa_bottom);
        draw_text(_gui_w * 0.5, _gui_h - 36, "Pressione ESPAÇO para continuar");
    }

    draw_set_alpha(_cutscene_barco.fade_alpha);
    draw_set_color(c_black);
    draw_rectangle(0, 0, _gui_w, _gui_h, false);

    draw_set_alpha(1);
    draw_set_color(c_white);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    exit;
}

// A cena de transição da vila ocupa a tela inteira. Como algumas rooms de
// transição não desenham de forma confiável o evento Draw do controlador,
// o HUD persistente também desenha esta cena.
var _cutscene_vila = instance_find(obj_cutscene_vila, 0);
if (_cutscene_vila != noone) {
    var _vila_gui_w = display_get_gui_width();
    var _vila_gui_h = display_get_gui_height();

    draw_set_alpha(1);
    draw_set_color(c_black);
    draw_rectangle(0, 0, _vila_gui_w, _vila_gui_h, false);

    draw_set_color(c_white);
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    var _vila_texto = string_copy(_cutscene_vila.texto_narrativa, 1,
        floor(_cutscene_vila.caractere_atual));
    var _vila_largura = max(1, min(_vila_gui_w - 48, _vila_gui_w * 0.82));
    var _vila_altura = string_height_ext(_vila_texto, 16, _vila_largura);
    var _vila_y = clamp(_vila_gui_h * 0.45, 12 + _vila_altura * 0.5,
        _vila_gui_h - 52 - _vila_altura * 0.5);
    draw_text_ext(_vila_gui_w * 0.5, _vila_y, _vila_texto, 16, _vila_largura);

    if (_cutscene_vila.caractere_atual >= string_length(_cutscene_vila.texto_narrativa)) {
        draw_set_color(c_gray);
        draw_text(_vila_gui_w * 0.5, _vila_gui_h - 18,
            "[ Pressione ESPAÇO ou E para continuar ]");
    }

    draw_set_alpha(1);
    draw_set_color(c_white);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    exit;
}

// Parte 5 e lampião: a room pode não desenhar o evento Draw do controlador
// da cena. Como obj_aviso é persistente e usa Draw GUI, ele exibe a mesma
// caixa de fala de forma confiável por cima de qualquer camada da room.
var _cutscene_dialogo = noone;
if (instance_exists(obj_cutscene_parte5)) {
    _cutscene_dialogo = instance_find(obj_cutscene_parte5, 0);
} else if (instance_exists(obj_cutscene_lampiao)) {
    _cutscene_dialogo = instance_find(obj_cutscene_lampiao, 0);
}

if (_cutscene_dialogo != noone) {
    var _dlg_gui_w = display_get_gui_width();
    var _dlg_gui_h = display_get_gui_height();

    draw_set_alpha(1);
    draw_set_color(c_black);
    draw_rectangle(0, 0, _dlg_gui_w, _dlg_gui_h, false);

    if (_cutscene_dialogo.current_line < _cutscene_dialogo.total_lines) {
        var _dlg_margin = min(24, _dlg_gui_w * 0.04);
        var _dlg_box_x1 = _dlg_margin;
        var _dlg_box_x2 = _dlg_gui_w - _dlg_margin;
        var _dlg_portrait_area = min(180, _dlg_gui_w * 0.18);
        var _dlg_text_x = _dlg_box_x1 + _dlg_portrait_area + 20;
        var _dlg_text_w = max(1, _dlg_box_x2 - _dlg_text_x - 16);
        var _dlg_line_sep = max(4, min(8, _dlg_gui_h * 0.012));
        var _dlg_text_h = string_height_ext(_cutscene_dialogo.speaker_text[_cutscene_dialogo.current_line], _dlg_line_sep, _dlg_text_w);
        var _dlg_box_h = min(_dlg_gui_h - 2 * _dlg_margin, max(_dlg_gui_h * 0.22, _dlg_text_h + 70));
        var _dlg_box_y2 = _dlg_gui_h - _dlg_margin;
        var _dlg_box_y1 = _dlg_box_y2 - _dlg_box_h;
        var _dlg_portrait = _cutscene_dialogo.speaker_portrait[_cutscene_dialogo.current_line];
        var _dlg_scale = min(1, min((_dlg_portrait_area - 12) / max(1, sprite_get_width(_dlg_portrait)), (_dlg_box_h - 16) / max(1, sprite_get_height(_dlg_portrait))));

        draw_set_color(c_black);
        draw_set_alpha(0.85);
        draw_roundrect(_dlg_box_x1, _dlg_box_y1, _dlg_box_x2, _dlg_box_y2, false);
        draw_set_alpha(1);
        draw_set_color(c_yellow);
        draw_roundrect(_dlg_box_x1, _dlg_box_y1, _dlg_box_x2, _dlg_box_y2, true);
        draw_roundrect(_dlg_box_x1 - 1, _dlg_box_y1 - 1, _dlg_box_x2 + 1, _dlg_box_y2 + 1, true);

        draw_sprite_ext(_dlg_portrait, 0, _dlg_box_x1 + 6, _dlg_box_y1 + 8, _dlg_scale, _dlg_scale, 0, c_white, 1);

        var _dlg_name_x1 = _dlg_text_x;
        var _dlg_name_y1 = _dlg_box_y1 + 4;
        var _dlg_name_x2 = min(_dlg_box_x2 - 8, _dlg_name_x1 + 160);
        var _dlg_name_y2 = _dlg_box_y1 + 36;
        draw_set_color(c_navy);
        draw_roundrect(_dlg_name_x1, _dlg_name_y1, _dlg_name_x2, _dlg_name_y2, false);
        draw_set_color(c_yellow);
        draw_roundrect(_dlg_name_x1, _dlg_name_y1, _dlg_name_x2, _dlg_name_y2, true);

        draw_set_color(c_white);
        draw_set_halign(fa_center);
        draw_set_valign(fa_middle);
        draw_text((_dlg_name_x1 + _dlg_name_x2) / 2, (_dlg_name_y1 + _dlg_name_y2) / 2, _cutscene_dialogo.speaker_name[_cutscene_dialogo.current_line]);
        draw_set_halign(fa_left);
        draw_set_valign(fa_top);
        draw_text_ext(_dlg_text_x, _dlg_box_y1 + 42, _cutscene_dialogo.speaker_text[_cutscene_dialogo.current_line], _dlg_line_sep, _dlg_text_w);

        if ((current_time div 500) mod 2 == 0) {
            draw_set_halign(fa_right);
            draw_set_valign(fa_bottom);
            draw_text(_dlg_box_x2 - 12, _dlg_box_y2 - 10, "▼");
        }
    }

    draw_set_alpha(1);
    draw_set_color(c_white);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    exit;
}

// A cena da água é uma fala curta sem retrato. Ela recebe o mesmo fundo
// preto, garantindo que a mensagem não dependa da room de transição.
if (instance_exists(obj_cutscene_agua)) {
    var _cutscene_agua = instance_find(obj_cutscene_agua, 0);
    var _agua_gui_w = display_get_gui_width();
    var _agua_gui_h = display_get_gui_height();

    draw_set_alpha(1);
    draw_set_color(c_black);
    draw_rectangle(0, 0, _agua_gui_w, _agua_gui_h, false);
    draw_set_color(c_white);
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_text_ext(_agua_gui_w * 0.5, _agua_gui_h * 0.5,
        "Me lembrei... preciso me encontrar com eles no bar.", -1, _agua_gui_w * 0.7);

    if (_cutscene_agua.exibir_continuar) {
        draw_set_valign(fa_bottom);
        draw_text(_agua_gui_w * 0.5, _agua_gui_h - 40, "Pressione ESPAÇO para continuar");
    }

    draw_set_alpha(1);
    draw_set_color(c_white);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    exit;
}

// A fuga dentro da casa precisa continuar visível mesmo quando a room troca
// a ordem de desenho dos objetos. Esta interface persistente mostra cada
// etapa: aviso do caçador, contador, consequência e transição para a vila.
if (instance_exists(obj_casa_controle)) {
    var _hide_ctrl = instance_find(obj_casa_controle, 0);
    var _hide_w = display_get_gui_width();
    var _hide_h = display_get_gui_height();

    if (_hide_ctrl.state == 1 || _hide_ctrl.state == 5) {
        var _hide_margin = min(24, _hide_w * 0.04);
        var _hide_x1 = _hide_margin;
        var _hide_x2 = _hide_w - _hide_margin;
        var _hide_portrait_w = min(150, _hide_w * 0.16);
        var _hide_text_x = _hide_x1 + _hide_portrait_w + 20;
        var _hide_text_w = max(1, _hide_x2 - _hide_text_x - 16);
        var _hide_sep = clamp(_hide_h * 0.032, 12, 24);
        var _hide_line = _hide_ctrl.dlg_i;
        var _hide_text_h = string_height_ext(_hide_ctrl.dlg_text[_hide_line], _hide_sep, _hide_text_w);
        var _hide_box_h = min(_hide_h - 2 * _hide_margin, max(_hide_h * 0.23, _hide_text_h + 74));
        var _hide_y2 = _hide_h - _hide_margin;
        var _hide_y1 = _hide_y2 - _hide_box_h;
        var _hide_portrait = _hide_ctrl.dlg_port[_hide_line];

        draw_set_alpha(0.88);
        draw_set_color(c_black);
        draw_rectangle(_hide_x1, _hide_y1, _hide_x2, _hide_y2, false);
        draw_set_alpha(1);
        draw_set_color(c_yellow);
        draw_rectangle(_hide_x1, _hide_y1, _hide_x2, _hide_y2, true);

        if (sprite_exists(_hide_portrait)) {
            var _hide_scale = min(1, min((_hide_portrait_w - 8) / max(1, sprite_get_width(_hide_portrait)), (_hide_box_h - 12) / max(1, sprite_get_height(_hide_portrait))));
            draw_sprite_ext(_hide_portrait, 0, _hide_x1 + 4, _hide_y1 + 6, _hide_scale, _hide_scale, 0, _hide_ctrl.dlg_col[_hide_line], 1);
        }

        draw_set_halign(fa_left);
        draw_set_valign(fa_top);
        draw_set_color(c_yellow);
        draw_text(_hide_text_x, _hide_y1 + 12, _hide_ctrl.dlg_name[_hide_line] + ":");
        draw_set_color(c_white);
        draw_text_ext(_hide_text_x, _hide_y1 + 42, _hide_ctrl.dlg_text[_hide_line], _hide_sep, _hide_text_w);
        draw_set_halign(fa_right);
        draw_set_valign(fa_bottom);
        draw_text(_hide_x2 - 12, _hide_y2 - 10, "[ESPAÇO] continuar");
        draw_set_alpha(1);
        draw_set_color(c_white);
        draw_set_halign(fa_left);
        draw_set_valign(fa_top);
        exit;
    }

    if (_hide_ctrl.state == 2) {
        var _hide_secs = max(0, ceil(_hide_ctrl.timer / game_get_speed(gamespeed_fps)));
        draw_set_alpha(0.84);
        draw_set_color(c_black);
        draw_rectangle(12, 12, _hide_w - 12, 86, false);
        draw_set_alpha(1);
        draw_set_halign(fa_center);
        draw_set_valign(fa_top);
        draw_set_color(c_red);
        draw_text(_hide_w * 0.5, 20, "ALERTA! ALGO ESTÁ SE APROXIMANDO!");
        draw_set_color(_hide_secs <= 5 ? c_red : c_yellow);
        draw_text(_hide_w * 0.5, 43, "ESCONDA-SE!  TEMPO: " + string(_hide_secs) + "s");
        draw_set_color(c_white);
        draw_text(_hide_w * 0.5, 65, "Encontre um esconderijo e pressione E");
        draw_set_alpha(1);
        draw_set_color(c_white);
        draw_set_halign(fa_left);
        draw_set_valign(fa_top);
        exit;
    }

    if (_hide_ctrl.state == 4) {
        draw_set_alpha(0.84);
        draw_set_color(c_black);
        draw_rectangle(12, 12, _hide_w - 12, 62, false);
        draw_set_alpha(1);
        draw_set_halign(fa_center);
        draw_set_valign(fa_top);
        draw_set_color(c_yellow);
        draw_text(_hide_w * 0.5, 22, "VOCÊ ESTÁ ESCONDIDO. NÃO FAÇA BARULHO...");
        draw_set_color(c_white);
        draw_text(_hide_w * 0.5, 44, "Aguarde o perigo passar.");
        draw_set_alpha(1);
        draw_set_color(c_white);
        draw_set_halign(fa_left);
        draw_set_valign(fa_top);
        exit;
    }

    if (_hide_ctrl.state == 3) {
        draw_set_alpha(0.9);
        draw_set_color(c_black);
        draw_rectangle(0, 0, _hide_w, _hide_h, false);
        draw_set_alpha(1);
        draw_set_halign(fa_center);
        draw_set_valign(fa_middle);
        draw_set_color(c_red);
        draw_text(_hide_w * 0.5, _hide_h * 0.5 - 46, "VOCÊ MORREU");
        draw_set_color(c_white);
        draw_text(_hide_w * 0.5, _hide_h * 0.5, "O Curupira encontrou você.");
        draw_set_color(c_dkgray);
        draw_rectangle(_hide_w * 0.5 - 90, _hide_h * 0.5, _hide_w * 0.5 + 90, _hide_h * 0.5 + 50, false);
        draw_set_color(c_yellow);
        draw_text(_hide_w * 0.5, _hide_h * 0.5 + 15, "Reiniciar");
        draw_set_alpha(1);
        draw_set_color(c_white);
        draw_set_halign(fa_left);
        draw_set_valign(fa_top);
        exit;
    }

    if (_hide_ctrl.state == 7) {
        draw_set_alpha(1);
        draw_set_color(c_black);
        draw_rectangle(0, 0, _hide_w, _hide_h, false);
        draw_set_color(c_white);
        draw_set_halign(fa_center);
        draw_set_valign(fa_middle);
        draw_text_ext(_hide_w * 0.5, _hide_h * 0.5, "Algum tempo depois, eles chegam à vila.", 8, max(1, _hide_w - 32));
        draw_set_color(c_gray);
        draw_set_valign(fa_bottom);
        draw_text(_hide_w * 0.5, _hide_h - 18, "[ESPAÇO] continuar");
        draw_set_alpha(1);
        draw_set_color(c_white);
        draw_set_halign(fa_left);
        draw_set_valign(fa_top);
        exit;
    }
}

var _texto = "";

// A vila é uma etapa própria. Ela precisa prevalecer sobre objetivos antigos
// quando o jogador chega por uma troca de sala ou abre a room diretamente.
if (room == rm_vila && instance_exists(obj_control_vila))
{
    var _controle_vila_hud = instance_find(obj_control_vila, 0);
    if (!_controle_vila_hud.game_over)
    {
        if (_controle_vila_hud.itens_coletados < _controle_vila_hud.total_itens_necessarios)
        {
            _texto = "Objetivo: Encontrar peças (" + string(_controle_vila_hud.itens_coletados) + "/" + string(_controle_vila_hud.total_itens_necessarios) + ")";
        }
        else
        {
            _texto = "Objetivo: Siga para o acampamento pela direita";
        }
    }
}
else if (global.quest == 0)
{
    _texto = "Objetivo: Beba água na mesa";
    if (place_meeting(x, y, obj_player_unificado))
    {
        _texto = "Objetivo: Beba água na mesa";
    }
	
	
}
else if (global.quest == 1)
{
    _texto = "Objetivo: Vá até o bar";
}

else if (global.quest == 2)
{
	_texto = "Objetivo: Vá até o barco";
}
else if (room == rm_final1 || room == rm_fim)
{
    // Sem objetivo durante o encerramento.
}
else if (room == rm_acampamento_noite3)
{
    _texto = "Objetivo: Consertar o barco (" + string(global.barco_consertos) + "/3)";
}
else if (!global.objective_done)
{
    _texto = "Objetivo: Derrubar árvores (" + string(global.trees_cut) + "/" + string(global.trees_goal) + ")";
}
else if (!global.wood_delivered)
{
    _texto = "Objetivo: Levar a madeira até o barco";
}
else if (global.camp_stage == 0 && !global.camp_has_wood)
{
    _texto = "Objetivo: Pegar a madeira no barco";
}
else if (global.camp_stage == 0 && global.camp_has_wood)
{
    _texto = "Objetivo: Levar a madeira até a fogueira";
}
else if (global.camp_stage == 1)
{
    _texto = "Objetivo: Assar a carne";
}
else if (global.camp_stage == 2)
{
    _texto = "Objetivo: Pegar a carne assada";
}
else if (global.camp_stage == 3)
{
    _texto = "Objetivo: Comer com os amigos";
}
else if (global.camp_stage == 4)
{
    _texto = "Objetivo: Apagar a fogueira";
}
else if (global.camp_stage == 5 && !global.has_slept)
{
    _texto = "Objetivo: Ir dormir";
}
else if (global.has_slept && !global.arrived_at_cabin2)
{
    _texto = "Objetivo: Vá até a outra cabana";
}
else if (global.arrived_at_cabin2 && !global.lamp_analyzed)
{
    _texto = "Objetivo: Procure seu parceiro";
}
else if (global.casa_stage == 1)
{
    _texto = "Objetivo: Explorar a casa";
}
else if (global.casa_stage == 2)
{
    _texto = "Objetivo: Esconda-se!";
}
else if (global.casa_stage == 3)
{
    _texto = "Objetivo: Ir até a vila";
}
else if (global.lamp_analyzed)
{
    _texto = "Objetivo: Entrar na casa";
}


                                      
// Interface própria da coleta na vila. Ela fica no HUD persistente para
// continuar visível mesmo quando a sala é aberta diretamente ou o controlador
// temporário ainda está sendo criado.
if (room == rm_vila && instance_exists(obj_control_vila))
{
    var _vila_ctrl = instance_find(obj_control_vila, 0);
    var _vila_w = display_get_gui_width();
    var _vila_h = display_get_gui_height();
    var _vila_min = floor(_vila_ctrl.tempo_restante / 60);
    var _vila_seg = floor(_vila_ctrl.tempo_restante mod 60);
    var _vila_min_s = (_vila_min < 10) ? "0" + string(_vila_min) : string(_vila_min);
    var _vila_seg_s = (_vila_seg < 10) ? "0" + string(_vila_seg) : string(_vila_seg);
    var _vila_status = "Peças: " + string(_vila_ctrl.itens_coletados) + "/" + string(_vila_ctrl.total_itens_necessarios);
    if (!_vila_ctrl.saida_liberada) _vila_status += "    Tempo: " + _vila_min_s + ":" + _vila_seg_s;

    draw_set_font(yes);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_alpha(0.65);
    draw_set_color(c_black);
    draw_rectangle(14, 52, min(_vila_w - 14, 14 + string_width(_vila_status) + 14), 82, false);
    draw_set_alpha(1);
    draw_set_color((_vila_ctrl.tempo_restante <= 60 && !_vila_ctrl.saida_liberada) ? c_red : c_white);
    draw_text(20, 58, _vila_status);

    if (_vila_ctrl.game_over)
    {
        draw_set_alpha(0.88);
        draw_set_color(c_black);
        draw_rectangle(0, 0, _vila_w, _vila_h, false);
        draw_set_alpha(1);
        draw_set_halign(fa_center);
        draw_set_valign(fa_middle);
        draw_set_color(c_red);
        draw_text_ext(_vila_w * 0.5, _vila_h * 0.5, "VOCÊ FOI PEGO PELO CURUPIRA!", -1, max(1, _vila_w - 32));
        draw_set_color(c_dkgray);
        draw_rectangle(_vila_w * 0.5 - 90, _vila_h * 0.5 + 10, _vila_w * 0.5 + 90, _vila_h * 0.5 + 60, false);
        draw_set_color(c_yellow);
        draw_text(_vila_w * 0.5, _vila_h * 0.5 + 35, "Reiniciar");
        draw_set_halign(fa_left);
        draw_set_valign(fa_top);
        draw_set_color(c_white);
        draw_set_alpha(1);
        exit;
    }
}

if (_texto == "") exit;

draw_set_font(yes);
var _padding = 6;
var _x1 = 20 - _padding;
var _y1 = 20 - _padding;
var _x2 = 20 + string_width(_texto) + _padding;
var _y2 = 20 + string_height(_texto) + _padding;

                           
draw_set_alpha(0.55);
draw_set_color(c_black);
draw_rectangle(_x1, _y1, _x2, _y2, false);

        
draw_set_alpha(0.25);
draw_set_color(c_white);
draw_rectangle(_x1, _y1, _x2, _y2, true);



draw_set_alpha(0.9);
draw_set_color(c_yellow);
draw_set_halign(fa_left);
draw_set_valign(fa_top);

draw_text(20, 20, _texto);



draw_set_alpha(1);
draw_set_color(c_white);
draw_set_font(yes);
