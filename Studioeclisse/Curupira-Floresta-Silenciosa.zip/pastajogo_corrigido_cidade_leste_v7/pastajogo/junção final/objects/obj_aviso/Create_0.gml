
if (instance_number(obj_aviso) > 1) {
    instance_destroy();
    exit;
}

                          
caixa_margem_x = 20; 
caixa_margem_y = 20;
caixa_padding = 10;  
opacidade_fundo = 0.6;
// Profundidade original do HUD: compatível com todas as rooms do projeto.
depth = -10000; 
