depth = -50000; // cutscene sempre acima de HUD, aviso, fader e neblina
global.em_cutscene = true;
global.estado_jogo = "cutscene";
if (instance_exists(obj_player_unificado)) obj_player_unificado.can_move = false;
if (!instance_exists(obj_aviso)) instance_create_depth(0, 0, -10000, obj_aviso);
                                                    
story_text[0] = "Depois de uma longa viagem, eles finalmente chegam à floresta.";
story_text[1] = "Preciso pegar lenha.";

total_pages = 2;
current_page = 0;
fade_alpha = 1;
fade_state = "in";
