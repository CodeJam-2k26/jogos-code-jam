draw_set_font(yes);
var gui_w = display_get_gui_width();
var gui_h = display_get_gui_height();

draw_set_alpha(1);
draw_set_color(c_black);
draw_rectangle(0, 0, gui_w, gui_h, false);

if (current_page < total_pages) {
    draw_set_color(c_white);
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_text_ext(gui_w * 0.5, gui_h * 0.5, story_text[current_page], -1, gui_w * 0.72);

    draw_set_valign(fa_bottom);
    draw_text(gui_w * 0.5, gui_h - 36, "Pressione ESPAÇO para continuar");
}

draw_set_alpha(fade_alpha);
draw_set_color(c_black);
draw_rectangle(0, 0, gui_w, gui_h, false);
draw_set_alpha(1);

draw_set_color(c_white);
draw_set_halign(fa_left);
draw_set_valign(fa_top);
