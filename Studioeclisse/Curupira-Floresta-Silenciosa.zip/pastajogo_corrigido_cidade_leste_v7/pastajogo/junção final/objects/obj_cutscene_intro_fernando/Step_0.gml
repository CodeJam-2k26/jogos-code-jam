                                       
if (fade_state == "in") {
    fade_alpha -= 0.02;
    if (fade_alpha <= 0) {
        fade_alpha = 0;
        fade_state = "idle";
    }
}

                                                    
if (fade_state == "idle") {
    if (keyboard_check_pressed(vk_space) || keyboard_check_pressed(ord("E"))) {
        fade_state = "out";
    }
}

                                                    
if (fade_state == "out") {
    fade_alpha += 0.02;
    if (fade_alpha >= 1) {
        fade_alpha = 1;
        current_page += 1;

        if (current_page >= total_pages) {
                                                                                
            global.quest = 3;
            global.fernando_intro_seen = true;
            global.em_cutscene = false;
            global.estado_jogo = "gameplay";
            // A rm_casinha liga a noite; a chegada ao acampamento é de dia.
            global.is_night = false;
            if (instance_exists(obj_player_unificado)) {
                obj_player_unificado.x = 762;
                obj_player_unificado.y = 328;
                obj_player_unificado.visible = true;
                obj_player_unificado.image_alpha = 1;
                obj_player_unificado.can_move = true;
            }
            // O aviso de objetivo é persistente; não o destrua ao trocar de sala.
            room_goto(rm_acampamento);
            exit;
        } else {
            fade_state = "in";
        }
    }
}
