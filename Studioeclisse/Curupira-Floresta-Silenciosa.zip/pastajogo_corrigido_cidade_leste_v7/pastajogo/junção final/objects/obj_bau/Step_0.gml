if (instance_exists(obj_player_unificado) && distance_to_object(obj_player_unificado) <= 24 && keyboard_check_pressed(ord("E")))
{
	if(global.quest == 0)
	{
		show_debug_message("lembrei tenho que ir ao bar com o pessoal!!");
		global.quest = 1;
	}
}