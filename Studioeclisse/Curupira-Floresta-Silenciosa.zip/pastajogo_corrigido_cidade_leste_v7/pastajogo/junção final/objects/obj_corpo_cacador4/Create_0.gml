depth = -10000;
timer = 5 * game_get_speed(gamespeed_fps);