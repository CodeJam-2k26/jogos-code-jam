if (room == rm_final1) exit;

var a = clamp(1 - timer / game_get_speed(gamespeed_fps), 0, 1);
draw_set_alpha(a);
draw_set_color(c_black);
draw_rectangle(0, 0, display_get_gui_width(), display_get_gui_height(), false);
draw_set_alpha(1);
draw_set_color(c_white);
