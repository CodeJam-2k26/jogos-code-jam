// Em rm_final1 este objeto é apenas parte da imagem final. O controlador da
// cena decide quando trocar para a tela "FIM".
if (room == rm_final1) exit;

timer--;
if (timer <= 0) {
    room_goto(rm_fim);
}
