if (current_time mod 500 < 17)
    show_debug_message("cam id=" + string(id) + " alvo=" + string(alvo) + " pos=" + string(x) + "," + string(y));