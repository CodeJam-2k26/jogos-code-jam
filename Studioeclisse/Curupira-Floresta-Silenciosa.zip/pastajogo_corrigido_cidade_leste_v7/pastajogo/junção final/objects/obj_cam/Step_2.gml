

if (variable_global_exists("estado_jogo") && global.estado_jogo == "cutscene")
{
    if (instance_exists(obj_cutscene_bar)) 
    {
        alvo = obj_cutscene_bar;
    }
}

else
{
    if (instance_exists(obj_player_unificado))
    {
        alvo = obj_player_unificado;
    }
}

                     
var _cam = view_camera[0];
if (instance_exists(alvo) && _cam != -1)
{
                                                               
    var _view_w = max(1, camera_get_view_width(_cam));
    var _view_h = max(1, camera_get_view_height(_cam));
    var _target_x = alvo.x - _view_w * 0.5;
    var _target_y = alvo.y - _view_h * 0.5;
    x = lerp(x, _target_x, 0.1);
    y = lerp(y, _target_y, 0.1);

                                                                      
                                    
    var _cam_x = clamp(x, 0, max(0, room_width - _view_w));
    var _cam_y = clamp(y, 0, max(0, room_height - _view_h));

                       
    camera_set_view_pos(_cam, _cam_x, _cam_y);
}
