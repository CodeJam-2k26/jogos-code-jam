
                                                                            
                                                             
if (instance_number(obj_cam) > 1) {
    instance_destroy();
    exit;
}

alvo = noone; 

zoom_w = 320;                   
zoom_h = 180;                  
zoom = noone;
