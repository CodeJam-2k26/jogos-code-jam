var near_player = distance_to_object(obj_player_unificado) <= interact_range;

if (near_player && keyboard_check_pressed(ord("E"))) {
    if (global.objective_done && !global.wood_delivered) {
                                                 
        global.wood_delivered = true;
        room_goto(rm_cutscene_parte2_fernando);
    } else if (global.wood_delivered && global.camp_stage == 0 && !global.camp_has_wood) {
                                     
        global.camp_has_wood = true;
    }
}