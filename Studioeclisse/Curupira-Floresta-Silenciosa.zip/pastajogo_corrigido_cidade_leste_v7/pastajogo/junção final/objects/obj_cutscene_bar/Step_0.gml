switch (fade_state)
{
    case "in":
        fade_alpha = max(0, fade_alpha - 0.04);
        if (fade_alpha <= 0)
        {
            fade_alpha = 0;
            fade_state = "idle";
        }
    break;

    case "idle":
        if (keyboard_check_pressed(vk_space))
        {
            fade_state = "out";
        }
    break;

    case "out":
        fade_alpha = min(1, fade_alpha + 0.04);
        if (fade_alpha >= 1)
        {
            current_page++;
            if (current_page >= total_pages)
            {
                global.estado_jogo = "gameplay";
                global.em_cutscene = false;
                global.cutscene_bar_feita = true;
                global.quest = 2;

                if (instance_exists(obj_player_unificado))
                {
                    obj_player_unificado.can_move = true;
                }

                                                                                    
                with (obj_block_bar) instance_destroy();

                room_goto(rm_cutscene_bar_fora);
            }
            else
            {
                fade_state = "in";
            }
        }
    break;
}
