depth = -10000;
global.estado_jogo = "cutscene";
global.em_cutscene = true;
if (instance_exists(obj_player_unificado))
{
    obj_player_unificado.can_move = false;
}

story_text = [
    "CAÇADOR 1: Fiquei sabendo que um pedaço da madeira do coração da floresta foi vendido por cinco mil reais.",
    "CAÇADOR 2: Sério? Por que alguém pagaria tanto por um pedaço de madeira?",
    "CAÇADOR 1: Ela só pode ser encontrada numa mata assombrada. Dos que se arriscam a entrar, poucos voltam.",
    "CAÇADOR 3: Se encontrarmos um pedaço, vamos ganhar muito dinheiro. Vamos até lá?",
    "CAÇADOR 2: Você tem certeza? Quase ninguém volta daquela floresta.",
    "CAÇADOR 3: A recompensa vale o risco. Vamos!",
    "CAÇADOR 2: Está bem... vamos para a floresta."
];

total_pages = array_length(story_text);
current_page = 0;
fade_alpha = 1;
fade_state = "in";
