if (point_distance(x, y, obj_player_unificado.x, obj_player_unificado.y) <= 60 && keyboard_check_pressed(ord("E"))) {
    room_goto(rm_acampamento_noite3);
}