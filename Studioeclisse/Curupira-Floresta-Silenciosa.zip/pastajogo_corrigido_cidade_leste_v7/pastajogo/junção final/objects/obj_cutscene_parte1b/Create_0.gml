depth = -50000; // cutscene sempre acima de HUD, aviso, fader e neblina
story_text[0] = "Após uma longa viagem, chegam à floresta.";
total_pages = 1;
current_page = 0;
fade_alpha = 1;
fade_state = "in";