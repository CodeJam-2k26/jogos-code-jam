if (global.player_morto) exit;

var perto = distance_to_object(obj_player_unificado) <= 40;
global.perto_barco = perto && global.barco_consertos < 3;

if (perto && global.barco_consertos < 3 && keyboard_check(ord("E"))) {
    global.consertando = true;
    obj_player_unificado.can_move = false;
    global.conserto_prog += 1 / (3 * game_get_speed(gamespeed_fps));

    if (global.conserto_prog >= 1) {
        global.conserto_prog = 0;
        global.barco_consertos += 1;
        global.consertando = false;
        obj_player_unificado.can_move = true;

        if (global.barco_consertos >= 3) {
            room_goto(rm_final1);
        }
    }
} else if (global.consertando) {
    global.consertando = false;
    obj_player_unificado.can_move = true;
}