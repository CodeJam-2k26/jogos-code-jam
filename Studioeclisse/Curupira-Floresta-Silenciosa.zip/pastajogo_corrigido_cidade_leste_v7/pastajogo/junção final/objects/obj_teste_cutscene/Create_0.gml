distancia_interacao = 30;
em_conversa = false;
etapa_dialogo = 0;
tempo_min_fala = 0;
dica_ja_usada = false;
if (!variable_global_exists("quest_feira")) global.quest_feira = 0;