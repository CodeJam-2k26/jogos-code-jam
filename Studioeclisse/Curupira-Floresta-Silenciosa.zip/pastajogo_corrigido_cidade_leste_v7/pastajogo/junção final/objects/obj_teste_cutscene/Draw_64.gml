draw_set_font(yes);
                                                                        
if (!em_conversa || !instance_exists(obj_player_unificado)) exit;

var _texto = "";
switch (etapa_dialogo)
{
    case 1:
        _texto = "Com licença, onde fica o bar?";
        break;
    case 2:
        _texto = "Ah, o bar? É só seguir direto para o Norte!";
        break;
    case 3:
        _texto = "Ainda aqui? O Norte é para lá, amigo!";
        break;
}
var _nome = "";
switch (etapa_dialogo) { case 1: _nome = "Você"; break; case 2: _nome = "Feirante"; break; case 3: _nome = "Feirante"; break; }
if (_texto == "") exit;

var _gui_w = display_get_gui_width();
var _gui_h = display_get_gui_height();
var _margin_x = min(20, _gui_w * 0.06);
var _panel_w = _gui_w - (_margin_x * 2);
var _panel_h = min(90, _gui_h * 0.5);
var _bottom = min(8, _gui_h * 0.04);
var _x1 = _margin_x;
var _y1 = _gui_h - _panel_h - _bottom;
var _x2 = _gui_w - _margin_x;
var _y2 = _gui_h - _bottom;

                                                                       
draw_set_alpha(0.88);
draw_set_color(c_black);
draw_rectangle(_x1, _y1, _x2, _y2, false);
draw_set_alpha(1);
draw_set_color(c_white);
draw_rectangle(_x1, _y1, _x2, _y2, true);

                                                       
draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_set_font(yes);
draw_set_color(c_white);
draw_set_color(c_yellow);
draw_text(_x1 + 8, _y1 + 4, _nome + ":");
draw_set_color(c_white);
draw_text_ext(_x1 + 8, _y1 + 28, _texto, 0, _panel_w - 16);

draw_set_alpha(1);
draw_set_color(c_white);
draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_set_font(yes);
