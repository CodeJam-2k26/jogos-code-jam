if (tempo_min_fala > 0) tempo_min_fala--;

if (instance_exists(obj_player_unificado))
{
    var _dist = distance_to_object(obj_player_unificado);
    if (_dist <= distancia_interacao && keyboard_check_pressed(ord("E")) && tempo_min_fala <= 0)
    {
        tempo_min_fala = 15;
        if (global.quest_feira == 0)
        {
            if (!em_conversa)
            {
                em_conversa = true;
                etapa_dialogo = 1;
                dica_ja_usada = true;
            }
            else
            {
                etapa_dialogo++;
                if (etapa_dialogo > 2)
                {
                    em_conversa = false;
                    etapa_dialogo = 0;
                    global.quest_feira = 1;
                }
            }
        }
        else if (global.quest_feira >= 1 && !em_conversa)
        {
            em_conversa = true;
            etapa_dialogo = 3;
            dica_ja_usada = true;
        }
        else if (etapa_dialogo == 3)
        {
            em_conversa = false;
            etapa_dialogo = 0;
        }
    }
}