depth = -50000; // cutscene sempre acima de HUD, aviso, fader e neblina
global.em_cutscene = true;
global.estado_jogo = "cutscene";
// A noite é ativada ao sair. Durante o diálogo a tela deve ficar limpa.
global.is_night = false;
exiting = false;

// A interface persistente desenha uma cópia segura da fala na GUI.
if (!instance_exists(obj_aviso)) {
    instance_create_depth(0, 0, -10000, obj_aviso);
}

if (instance_exists(obj_player_unificado)) {
    with (obj_player_unificado) {
        can_move = false;
        visible = true;
        image_alpha = 1;
    }
}

speaker_name[0] = "Caçador 1";
speaker_text[0] = "Esse é o lampião do Caçador 4... ele nunca sairia sem ele.";
speaker_portrait[0] = spr_cacador1_portrait;

speaker_name[1] = "Caçador 1";
speaker_text[1] = "As pegadas seguem pra dentro da mata. Preciso ir atrás dele.";
speaker_portrait[1] = spr_cacador1_portrait;

total_lines = 2;
current_line = 0;
