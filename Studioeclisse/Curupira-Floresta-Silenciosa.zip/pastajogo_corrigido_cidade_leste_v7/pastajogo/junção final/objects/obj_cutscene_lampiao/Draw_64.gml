draw_set_alpha(1);
draw_set_color(c_white);
draw_set_font(yes);
var gui_w = display_get_gui_width();
var gui_h = display_get_gui_height();

draw_set_color(c_black);
draw_rectangle(0, 0, gui_w, gui_h, false);

if (current_line < total_lines) {
    var _margin = min(24, gui_w * 0.04);
    var box_x1 = _margin;
    var box_x2 = gui_w - _margin;
    var _portrait_area = min(180, gui_w * 0.18);
    var _text_x = box_x1 + _portrait_area + 20;
    var _text_w = max(1, box_x2 - _text_x - 16);
    var _line_sep = max(4, min(8, gui_h * 0.012));
    var _text_h = string_height_ext(speaker_text[current_line], _line_sep, _text_w);
    var _box_h = min(gui_h - 2 * _margin, max(gui_h * 0.22, _text_h + 70));
    var box_y2 = gui_h - _margin;
    var box_y1 = box_y2 - _box_h;

    var _portrait_sprite = speaker_portrait[current_line];
    var _portrait_scale = min(1, min((_portrait_area - 12) / max(1, sprite_get_width(_portrait_sprite)), (_box_h - 16) / max(1, sprite_get_height(_portrait_sprite))));
    var portrait_x = box_x1 + 6;
    var portrait_y = box_y1 + 8;
    draw_set_color(c_black);
    draw_set_alpha(0.85);
    draw_roundrect(box_x1, box_y1, box_x2, box_y2, false);
    draw_set_alpha(1);

    draw_set_color(c_yellow);
    draw_roundrect(box_x1, box_y1, box_x2, box_y2, true);
    draw_roundrect(box_x1 - 1, box_y1 - 1, box_x2 + 1, box_y2 + 1, true);

    draw_sprite_ext(_portrait_sprite, 0, portrait_x, portrait_y, _portrait_scale, _portrait_scale, 0, c_white, 1);

    var name_x1 = _text_x;
    var name_y1 = box_y1 + 4;
    var name_x2 = min(box_x2 - 8, name_x1 + 160);
    var name_y2 = box_y1 + 36;
    draw_set_color(c_navy);
    draw_roundrect(name_x1, name_y1, name_x2, name_y2, false);
    draw_set_color(c_yellow);
    draw_roundrect(name_x1, name_y1, name_x2, name_y2, true);

    draw_set_color(c_white);
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_text((name_x1 + name_x2) / 2, (name_y1 + name_y2) / 2, speaker_name[current_line]);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_text_ext(_text_x, box_y1 + 42, speaker_text[current_line], _line_sep, _text_w);

    if ((current_time div 500) mod 2 == 0) {
        draw_set_halign(fa_right);
        draw_set_valign(fa_bottom);
        draw_text(box_x2 - 12, box_y2 - 10, "▼");
    }
}

draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_set_alpha(1);
draw_set_color(c_white);
