// A passagem inferior direita da rm_cidade deve abrir assim que o jogador
// atingir quest_feira >= 2, preservando a progressão da missão.
if (global.quest_feira >= 2)
{
    instance_destroy();
}
else if (place_meeting(x - 2, y, obj_player_unificado) ||
         place_meeting(x + 2, y, obj_player_unificado) ||
         place_meeting(x, y - 2, obj_player_unificado) ||
         place_meeting(x, y + 2, obj_player_unificado))
{
    obj_player_unificado.mensagem = "Acho melhor conversar com aquele cara primeiro";
    global.txt_aviso = 60;
}
