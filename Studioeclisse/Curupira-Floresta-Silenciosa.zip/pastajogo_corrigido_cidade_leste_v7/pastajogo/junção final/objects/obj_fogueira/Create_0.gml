interact_range = 60;
roasting = false;
roast_timer = 0;
roast_duration = 300;                       

eating = false;
eat_timer = 0;
eat_duration = 300;