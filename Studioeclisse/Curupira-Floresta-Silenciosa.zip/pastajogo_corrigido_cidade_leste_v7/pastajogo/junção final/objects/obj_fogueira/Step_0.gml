var near_player = distance_to_object(obj_player_unificado) <= interact_range;

                                                                
if (global.camp_stage == 0 && near_player && global.camp_has_wood && keyboard_check_pressed(ord("E"))) {
    global.camp_has_wood = false;
    global.camp_stage = 1;
}

                                                                 
if (global.camp_stage == 1 && near_player && keyboard_check_pressed(ord("R")) && !roasting) {
    roasting = true;
    roast_timer = 0;
}

if (roasting) {
    roast_timer += 1;
    if (roast_timer >= roast_duration) {
        roasting = false;
        global.camp_stage = 2;
    }
}

                                                          
if (global.camp_stage == 2 && near_player && keyboard_check_pressed(ord("R"))) {
    global.camp_stage = 3;
}

                                                 
if (global.camp_stage == 3 && near_player && keyboard_check_pressed(ord("R")) && !eating) {
    eating = true;
    eat_timer = 0;
}

if (eating) {
    eat_timer += 1;
    if (eat_timer >= eat_duration) {
        eating = false;
        global.camp_stage = 4;
    }
}

                                                       
if (global.camp_stage == 4 && near_player && keyboard_check_pressed(ord("E"))) {
    global.camp_stage = 5;
}