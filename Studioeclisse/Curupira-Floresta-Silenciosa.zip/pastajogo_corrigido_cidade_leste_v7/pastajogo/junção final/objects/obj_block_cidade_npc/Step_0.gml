                                                                       
// A barreira norte precisa abrir após a primeira conversa para permitir
// alcançar o NPC que conclui esta etapa da missão. A barreira leste segue
// fechada até a missão chegar à etapa 2.
var _liberar_barreira = global.quest_feira >= 2;
if (room == rm_cidade && x < 600 && global.quest_feira >= 1) {
    _liberar_barreira = true;
}

if (_liberar_barreira)
{
    instance_destroy();
}
else if (place_meeting(x - 2, y, obj_player_unificado) ||
         place_meeting(x + 2, y, obj_player_unificado) ||
         place_meeting(x, y - 2, obj_player_unificado) ||
         place_meeting(x, y + 2, obj_player_unificado))
{
    obj_player_unificado.mensagem = "Acho melhor conversar com aquele cara primeiro";
    global.txt_aviso = 60;
}
