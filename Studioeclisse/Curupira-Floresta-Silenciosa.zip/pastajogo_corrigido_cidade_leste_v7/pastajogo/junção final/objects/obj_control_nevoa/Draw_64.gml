                                                                       
                                                                                
// O shader redesenha a application_surface por cima da interface. Suspenda-o
// nas cutscenes, que são desenhadas no Draw GUI End.
if (!instance_exists(obj_cutscene_bar)
    && !instance_exists(obj_cutscene_intro_fernando)
    && !instance_exists(obj_cutscene_parte2_fernando)
    && !instance_exists(obj_cutscene_parte3)
    && !instance_exists(obj_cutscene_parte4)
    && !instance_exists(obj_cutscene_parte5)
    && !instance_exists(obj_cutscene_lampiao)
    && !instance_exists(obj_cutscene_agua)) {
    gpu_set_blendenable(true);
    gpu_set_tex_filter(true);                                        

    shader_set(shd_nevoa);

                              
    shader_set_uniform_f(u_time, current_time * 0.0015);

                                                        
    var surf_w = surface_get_width(application_surface);
    var surf_h = surface_get_height(application_surface);
    shader_set_uniform_f(u_resolution, surf_w, surf_h);

                                                                       
    var scale_x = display_get_gui_width() / surf_w;
    var scale_y = display_get_gui_height() / surf_h;

                                                      
    draw_surface_ext(application_surface, 0, 0, scale_x, scale_y, 0, c_white, 1);

    shader_reset();
    gpu_set_tex_filter(false);
}
