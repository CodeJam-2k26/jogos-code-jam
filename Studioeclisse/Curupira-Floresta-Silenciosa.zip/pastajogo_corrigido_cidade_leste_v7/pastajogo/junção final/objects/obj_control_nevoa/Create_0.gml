u_time = shader_get_uniform(shd_nevoa, "u_time");
u_resolution = shader_get_uniform(shd_nevoa, "u_resolution");

                                                                                     
application_surface_draw_enable(true);
