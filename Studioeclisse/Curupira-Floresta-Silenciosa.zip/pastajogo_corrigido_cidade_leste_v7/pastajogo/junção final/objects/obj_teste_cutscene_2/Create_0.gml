distancia_interacao = 30;
em_conversa = false;
etapa_dialogo = 0;
if (!variable_global_exists("quest_feira")) global.quest_feira = 0;
if (!variable_global_exists("quest")) global.quest = 0;
if (!variable_global_exists("dica_npc_norte_vista")) global.dica_npc_norte_vista = false;
dica_ja_usada = global.dica_npc_norte_vista;
