if (instance_exists(obj_player_unificado))
{
    var _dist = distance_to_object(obj_player_unificado);

    if (keyboard_check_pressed(ord("E")))
    {
        if (em_conversa)
        {
                                                                 
            if (etapa_dialogo >= 2)
            {
                em_conversa = false;
                etapa_dialogo = 0;
                if (global.quest_feira == 1) global.quest_feira = 2;
            }
            else
            {
                etapa_dialogo++;
            }
        }
        else if (_dist <= distancia_interacao && global.quest_feira == 1)
        {
            em_conversa = true;
            etapa_dialogo = 1;
            dica_ja_usada = true;
            global.dica_npc_norte_vista = true;
        }
        else if (_dist <= distancia_interacao && global.quest_feira >= 2)
        {
            em_conversa = true;
            etapa_dialogo = 3;
            dica_ja_usada = true;
            global.dica_npc_norte_vista = true;
        }
    }
}
