if (global.quest == 0)
{

    if (place_meeting(x - 2, y, obj_player_unificado) ||
        place_meeting(x + 2, y, obj_player_unificado) ||
        place_meeting(x, y - 2, obj_player_unificado) ||
        place_meeting(x, y + 2, obj_player_unificado))
    {
                                 
        obj_player_unificado.mensagem = "preciso beber agua primeiro";
        global.txt_aviso = 60; 
    }
}

else
{
	instance_destroy();
}