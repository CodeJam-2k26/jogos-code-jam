draw_set_font(yes);
draw_self();

var near_player = point_distance(x, y, obj_player_unificado.x, obj_player_unificado.y) <= interact_range;

if (near_player && !show_dialogue && !was_called && !global.dialogue_open) {
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_set_color(c_white);
    draw_text(x, y - 50, "Clique R para conversar");
}
