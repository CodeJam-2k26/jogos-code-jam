if (!instance_exists(obj_player_unificado)) exit;
var near_player = point_distance(x, y, obj_player_unificado.x, obj_player_unificado.y) <= interact_range;

if (near_player && keyboard_check_pressed(ord("R")) && !show_dialogue && !was_called
    && !global.dialogue_open) {
    show_dialogue = true;
    show_choice = true;
    global.dialogue_open = true;
    global.dialogue_owner = id;
}

if (!near_player) {
    if (global.dialogue_owner == id) {
        global.dialogue_open = false;
        global.dialogue_owner = noone;
    }
    show_dialogue = false;
    show_choice = false;
}

if (show_dialogue && !show_choice && global.dialogue_owner == id
    && (keyboard_check_pressed(ord("R")) || keyboard_check_pressed(ord("E"))
        || keyboard_check_pressed(vk_space))) {
    show_dialogue = false;
    global.dialogue_open = false;
    global.dialogue_owner = noone;
}

if (show_choice) {
    var mx = device_mouse_x_to_gui(0);
    var my = device_mouse_y_to_gui(0);
    
    var gui_w = display_get_gui_width();
    var gui_h = display_get_gui_height();
    
    var box_w = min(720, gui_w - 32);
    var box_x1 = (gui_w - box_w) * 0.5;
    var box_y1 = gui_h * 0.70;
    var box_x2 = box_x1 + box_w;
    var box_y2 = gui_h - 18;
    
    var btn_x1 = box_x2 - 210; var btn_y1 = box_y2 - 46; var btn_x2 = box_x2 - 14; var btn_y2 = box_y2 - 12;
    
    if (mouse_check_button_pressed(mb_left)) {
        if (mx >= btn_x1 && mx <= btn_x2 && my >= btn_y1 && my <= btn_y2) {
            dialogue_text = response_text;
            show_choice = false;
            was_called = true;
            global.hunters_called += 1;
        }
    }
}
