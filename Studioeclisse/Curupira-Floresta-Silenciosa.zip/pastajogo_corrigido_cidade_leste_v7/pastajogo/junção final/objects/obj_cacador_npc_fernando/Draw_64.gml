draw_set_font(yes);
if (show_dialogue && global.dialogue_open && global.dialogue_owner == id) {
    var gui_w = display_get_gui_width();
    var gui_h = display_get_gui_height();
    
    var box_w = min(720, gui_w - 32);
    var box_x1 = (gui_w - box_w) * 0.5;
    var box_y1 = gui_h * 0.70;
    var box_x2 = box_x1 + box_w;
    var box_y2 = gui_h - 18;
    
    draw_set_alpha(0.85);
    draw_set_color(c_black);
    draw_rectangle(box_x1, box_y1, box_x2, box_y2, false);
    draw_set_alpha(1);
    draw_set_color(c_white);
    draw_rectangle(box_x1, box_y1, box_x2, box_y2, true);
    
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_text_ext(box_x1 + 16, box_y1 + 12, dialogue_text, -1, box_w - 32);
    
    if (show_choice) {
        var btn_x1 = box_x2 - 210; var btn_y1 = box_y2 - 46; var btn_x2 = box_x2 - 14; var btn_y2 = box_y2 - 12;
        
        draw_set_color(c_dkgray);
        draw_rectangle(btn_x1, btn_y1, btn_x2, btn_y2, false);
        draw_set_color(c_white);
        draw_rectangle(btn_x1, btn_y1, btn_x2, btn_y2, true);
        
        draw_set_halign(fa_center);
        draw_set_valign(fa_middle);
        draw_text((btn_x1 + btn_x2) / 2, (btn_y1 + btn_y2) / 2, choice_text);
    } else {
        draw_set_halign(fa_right);
        draw_set_valign(fa_bottom);
        draw_text(box_x2 - 18, box_y2 - 8, "R: fechar");
    }
}
