depth = -50000; // cutscene sempre acima de HUD, aviso, fader e neblina
global.em_cutscene = true;
global.estado_jogo = "cutscene";
if (instance_exists(obj_player_unificado)) obj_player_unificado.can_move = false;
if (!instance_exists(obj_aviso)) instance_create_depth(0, 0, -10000, obj_aviso);
story_text[0] = "Durante a madrugada, um dos caçadores acorda sentindo-se mal e decide sair da cabana para tomar um pouco de ar.";
story_text[1] = "Enquanto caminha pela mata escura, ouve um estranho barulho vindo dos arbustos.";
story_text[2] = "Curioso, aproxima-se lentamente para investigar.";
story_text[3] = "Em poucos segundos, um forte assobio ecoa pela floresta.";
story_text[4] = "O silêncio toma conta do lugar.";
story_text[5] = "O caçador desaparece sem deixar rastros.";
story_text[6] = "Algum tempo depois, o companheiro que dividia a cabana com ele desperta e percebe que ele não voltou. Após procurá-lo nas proximidades sem sucesso, corre até a outra cabana para avisar os demais de que um dos caçadores desapareceu.";

total_pages = 7;
current_page = 0;
fade_alpha = 1;
fade_state = "in";
