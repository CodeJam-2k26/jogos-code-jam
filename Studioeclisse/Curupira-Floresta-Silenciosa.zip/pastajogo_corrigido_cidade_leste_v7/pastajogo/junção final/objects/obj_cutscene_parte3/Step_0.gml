if (fade_state == "in") {
    fade_alpha -= 0.02;
    if (fade_alpha <= 0) {
        fade_alpha = 0;
        fade_state = "idle";
    }
}

if (fade_state == "idle") {
    if (keyboard_check_pressed(vk_space) || keyboard_check_pressed(ord("E"))) {
        fade_state = "out";
    }
}

if (fade_state == "out") {
    fade_alpha += 0.02;
    if (fade_alpha >= 1) {
        fade_alpha = 1;
        current_page += 1;
        if (current_page >= total_pages) {
            room_goto(rm_cutscene_parte4);
        } else {
            fade_state = "in";
        }
    }
}