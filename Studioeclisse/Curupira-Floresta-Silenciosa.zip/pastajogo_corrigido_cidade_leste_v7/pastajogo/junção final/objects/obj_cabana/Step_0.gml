// Ir dormir -> cutscene (rm_cutscene_parte3).
// A cabana tem origem no canto superior esquerdo e é escalada (2.5x) na sala:
// medir a distância até a origem deixava a porta fora do alcance. Aqui a distância
// é medida até a caixa de colisão real (igual à fogueira e ao barco do acampamento).
if (!instance_exists(obj_player_unificado)) exit;

var near_player = distance_to_object(obj_player_unificado) <= interact_range;

if (near_player && keyboard_check_pressed(ord("E")) && global.camp_stage == 5 && !global.has_slept) {
    global.has_slept = true;
    room_goto(rm_cutscene_parte3);
}
