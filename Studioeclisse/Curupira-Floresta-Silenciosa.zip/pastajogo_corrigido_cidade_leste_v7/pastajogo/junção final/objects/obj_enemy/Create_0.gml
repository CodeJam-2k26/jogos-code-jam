move_speed = 1;
direction_walk_x = 0;
direction_walk_y = 0;
start_x = x;
start_y = y;
hp = 50;