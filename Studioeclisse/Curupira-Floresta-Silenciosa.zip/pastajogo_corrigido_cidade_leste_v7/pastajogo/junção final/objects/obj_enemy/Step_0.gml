var dist = point_distance(x, y, obj_player_unificado.x, obj_player_unificado.y);
var vision_range = 150;

if (dist <= vision_range) {
    direction_walk_x = sign(obj_player_unificado.x - x);
    direction_walk_y = sign(obj_player_unificado.y - y);
} else {
    var dist_start = point_distance(x, y, start_x, start_y);
    if (dist_start > 4) {
        direction_walk_x = sign(start_x - x);
        direction_walk_y = sign(start_y - y);
    } else {
        direction_walk_x = 0;
        direction_walk_y = 0;
    }
}

if (!place_meeting(x + direction_walk_x * move_speed, y, obj_wall)
    && !place_meeting(x + direction_walk_x * move_speed, y, obj_wall_fernando)) {
    x += direction_walk_x * move_speed;
}
if (!place_meeting(x, y + direction_walk_y * move_speed, obj_wall)
    && !place_meeting(x, y + direction_walk_y * move_speed, obj_wall_fernando)) {
    y += direction_walk_y * move_speed;
}
