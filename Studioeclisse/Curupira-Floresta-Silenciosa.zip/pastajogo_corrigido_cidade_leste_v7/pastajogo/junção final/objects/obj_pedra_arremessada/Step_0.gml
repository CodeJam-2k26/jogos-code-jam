if (point_distance(x, y, destino_x, destino_y) <= vel) {
    global.barulho_x = destino_x;
    global.barulho_y = destino_y;
    global.barulho_ativo = true;
    instance_destroy();
} else {
    var d = point_direction(x, y, destino_x, destino_y);
    x += lengthdir_x(vel, d);
    y += lengthdir_y(vel, d);
}