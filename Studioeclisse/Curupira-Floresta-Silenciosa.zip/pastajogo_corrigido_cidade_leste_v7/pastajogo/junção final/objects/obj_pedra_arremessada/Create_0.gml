destino_x = x;
destino_y = y;
vel = 8;