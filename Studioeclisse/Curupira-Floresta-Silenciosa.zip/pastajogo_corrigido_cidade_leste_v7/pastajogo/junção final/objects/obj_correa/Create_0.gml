                                                                                          
nome_item = "Corrêa";
distancia_interacao = 32;                                                          