depth = -50000; // cutscene sempre acima de HUD, aviso, fader e neblina
global.em_cutscene = true;
global.estado_jogo = "cutscene";
if (instance_exists(obj_player_unificado)) obj_player_unificado.can_move = false;
if (!instance_exists(obj_aviso)) instance_create_depth(0, 0, -10000, obj_aviso);
story_text[0] = "Como o local é muito distante e explorar toda a região em apenas um dia seria impossível, um dos caçadores sugere que montem um acampamento e permaneçam ali por alguns dias.";
story_text[1] = "Antes do anoitecer, eles montam duas pequenas cabanas e passam o restante do dia explorando os arredores, marcando árvores e planejando por onde começariam a retirada da madeira na manhã seguinte.";

total_pages = 2;
current_page = 0;
fade_alpha = 1;
fade_state = "in";
