draw_set_font(yes);
draw_self();

if (!can_move && !intro_dialogue_shown) {
    var bubble_w = 220;
    var bubble_h = 70;
    var bubble_x = x - bubble_w / 2;
    var bubble_y = y - 110;
    
                     
    draw_set_color(c_white);
    draw_roundrect(bubble_x, bubble_y, bubble_x + bubble_w, bubble_y + bubble_h, false);
    draw_set_color(c_black);
    draw_roundrect(bubble_x, bubble_y, bubble_x + bubble_w, bubble_y + bubble_h, true);
    
                                                  
    draw_triangle(x - 10, bubble_y + bubble_h, x + 10, bubble_y + bubble_h, x, bubble_y + bubble_h + 15, false);
    draw_set_color(c_white);
    draw_triangle(x - 8, bubble_y + bubble_h - 2, x + 8, bubble_y + bubble_h - 2, x, bubble_y + bubble_h + 12, false);
    
            
    draw_set_color(c_black);
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_text_ext(x, bubble_y + bubble_h / 2, intro_dialogue_text, -1, bubble_w - 20);
}