if (can_move && !auto_walk_active) {
    var input_h = keyboard_check(ord("D")) - keyboard_check(ord("A"));
    var input_v = keyboard_check(ord("S")) - keyboard_check(ord("W"));

    if (input_h != 0 && input_v != 0) {
        input_h *= 0.7071;
        input_v *= 0.7071;
    }

    if (input_h != 0) {
        facing = input_h;
    }

    if (!place_meeting(x + input_h * move_speed, y, obj_wall_fernando)) {
        x += input_h * move_speed;
    }
    if (!place_meeting(x, y + input_v * move_speed, obj_wall_fernando)) {
        y += input_v * move_speed;
    }
}

                                                               
if (auto_walk_active) {
    var dist_to_target = point_distance(x, y, auto_walk_target_x, auto_walk_target_y);
    
    if (dist_to_target > 4) {
                                                    
        var dir = point_direction(x, y, auto_walk_target_x, auto_walk_target_y);
        x += lengthdir_x(move_speed, dir);
        y += lengthdir_y(move_speed, dir);
    } else {
                                                                    
        auto_walk_pause_timer += 1;
        if (auto_walk_pause_timer >= 60) {                           
            auto_walk_active = false;
            can_move = true;                                    
            room_goto(rm_acampamento_noiteteste);                          
        }
    }
}
if (!can_move && !intro_dialogue_shown) {
    if (keyboard_check_pressed(vk_space) || keyboard_check_pressed(ord("E"))) {
        can_move = true;
        intro_dialogue_shown = true;
    }
}

        
near_door = place_meeting(x, y, obj_door_fernando);

if (near_door && keyboard_check_pressed(ord("E"))) {
    var target_door = instance_place(x, y, obj_door_fernando);
    room_goto(target_door.target_room);
    x = target_door.target_x;
    y = target_door.target_y;
}



                                    
if (invincible_timer > 0) {
    invincible_timer -= 1;
}

if (place_meeting(x, y, obj_enemy_fernando) && invincible_timer <= 0) {
    hp -= 20;
    invincible_timer = 60;
    
    if (hp <= 0) {
        hp = hp_max;
        x = spawn_x;
        y = spawn_y;
    }
}

show_debug_message("trees_cut: " + string(global.trees_cut) + " objective_done: " + string(global.objective_done));

                                                                          
if (global.trees_cut >= global.trees_goal && !global.objective_done) {
    global.objective_done = true;
}

                                                       
if (keyboard_check_pressed(ord("Q"))) {
    var _p = instance_nearest(x, y, obj_pedra);
    if (_p != noone && point_distance(x, y, _p.x, _p.y) <= 40) {
        global.pedras += 1;
        instance_destroy(_p);
    } else {
        flashlight_on = !flashlight_on;
        if (flashlight_on) {
            sprite_index = sprite_with_lantern;
            sprite_normal = sprite_with_lantern;
        } else {
            sprite_index = sprite_no_lantern;
            sprite_normal = sprite_no_lantern;
        }
    }
}