draw_set_font(yes);
                            
var _mostrar_hud_acampamento = room == rm_acampamento || room == rm_acampamento_noite
    || room == rm_acampamento_noite2 || room == rm_acampamento_noite3;

if (_mostrar_hud_acampamento) {
    var bar_x = 20;
    var bar_y = 20;
    var bar_width = 200;
    var bar_height = 20;

    draw_set_color(c_dkgray);
    draw_rectangle(bar_x, bar_y, bar_x + bar_width, bar_y + bar_height, false);

    draw_set_color(c_lime);
    var hp_width = (hp / hp_max) * bar_width;
    draw_rectangle(bar_x, bar_y, bar_x + hp_width, bar_y + bar_height, false);

    draw_set_color(c_white);
    draw_rectangle(bar_x, bar_y, bar_x + bar_width, bar_y + bar_height, true);
}

                                                           
var gui_w = display_get_gui_width();
var gui_h = display_get_gui_height();
var obj_x = gui_w - 20;
var obj_y = 20;

draw_set_halign(fa_right);
draw_set_valign(fa_top);
draw_set_color(c_white);

if (room == rm_final || room == rm_fim) {
                                    
} else if (!_mostrar_hud_acampamento) {
                                                                             
} else if (room == rm_acampamento_noite3) {
    draw_text(obj_x, obj_y, "Objetivo: Consertar o barco (" + string(global.barco_consertos) + "/3)");
} else if (!global.objective_done) {
    draw_text(obj_x, obj_y, "Objetivo: Derrubar árvores (" + string(global.trees_cut) + "/" + string(global.trees_goal) + ")");
} else if (!global.wood_delivered) {
    draw_text(obj_x, obj_y, "Objetivo: Levar a madeira até o barco");
} else if (global.camp_stage == 0) {
    draw_text(obj_x, obj_y, "Objetivo: Pegar a madeira do barco para a fogueira");
} else if (global.camp_stage == 1) {
    draw_text(obj_x, obj_y, "Objetivo: Assar a carne");
} else if (global.camp_stage == 2) {
    draw_text(obj_x, obj_y, "Objetivo: Pegar a carne assada");
} else if (global.camp_stage == 3) {
    draw_text(obj_x, obj_y, "Objetivo: Comer com os amigos");
} else if (global.camp_stage == 4) {
    draw_text(obj_x, obj_y, "Objetivo: Apagar a fogueira");
} else if (global.camp_stage == 5 && !global.has_slept) {
    draw_text(obj_x, obj_y, "Objetivo: Ir dormir");
} else if (global.has_slept && !global.arrived_at_cabin2) {
    draw_text(obj_x, obj_y, "Objetivo: Ir até a outra cabana");
} else if (global.arrived_at_cabin2 && !global.lamp_analyzed) {
    draw_text(obj_x, obj_y, "Objetivo: Procurar seu parceiro");
} else if (global.casa_stage == 1) {
    draw_text(obj_x, obj_y, "Objetivo: Explorar a casa");
} else if (global.casa_stage == 2) {
    draw_text(obj_x, obj_y, "Objetivo: Esconda-se!");
} else if (global.casa_stage == 3) {
    draw_text(obj_x, obj_y, "Objetivo: Ir até a vila");
} else if (global.lamp_analyzed) {
    draw_text(obj_x, obj_y, "Objetivo: Entrar na casa");
}

draw_set_halign(fa_left);

                               
if (global.is_night) {

                                                                     
    if (!flashlight_hint_shown) {
        draw_set_halign(fa_center);
        draw_set_color(c_white);
        draw_text(gui_w / 2, 50, "Pressione Q para acender a lanterna");
        draw_set_halign(fa_left);
        if (flashlight_on) {
            flashlight_hint_shown = true;
        }
    }

    if (!flashlight_on) {
                                                   
        draw_set_alpha(0.85);
        draw_set_color(c_black);
        draw_rectangle(0, 0, gui_w, gui_h, false);
        draw_set_alpha(1);
    } else {
                                                                               

        if (!surface_exists(light_surf)
            || surface_get_width(light_surf) != gui_w
            || surface_get_height(light_surf) != gui_h) {
            if (surface_exists(light_surf)) surface_free(light_surf);
            light_surf = surface_create(gui_w, gui_h);
        }

        var cam = view_camera[0];
        var cam_x = camera_get_view_x(cam);
        var cam_y = camera_get_view_y(cam);
        var cam_w = max(1, camera_get_view_width(cam));
        var cam_h = max(1, camera_get_view_height(cam));
        var scale_x = gui_w / cam_w;
        var scale_y = (room == rm_casa_1) ? scale_x : (gui_h / cam_h);
        var px = (x - cam_x) * scale_x;
        var py = (y - cam_y) * scale_y;

        var light_radius_x = 160 * scale_x;
        var light_radius_y = 160 * scale_y;
        var steps = 10;

        surface_set_target(light_surf);
        draw_clear_alpha(c_black, 0.85);

        gpu_set_blendmode(bm_subtract);
        draw_set_color(c_white);
        for (var i = 0; i < steps; i++) {
            var radius_x = light_radius_x * (1 - i / steps);
            var radius_y = light_radius_y * (1 - i / steps);
            draw_set_alpha(0.9 / steps);
            draw_ellipse(px - radius_x, py - radius_y, px + radius_x, py + radius_y, false);
        }
        gpu_set_blendmode(bm_normal);
        draw_set_alpha(1);
        surface_reset_target();

        draw_surface(light_surf, 0, 0);
    }
}

draw_set_alpha(1);
draw_set_color(c_white);
draw_set_halign(fa_left);
