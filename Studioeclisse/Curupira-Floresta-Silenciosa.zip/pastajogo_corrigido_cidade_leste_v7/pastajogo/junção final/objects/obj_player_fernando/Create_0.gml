draw_set_font(yes); 

move_speed = 3;
facing = 1;

hp = 100;
hp_max = 100;
invincible_timer = 0;

spawn_x = x;
spawn_y = y;

near_door = false;

has_sword = false;
attack_cooldown = 0;
attack_timer = 0;
sprite_normal = spr_player_fernando;                                   
sprite_attack = sprite_normal;

can_move = false;
intro_dialogue_shown = false;
intro_dialogue_text = "Acho melhor eu ir chamar meus amigos, para irmos";

                                                    
auto_walk_active = false;
auto_walk_target_x = 0;
auto_walk_target_y = 0;
auto_walk_pause_timer = 0;

                                  
flashlight_on = false;
flashlight_hint_shown = false;

sprite_no_lantern = sprite_normal;
sprite_with_lantern = spr_player_lanterna;                                        

light_surf = -1;

                                                       
if (!variable_global_exists("game_started")) {
    global.game_started = true;

    global.hunters_called = 0;
    global.trees_cut = 0;
    global.trees_goal = 3;
    global.objective_done = false;

    global.dialogue_open = false;

    global.wood_delivered = false;

    global.camp_stage = 0;                                                                             
    global.camp_has_wood = false;

    global.arrived_at_cabin2 = false;
    global.has_slept = false;

    global.is_night = false;

    global.lamp_analyzed = false;
	
	global.casa_stage = 0;
	global.map_picked=false;
	global.player_hidden=false;
	global.casa_alerta=false;
	
}