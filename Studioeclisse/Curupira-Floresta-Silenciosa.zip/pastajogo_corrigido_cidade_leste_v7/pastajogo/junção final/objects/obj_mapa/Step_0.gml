var near_player = point_distance(x, y, obj_player_unificado.x, obj_player_unificado.y) <= interact_range;
if (near_player && keyboard_check_pressed(ord("E")) && !global.map_picked) {
    global.map_picked = true;
    global.casa_stage = 2;
    instance_destroy();
}