                                                               
tempo_auto_reset--;

                                
alpha_texto += alpha_dir;
if (alpha_texto <= 0.2) alpha_dir = 0.02;
if (alpha_texto >= 1.0) alpha_dir = -0.02;

                                                                          
var apertou_botao = keyboard_check_pressed(vk_anykey) 
                 || mouse_check_button_pressed(mb_any) 
                 || gamepad_button_check_pressed(0, gp_face1) 
                 || gamepad_button_check_pressed(0, gp_start);

                                                                         
if (apertou_botao || tempo_auto_reset <= 0)
{
                                                                                           
    game_restart();
}