draw_set_font(yes);
var gui_w = display_get_gui_width();
var gui_h = display_get_gui_height();

draw_set_halign(fa_center);
draw_set_valign(fa_middle);

                           
draw_set_color(c_white);
draw_text_transformed(gui_w / 2, gui_h / 2 - 60, "FIM DA DEMO", 2.5, 2.5, 0);

draw_set_color(c_ltgray);
draw_text(gui_w / 2, gui_h / 2, "Obrigado por jogar!");

                                                     
draw_set_alpha(alpha_texto);
draw_set_color(c_yellow);
draw_text_transformed(gui_w / 2, gui_h / 2 + 70, "PRESSIONE QUALQUER TECLA PARA JOGAR", 1.2, 1.2, 0);
draw_set_alpha(1);                                             

                                                    
var segundos_restantes = ceil(tempo_auto_reset / 60);
draw_set_color(c_gray);
draw_text(gui_w / 2, gui_h - 40, "Reiniciando automaticamente em " + string(segundos_restantes) + "s");

                                          
draw_set_halign(fa_left);
draw_set_valign(fa_top);