                                                                              
tempo_auto_reset = 30 * 60; 

                                      
alpha_texto = 1;
alpha_dir = -0.02;