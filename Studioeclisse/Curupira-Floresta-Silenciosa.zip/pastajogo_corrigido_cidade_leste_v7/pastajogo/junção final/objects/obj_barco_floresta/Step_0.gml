var near_player = point_distance(x, y, obj_player_unificado.x, obj_player_unificado.y) <= interact_range;

if (near_player && keyboard_check_pressed(ord("R")) && global.objective_done && !global.wood_delivered) {
    global.wood_delivered = true;
    room_goto(rm_cutscene_parte2_fernando);
}