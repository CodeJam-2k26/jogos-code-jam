                       
if (!game_over && itens_coletados >= total_itens_necessarios) {
    itens_coletados = total_itens_necessarios;
    timer_ativo = false;
    saida_liberada = true;
    global.vila_pecas_reunidas = true;
}

if (timer_ativo && !game_over) {
    tempo_restante -= delta_time / 1000000;                                     
    
                                    
    if (tempo_restante <= 0)
    {
        tempo_restante = 0;
        timer_ativo = false;
        game_over = true;
        if (instance_exists(obj_player_unificado)) {
            obj_player_unificado.can_move = false;
        }
    }
}

// O jogador pode começar a tentativa novamente sem precisar fechar o jogo.
if (game_over && mouse_check_button_pressed(mb_left)) {
    var _mx = device_mouse_x_to_gui(0);
    var _my = device_mouse_y_to_gui(0);
    var _gw = display_get_gui_width();
    var _gh = display_get_gui_height();
    if (_mx >= _gw * 0.5 - 90 && _mx <= _gw * 0.5 + 90
        && _my >= _gh * 0.5 + 10 && _my <= _gh * 0.5 + 60) {
        room_restart();
    }
}
