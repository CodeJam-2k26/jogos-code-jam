                                           
// O HUD persistente desenha a interface principal da vila. Este evento fica
// como fallback para salas abertas sem RoomCreationCode.
if (instance_exists(obj_aviso)) exit;

draw_set_alpha(1);
draw_set_font(yes);                                                
draw_set_color(c_white);
draw_set_halign(fa_left);
draw_set_valign(fa_top);

                                                         
var _texto_itens = "Peças encontradas: " + string(itens_coletados) + "/" + string(total_itens_necessarios);
var _gui_w = display_get_gui_width();
var _gui_h = display_get_gui_height();
// Deixa a primeira linha para o objetivo amarelo persistente.
draw_text_ext(16, 56, _texto_itens, -1, max(1, min(_gui_w * 0.58, _gui_w - 32)));

                                        
var _minutos = floor(tempo_restante / 60);
var _segundos = floor(tempo_restante mod 60);
var _str_min = (_minutos < 10) ? "0" + string(_minutos) : string(_minutos);
var _str_seg = (_segundos < 10) ? "0" + string(_segundos) : string(_segundos);

                                            
var _texto_timer = "Tempo: " + _str_min + ":" + _str_seg;
                                                                           
if (tempo_restante <= 60) {
    draw_set_color(c_red);
}

draw_set_halign(fa_right);
if (!saida_liberada) draw_text(_gui_w - 16, 56, _texto_timer);
draw_set_halign(fa_left);

if (saida_liberada && !game_over) {
    draw_set_halign(fa_center);
    draw_set_color(c_yellow);
    draw_text_ext(_gui_w * 0.5, 56, "Peças reunidas! Siga para o acampamento pela direita.", -1, max(1, _gui_w - 32));
    draw_set_halign(fa_left);
}

if (game_over) {
    draw_set_alpha(0.88);
    draw_set_color(c_black);
    draw_rectangle(0, 0, _gui_w, _gui_h, false);
    draw_set_alpha(1);
    draw_set_halign(fa_center);
    draw_set_color(c_red);
    draw_set_valign(fa_middle);
    draw_text_ext(_gui_w / 2, _gui_h / 2, "VOCÊ FOI PEGO PELO CURUPIRA!", -1, max(1, _gui_w - 32));
    draw_set_color(c_dkgray);
    draw_rectangle(_gui_w * 0.5 - 90, _gui_h * 0.5 + 10, _gui_w * 0.5 + 90, _gui_h * 0.5 + 60, false);
    draw_set_color(c_yellow);
    draw_text(_gui_w * 0.5, _gui_h * 0.5 + 35, "Reiniciar");
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
}

                             
draw_set_color(c_white);
