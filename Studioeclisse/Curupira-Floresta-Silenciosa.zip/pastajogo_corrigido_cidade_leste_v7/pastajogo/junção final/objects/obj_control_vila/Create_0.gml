                           
total_itens_necessarios = 3;                                        
itens_coletados = 0;
cutscene_estado = 0;

                                            
lista_itens = [];

                           
                                                                                                                               
tempo_restante = 300; 
timer_ativo = true;
game_over = false;
saida_liberada = false;
if (!variable_global_exists("vila_pecas_reunidas")) global.vila_pecas_reunidas = false;
if (global.vila_pecas_reunidas) {
    itens_coletados = total_itens_necessarios;
    tempo_restante = 0;
    timer_ativo = false;
    saida_liberada = true;
}
