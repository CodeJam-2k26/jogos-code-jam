hits_needed = 3;
hits_taken = 0;