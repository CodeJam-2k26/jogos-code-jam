// A room tinha dois controladores iguais. Apenas um pode consumir a tecla R,
// senão duas pedras são lançadas no mesmo pressionamento.
if (id != instance_find(obj_noite3_controle, 0)) exit;

if (global.player_morto) {
    var dw = display_get_gui_width();
    var dh = display_get_gui_height();
    var clicou = false;

    if (mouse_check_button_pressed(mb_left)) {
        var mx = device_mouse_x_to_gui(0);
        var my = device_mouse_y_to_gui(0);
        clicou = point_in_rectangle(mx, my, dw/2 - 90, dh/2, dw/2 + 90, dh/2 + 50);
    }

    if (clicou || keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space)) {
        global.player_morto = false;
        if (instance_exists(obj_player_unificado)) {
            with (obj_player_unificado) {
                x = 544;
                y = 352;
                spawn_x = 544;
                spawn_y = 352;
                hp = hp_max;
                invincible_timer = 60;
                visible = true;
                image_alpha = 1;
                sprite_index = spr_player_frente;
                image_index = 0;
                flashlight_on = true;
                flashlight_hint_shown = true;
                can_move = true;
            }
        }
    }
    exit;
}

if (keyboard_check_pressed(ord("R")) && global.pedras > 0 && !global.consertando) {
    global.pedras -= 1;

    var dist = min(250, point_distance(obj_player_unificado.x, obj_player_unificado.y, mouse_x, mouse_y));
    var d = point_direction(obj_player_unificado.x, obj_player_unificado.y, mouse_x, mouse_y);

    var p = instance_create_depth(obj_player_unificado.x, obj_player_unificado.y, -50, obj_pedra_arremessada);
    p.destino_x = obj_player_unificado.x + lengthdir_x(dist, d);
    p.destino_y = obj_player_unificado.y + lengthdir_y(dist, d);
}

