if (id != instance_find(obj_noite3_controle, 0)) exit;

draw_set_font(yes);
var gw = display_get_gui_width();
var gh = display_get_gui_height();

draw_set_color(c_white);
draw_text(20, 60, "Pedras: " + string(global.pedras));
draw_set_color(c_gray);
if (global.pedras > 0) {
    draw_text(20, 80, "R: arremessar pedra para distrair o Curupira");
} else {
    draw_text(20, 80, "Q: pegar pedras para distrair o Curupira");
}
var _monstro_hud = instance_find(obj_monstro_noite, 0);
if (_monstro_hud != noone
    && variable_instance_exists(_monstro_hud, "distracao_timer")
    && _monstro_hud.distracao_timer > 0) {
    draw_set_color(c_yellow);
    draw_text(20, 100, "Curupira distraído!");
}
draw_set_color(c_white);

                    
if (global.conserto_prog > 0) {
    draw_set_color(c_dkgray);
    draw_rectangle(gw/2 - 100, gh - 90, gw/2 + 100, gh - 74, false);
    draw_set_color(c_yellow);
    draw_rectangle(gw/2 - 100, gh - 90, gw/2 - 100 + 200 * global.conserto_prog, gh - 74, false);
    draw_set_color(c_white);
    draw_rectangle(gw/2 - 100, gh - 90, gw/2 + 100, gh - 74, true);
}

             
for (var i = 0; i < 3; i++) {
    var cx = gw/2 - 40 + i * 40;
    var cy = gh - 40;
    draw_set_color(c_dkgray);
    draw_circle(cx, cy, 12, false);
    if (i < global.barco_consertos) {
        draw_set_color(c_lime);
        draw_circle(cx, cy, 12, false);
    }
    draw_set_color(c_white);
    draw_circle(cx, cy, 12, true);
}
draw_set_color(c_white);

if (global.perto_barco) {
    draw_set_halign(fa_center);
    draw_set_color(c_yellow);
    draw_text(gw/2, gh - 130, "Segure E para consertar o barco");
    draw_set_halign(fa_left);
    draw_set_color(c_white);
}
if (global.player_morto) {
    draw_set_color(c_black);
    draw_set_alpha(0.85);
    draw_rectangle(0, 0, gw, gh, false);
    draw_set_alpha(1);

    draw_set_halign(fa_center);
    draw_set_color(c_red);
    draw_text(gw/2, gh/2 - 80, "VOCÊ MORREU");
    draw_set_color(c_dkgray);
    draw_rectangle(gw/2 - 90, gh/2, gw/2 + 90, gh/2 + 50, false);
    draw_set_color(c_white);
    draw_text(gw/2, gh/2 + 15, "Renascer");
    draw_set_halign(fa_left);
}
