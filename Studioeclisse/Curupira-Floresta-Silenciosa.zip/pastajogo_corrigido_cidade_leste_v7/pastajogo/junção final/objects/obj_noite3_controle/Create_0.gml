depth = -10000;

// rm_acampamento_noite3 herda a criação da room e o GameMaker descarta o
// RoomCreationCode dela ao salvar. Por isso o spawn precisa ficar em um objeto
// que pertence à própria sala, e não apenas no arquivo de criação solto.
if (id != instance_find(obj_noite3_controle, 0)) exit;

global.is_night = true;
global.pedras = 0;
global.barco_consertos = 0;
global.conserto_prog = 0;
global.consertando = false;
global.perto_barco = false;
global.barulho_ativo = false;
global.barulho_x = 0;
global.barulho_y = 0;
global.em_cutscene = false;
global.player_hidden = false;
global.player_morto = false;

if (instance_exists(obj_player_unificado)) {
    with (obj_player_unificado) {
        // Esta faixa é areia firme, bem antes da primeira coluna de água.
        x = 544;
        y = 352;
        spawn_x = 544;
        spawn_y = 352;
        can_move = true;
        visible = true;
        image_alpha = 1;
        image_xscale = 1;
        image_yscale = 1;
        sprite_index = spr_player_frente;
        image_index = 0;
        flashlight_on = true;
        flashlight_hint_shown = true;
        hp = hp_max;
    }
}
