                               
window_set_size(1280, 720);

velh = 0
velv = 0
vel = 1