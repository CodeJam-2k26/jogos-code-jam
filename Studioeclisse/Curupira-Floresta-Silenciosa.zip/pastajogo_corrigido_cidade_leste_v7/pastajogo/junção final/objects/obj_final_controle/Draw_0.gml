// Mar e margem da cena final. São usados os próprios tiles do jogo para não
// parecer uma faixa lisa e desconectada do restante do mapa.
if (room != rm_final1) exit;

draw_set_alpha(1);
for (var _agua_y = 0; _agua_y < room_height; _agua_y += 32) {
    for (var _agua_x = 704; _agua_x < room_width; _agua_x += 32) {
        draw_sprite(spr_agua, 0, _agua_x, _agua_y);
    }
}

// A praia avança um pouco no meio da tela e recua nas extremidades, criando
// uma margem curva em vez de uma parede reta entre terra e mar.
for (var _y = 0; _y < room_height; _y += 32) {
    var _praia_x = 688 + floor(abs(_y - room_height * 0.5) / 64) * 16;
    _praia_x = min(_praia_x, 784);
    for (var _x = _praia_x; _x < 848; _x += 32) {
        draw_sprite(spr_areia, 0, _x, _y);
    }

    // Espuma discreta onde a água encontra a areia.
    draw_set_color(make_color_rgb(165, 211, 224));
    draw_line(_praia_x - 12, _y + 10, _praia_x - 2, _y + 10);
    draw_line(_praia_x - 6, _y + 18, _praia_x + 4, _y + 18);
}

draw_set_color(c_white);
draw_set_alpha(1);
