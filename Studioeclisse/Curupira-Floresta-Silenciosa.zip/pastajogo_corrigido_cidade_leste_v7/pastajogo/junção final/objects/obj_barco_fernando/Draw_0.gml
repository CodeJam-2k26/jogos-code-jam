draw_set_font(yes);
draw_self();

var near_player = room != rm_final1
    && distance_to_object(obj_player_unificado) <= interact_range;

if (near_player) {
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_set_color(c_white);
    if (global.hunters_called >= 3) {
        draw_text(x, y - 50, "Aperte E para ir para floresta");
    } else {
        draw_text(x, y - 50, "Chame os outros caçadores primeiro (" + string(global.hunters_called) + "/3)");
    }
}




if (near_player) {
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_set_color(c_white);
	 }
    
