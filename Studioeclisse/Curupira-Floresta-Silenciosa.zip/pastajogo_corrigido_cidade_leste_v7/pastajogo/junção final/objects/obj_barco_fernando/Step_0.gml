// No encerramento este barco é cenário: não pode abrir a rota antiga nem
// exibir a interação dos caçadores.
var near_player = room != rm_final1
    && distance_to_object(obj_player_unificado) <= interact_range;

if (near_player && keyboard_check_pressed(ord("E")) && global.hunters_called >= 3) {
    room_goto(rm_cutscene_parte1b_fernando);
}
