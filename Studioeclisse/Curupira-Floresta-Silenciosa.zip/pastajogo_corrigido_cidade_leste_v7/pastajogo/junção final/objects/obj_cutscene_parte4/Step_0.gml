                                   
if (fade_state == "in") {
    fade_alpha -= 0.02;
    if (fade_alpha <= 0) {
        fade_alpha = 0;
        fade_state = "idle";                                        
    }
}

                                                          
if (fade_state == "idle") {
    if (keyboard_check_pressed(vk_space) || keyboard_check_pressed(ord("E"))) {
        fade_state = "out";                      
    }
}

                                                                  
if (fade_state == "out") {
    fade_alpha += 0.02;
    if (fade_alpha >= 1) {
        fade_alpha = 1;
        current_page += 1;                             

        if (current_page >= total_pages) {
            if (instance_exists(obj_player_unificado)) {
                with (obj_player_unificado) {
                    x = 388;
                    y = 292;
                    spawn_x = 388;
                    spawn_y = 292;
                }
            }
            global.em_cutscene = false;
            global.estado_jogo = "gameplay";
            if (instance_exists(obj_player_unificado)) {
                obj_player_unificado.visible = true;
                obj_player_unificado.image_alpha = 1;
                obj_player_unificado.can_move = true;
            }
            // O aviso de objetivo é persistente; não o destrua ao trocar de sala.
            room_goto(rm_acampamento_noite2);                                            
            exit;
        } else {
            fade_state = "in";                                     
        }
    }
}
