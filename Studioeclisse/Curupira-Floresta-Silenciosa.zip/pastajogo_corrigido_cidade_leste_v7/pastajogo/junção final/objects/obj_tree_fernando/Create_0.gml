interact_range = 40;
chop_timer = 0;
chop_duration = 300;                                                                
being_chopped = false;