if (global.trees_cut >= global.trees_goal) {
    being_chopped = false;
    chop_timer = 0;
    exit;
}

var near_player = instance_exists(obj_player_unificado)
    && distance_to_object(obj_player_unificado) <= interact_range;

if (near_player && keyboard_check(ord("E"))) {
    being_chopped = true;
    chop_timer += 1;

    if (chop_timer >= chop_duration) {
        instance_destroy();
        global.trees_cut = min(global.trees_cut + 1, global.trees_goal);
    }
} else {
    being_chopped = false;
    chop_timer = 0;
}