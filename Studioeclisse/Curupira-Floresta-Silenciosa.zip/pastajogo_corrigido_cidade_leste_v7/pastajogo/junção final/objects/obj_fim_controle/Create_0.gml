depth = -10000;
tempo_espera = 0;
exibir_novo_jogo = true;
alpha_texto = 1;
alpha_dir = -0.02;
