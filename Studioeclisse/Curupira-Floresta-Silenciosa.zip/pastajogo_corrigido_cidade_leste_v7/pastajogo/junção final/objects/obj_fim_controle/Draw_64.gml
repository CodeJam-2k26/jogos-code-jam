draw_set_font(yes);
var dw = display_get_gui_width();
var dh = display_get_gui_height();

draw_set_color(c_black);
draw_rectangle(0, 0, dw, dh, false);

draw_set_halign(fa_center);
draw_set_valign(fa_middle);
draw_set_color(c_white);
draw_text_transformed(dw / 2, dh / 2, "FIM", 4, 4, 0);
draw_set_halign(fa_left);
draw_set_valign(fa_top);