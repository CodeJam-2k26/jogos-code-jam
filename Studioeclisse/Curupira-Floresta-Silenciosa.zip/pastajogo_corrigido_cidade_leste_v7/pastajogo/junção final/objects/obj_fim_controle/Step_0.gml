                                      
if (tempo_espera > 0)
{
    tempo_espera--;
    if (tempo_espera <= 0)
    {
        exibir_novo_jogo = true;                                   
    }
}

                                                              
if (exibir_novo_jogo)
{
                               
    alpha_texto += alpha_dir;
    if (alpha_texto <= 0.2) alpha_dir = 0.03;
    if (alpha_texto >= 1.0) alpha_dir = -0.03;

                                                      
    var apertou = keyboard_check_pressed(vk_anykey) || mouse_check_button_pressed(mb_any);
    
    if (apertou)
    {
        game_restart();                                      
    }
}