draw_set_alpha(1);
draw_set_color(c_white);
draw_set_font(yes);
var gui_w = display_get_gui_width();
var gui_h = display_get_gui_height();

draw_set_color(c_black);
draw_rectangle(0, 0, gui_w, gui_h, false);

if (current_page < total_pages) {
    draw_set_color(c_white);
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    var _story_w = max(1, min(gui_w - 32, gui_w * 0.82));
    var _story_h = string_height_ext(story_text[current_page], -1, _story_w);
    var _story_y = clamp(gui_h * 0.45, 12 + _story_h * 0.5, gui_h - 64 - _story_h * 0.5);
    draw_text_ext(gui_w / 2, _story_y, story_text[current_page], -1, _story_w);
    draw_text(gui_w / 2, gui_h - 32, "Pressione ESPAÇO para continuar");
}

draw_set_alpha(fade_alpha);
draw_set_color(c_black);
draw_rectangle(0, 0, gui_w, gui_h, false);
draw_set_alpha(1);

// Restaura o estado de desenho para evitar texto desalinhado em outras interfaces.
draw_set_alpha(1);
draw_set_color(c_white);
draw_set_halign(fa_left);
draw_set_valign(fa_top);
