// Barco a vapor do píer -> cutscene da viagem até a floresta (rm_cutscene_intro_fernando).
// O gatilho fica no próprio barco para não depender do bloco de movimento do jogador.
if (!instance_exists(obj_player_unificado)) exit;

if (!global.em_cutscene
    && distance_to_object(obj_player_unificado) < 48
    && keyboard_check_pressed(ord("E"))) {
    room_goto(rm_cutscene_intro_fernando);
}
