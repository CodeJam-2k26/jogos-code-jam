depth = -50000; // cutscene sempre acima de HUD, aviso, fader e neblina
global.em_cutscene = true;
global.estado_jogo = "cutscene";
if (instance_exists(obj_player_unificado)) {
    obj_player_unificado.can_move = false;
    obj_player_unificado.visible = true;
    obj_player_unificado.image_alpha = 1;
}
                                         
texto_narrativa = "As três peças estão reunidas.\n\nAgora precisamos voltar ao acampamento e consertar o barco antes do amanhecer.\n\nO Curupira ainda está por perto...";

                                                             
caractere_atual = 0;
velocidade_digitacao = 0.5;                                              
// Evita que uma tecla usada na sala anterior pule a cena inteira ao chegar.
entrada_bloqueada = 15;
proxima_sala = rm_acampamento_noite3;
