                                        
// Reafirma o estado enquanto a cena estiver ativa, inclusive se algum
// objeto persistente tentar limpar o estado global ao trocar de room.
global.em_cutscene = true;
global.estado_jogo = "cutscene";
if (instance_exists(obj_player_unificado)) obj_player_unificado.can_move = false;

if (caractere_atual < string_length(texto_narrativa)) {
    caractere_atual += velocidade_digitacao;
}

if (entrada_bloqueada > 0) entrada_bloqueada -= 1;

// A primeira fração de segundo ignora a tecla que trouxe o jogador até aqui.
if (entrada_bloqueada <= 0
    && (keyboard_check_pressed(vk_space) || keyboard_check_pressed(ord("E")))) {
                                                                    
    if (caractere_atual < string_length(texto_narrativa)) {
        caractere_atual = string_length(texto_narrativa);
    } else {
        global.em_cutscene = false;
        global.estado_jogo = "gameplay";
        global.vila_pecas_reunidas = true;
        if (instance_exists(obj_player_unificado)) {
            with (obj_player_unificado) {
                visible = true;
                image_alpha = 1;
                can_move = true;
            }
        }
        room_goto(proxima_sala);
    }
}
