draw_set_alpha(1);
draw_set_color(c_white);
draw_set_font(yes);
var _gui_w = display_get_gui_width();
var _gui_h = display_get_gui_height();

                                
draw_set_color(c_black);
draw_rectangle(0, 0, _gui_w, _gui_h, false);

                                              
draw_set_color(c_white);
draw_set_halign(fa_center);
draw_set_valign(fa_middle);

                                                                               
var _texto_exibido = string_copy(texto_narrativa, 1, floor(caractere_atual));
var _texto_largura = max(1, min(_gui_w - 48, _gui_w * 0.82));
var _texto_altura = string_height_ext(_texto_exibido, 16, _texto_largura);
var _texto_y = clamp(_gui_h * 0.45, 12 + _texto_altura * 0.5, _gui_h - 52 - _texto_altura * 0.5);

                                              
draw_text_ext(_gui_w / 2, _texto_y, _texto_exibido, 16, _texto_largura);

                                                                     
if (caractere_atual >= string_length(texto_narrativa)) {
    draw_set_color(c_gray);
    draw_text(_gui_w / 2, _gui_h - 18, "[ Pressione ESPAÇO para continuar ]");
}

                         
draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_set_color(c_white);
