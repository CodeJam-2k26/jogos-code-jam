draw_set_font(yes);
var gui_w = display_get_gui_width();
var gui_h = display_get_gui_height();

                   
// O aviso inicial cobre somente as missões 0 a 2. A partir da chegada ao
// acampamento, a missão vem deste HUD mesmo se uma instância antiga do aviso
// persistir entre as salas.
if (!instance_exists(obj_aviso)) {
    var obj_x = gui_w - 20;
    var obj_y = 20;

    draw_set_halign(fa_right);
    draw_set_valign(fa_top);
    draw_set_color(c_white);
    var _objective_text = "";

    if (room == rm_final1 || room == rm_fim) {
                                          
    } else if (room == rm_acampamento_noite3) {
        _objective_text = "Objetivo: Consertar o barco (" + string(global.barco_consertos) + "/3)";
    } else if (!global.objective_done) {
        _objective_text = "Objetivo: Derrubar árvores (" + string(global.trees_cut) + "/" + string(global.trees_goal) + ")";
    } else if (!global.wood_delivered) {
        _objective_text = "Objetivo: Levar a madeira até o barco";
    } else if (global.camp_stage == 0 && !global.camp_has_wood) {
        _objective_text = "Objetivo: Pegar a madeira no barco";
    } else if (global.camp_stage == 0 && global.camp_has_wood) {
        _objective_text = "Objetivo: Levar a madeira até a fogueira";
    } else if (global.camp_stage == 1) {
        _objective_text = "Objetivo: Assar a carne";
    } else if (global.camp_stage == 2) {
        _objective_text = "Objetivo: Pegar a carne assada";
    } else if (global.camp_stage == 3) {
        _objective_text = "Objetivo: Comer com os amigos";
    } else if (global.camp_stage == 4) {
        _objective_text = "Objetivo: Apagar a fogueira";
    } else if (global.camp_stage == 5 && !global.has_slept) {
        _objective_text = "Objetivo: Ir dormir";
    } else if (global.has_slept && !global.arrived_at_cabin2) {
        _objective_text = "Objetivo: Ir até a outra cabana";
    } else if (global.arrived_at_cabin2 && !global.lamp_analyzed) {
        _objective_text = "Objetivo: Procurar seu parceiro";
    } else if (global.casa_stage == 1) {
        _objective_text = "Objetivo: Explorar a casa";
    } else if (global.casa_stage == 2) {
        _objective_text = "Objetivo: Esconda-se!";
    } else if (global.casa_stage == 3) {
        _objective_text = "Objetivo: Ir até a vila";
    } else if (global.lamp_analyzed) {
        _objective_text = "Objetivo: Entrar na casa";
    }

    if (_objective_text != "") {
        var _objective_w = max(1, min(520, gui_w - 40));
        draw_text_ext(obj_x, obj_y, _objective_text, -1, _objective_w);
    }
}

draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_set_color(c_white);

                                                                                            
if (global.is_night) {
    if (!flashlight_hint_shown) {
        draw_set_halign(fa_center);
        draw_set_color(c_white);
        draw_text(gui_w / 2, 50, "Pressione Q para acender a lanterna");
        draw_set_halign(fa_left);
        if (flashlight_on) flashlight_hint_shown = true;
    }

    if (!flashlight_on) {
        draw_set_alpha(0.85);
        draw_set_color(c_black);
        draw_rectangle(0, 0, gui_w, gui_h, false);
        draw_set_alpha(1);
    } else {
        if (!surface_exists(light_surf)
            || surface_get_width(light_surf) != gui_w
            || surface_get_height(light_surf) != gui_h) {
            if (surface_exists(light_surf)) surface_free(light_surf);
            light_surf = surface_create(gui_w, gui_h);
        }

        if (surface_exists(light_surf)) {
            var cam = view_camera[0];
            var cam_x = camera_get_view_x(cam);
            var cam_y = camera_get_view_y(cam);
            var cam_w = max(1, camera_get_view_width(cam));
            var scale = gui_w / cam_w;
            var px = (x - cam_x) * scale;
            var py = (y - cam_y) * scale;
            var light_radius = 160 * scale;
            var steps = 10;

            surface_set_target(light_surf);
            draw_clear_alpha(c_black, 0.85);
            gpu_set_blendmode(bm_subtract);
            draw_set_color(c_white);
            for (var i = 0; i < steps; i++) {
                var r = light_radius * (1 - i / steps);
                draw_set_alpha(0.9 / steps);
                draw_circle(px, py, r, false);
            }
            gpu_set_blendmode(bm_normal);
            draw_set_alpha(1);
            surface_reset_target();
            draw_surface(light_surf, 0, 0);
        }
    }
}

                                                                                           
var _cam = view_camera[0];
var _cam_x = camera_get_view_x(_cam);
var _cam_y = camera_get_view_y(_cam);
var _cam_w = max(1, camera_get_view_width(_cam));
var _cam_h = max(1, camera_get_view_height(_cam));
var _scale_x = gui_w / _cam_w;
var _scale_y = gui_h / _cam_h;
var _hint_obj = noone;
var _hint_text = "";
var _hint_dist = 1000000000;
var _candidate = noone;
var _candidate_dist = 0;
var _candidate_text = "";

                         
_candidate = instance_nearest(x, y, obj_tree_fernando);
if (_candidate != noone && global.trees_cut < global.trees_goal
    && variable_instance_exists(_candidate, "being_chopped")
    && !_candidate.being_chopped) {
    _candidate_dist = point_distance(x, y, _candidate.x, _candidate.y);
    if (_candidate_dist <= _candidate.interact_range && _candidate_dist < _hint_dist) {
        _hint_obj = _candidate;
        _hint_text = "Segure E para derrubar";
        _hint_dist = _candidate_dist;
    }
}

                       
_candidate = instance_nearest(x, y, obj_barco_acampamento);
if (_candidate != noone) {
    _candidate_dist = distance_to_object(_candidate);
    _candidate_text = "";
    if (!global.objective_done) {
        _candidate_text = "Corte as árvores primeiro (" + string(global.trees_cut) + "/" + string(global.trees_goal) + ")";
    } else if (!global.wood_delivered) {
        _candidate_text = "Aperte E para colocar a madeira";
    } else if (global.camp_stage == 0 && !global.camp_has_wood) {
        _candidate_text = "Aperte E para pegar a madeira";
    }
    if (_candidate_text != "" && _candidate_dist <= _candidate.interact_range && _candidate_dist < _hint_dist) {
        _hint_obj = _candidate;
        _hint_text = _candidate_text;
        _hint_dist = _candidate_dist;
    }
}

                    
_candidate = instance_nearest(x, y, obj_barco_floresta);
if (_candidate != noone) {
    _candidate_dist = point_distance(x, y, _candidate.x, _candidate.y);
    _candidate_text = "";
    if (global.objective_done && !global.wood_delivered) {
        _candidate_text = "Pressione R para colocar a madeira";
    } else if (!global.objective_done) {
        _candidate_text = "Corte as árvores primeiro (" + string(global.trees_cut) + "/" + string(global.trees_goal) + ")";
    }
    if (_candidate_text != "" && _candidate_dist <= _candidate.interact_range && _candidate_dist < _hint_dist) {
        _hint_obj = _candidate;
        _hint_text = _candidate_text;
        _hint_dist = _candidate_dist;
    }
}

           
_candidate = instance_nearest(x, y, obj_fogueira);
if (_candidate != noone) {
    _candidate_dist = point_distance(x, y, _candidate.x, _candidate.y);
    _candidate_text = "";
    if (global.camp_stage == 0 && global.camp_has_wood) {
        _candidate_text = "Aperte E para colocar a lenha";
    } else if (global.camp_stage == 1 && !_candidate.roasting) {
        _candidate_text = "Pressione R para assar a carne";
    } else if (global.camp_stage == 2) {
        _candidate_text = "Pressione R para pegar a carne";
    } else if (global.camp_stage == 3 && !_candidate.eating) {
        _candidate_text = "Pressione R para comer com os amigos";
    } else if (global.camp_stage == 4) {
        _candidate_text = "Aperte E para apagar a fogueira";
    }
    if (_candidate_text != "" && _candidate_dist <= _candidate.interact_range && _candidate_dist < _hint_dist) {
        _hint_obj = _candidate;
        _hint_text = _candidate_text;
        _hint_dist = _candidate_dist;
    }
}

                     
// Barco a vapor do píer: E para embarcar (cutscene da viagem).
_candidate = instance_nearest(x, y, obj_barco_vapor);
if (_candidate != noone) {
    _candidate_dist = distance_to_object(_candidate);
    if (_candidate_dist < 48 && _candidate_dist < _hint_dist) {
        _hint_obj = _candidate;
        _hint_text = "Aperte E para embarcar";
        _hint_dist = _candidate_dist;
    }
}

// Dormir: distância até a caixa de colisão de cada cabana (escalada, origem no canto).
if (global.camp_stage == 5 && !global.has_slept) {
    for (var _cab_i = 0; _cab_i < instance_number(obj_cabana); _cab_i++) {
        _candidate = instance_find(obj_cabana, _cab_i);
        _candidate_dist = distance_to_object(_candidate);
        if (_candidate_dist <= _candidate.interact_range && _candidate_dist < _hint_dist) {
            _hint_obj = _candidate;
            _hint_text = "Aperte E para dormir";
            _hint_dist = _candidate_dist;
        }
    }
}

                              
_candidate = instance_nearest(x, y, obj_cabana2);
if (_candidate != noone) {
    _candidate_dist = distance_to_object(_candidate);
    if (!global.arrived_at_cabin2 && _candidate_dist <= _candidate.interact_range && _candidate_dist < _hint_dist) {
        _hint_obj = _candidate;
        _hint_text = "Aperte E para acordar os outros";
        _hint_dist = _candidate_dist;
    }
}

          
_candidate = instance_nearest(x, y, obj_lampiao);
if (_candidate != noone) {
    _candidate_dist = distance_to_object(_candidate);
    if (global.arrived_at_cabin2 && !global.lamp_analyzed
        && _candidate_dist <= _candidate.interact_range && _candidate_dist < _hint_dist) {
        _hint_obj = _candidate;
        _hint_text = "Aperte E para analisar";
        _hint_dist = _candidate_dist;
    }
}

                  
_candidate = instance_nearest(x, y, obj_pedra);
if (_candidate != noone) {
    _candidate_dist = point_distance(x, y, _candidate.x, _candidate.y);
    if (_candidate_dist <= 40 && _candidate_dist < _hint_dist) {
        _hint_obj = _candidate;
        _hint_text = "Q: pegar pedra";
        _hint_dist = _candidate_dist;
    }
}

                     
_candidate = instance_nearest(x, y, obj_casinha_entrada);
if (_candidate != noone) {
    _candidate_dist = point_distance(x, y, _candidate.x, _candidate.y);
    if (_candidate_dist <= _candidate.interact_range && _candidate_dist < _hint_dist) {
        _hint_obj = _candidate;
        _hint_text = "Aperte E para entrar";
        _hint_dist = _candidate_dist;
    }
}

                      
_candidate = instance_nearest(x, y, obj_esconderijo);
if (_candidate != noone) {
    _candidate_dist = point_distance(x, y, _candidate.x, _candidate.y);
    if (global.casa_alerta && !global.player_hidden && _candidate_dist <= 60 && _candidate_dist < _hint_dist) {
        _hint_obj = _candidate;
        _hint_text = "Aperte E para se esconder";
        _hint_dist = _candidate_dist;
    }
}

                                         
_candidate = instance_nearest(x, y, obj_teste);
if (_candidate != noone) {
    _candidate_dist = point_distance(x, y, _candidate.x, _candidate.y);
    if (_candidate_dist <= 60 && _candidate_dist < _hint_dist) {
        _hint_obj = _candidate;
        _hint_text = "E: ir para o final";
        _hint_dist = _candidate_dist;
    }
}

               
_candidate = instance_nearest(x, y, obj_mapa);
if (_candidate != noone) {
    _candidate_dist = point_distance(x, y, _candidate.x, _candidate.y);
    if (!global.map_picked && _candidate_dist <= _candidate.interact_range && _candidate_dist < _hint_dist) {
        _hint_obj = _candidate;
        _hint_text = "Aperte E para pegar o mapa";
        _hint_dist = _candidate_dist;
    }
}

                           
_candidate = instance_nearest(x, y, obj_correa);
if (_candidate != noone) {
    _candidate_dist = point_distance(x, y, _candidate.x, _candidate.y);
    if (_candidate_dist <= _candidate.distancia_interacao && _candidate_dist < _hint_dist) {
        _hint_obj = _candidate;
        _hint_text = "[E] Pegar " + _candidate.nome_item;
        _hint_dist = _candidate_dist;
    }
}

_candidate = instance_nearest(x, y, obj_engrenagem);
if (_candidate != noone) {
    _candidate_dist = point_distance(x, y, _candidate.x, _candidate.y);
    if (_candidate_dist <= _candidate.distancia_interacao && _candidate_dist < _hint_dist) {
        _hint_obj = _candidate;
        _hint_text = "[E] Pegar " + _candidate.nome_item;
        _hint_dist = _candidate_dist;
    }
}

_candidate = instance_nearest(x, y, obj_parafuso);
if (_candidate != noone) {
    _candidate_dist = point_distance(x, y, _candidate.x, _candidate.y);
    if (_candidate_dist <= _candidate.distancia_interacao && _candidate_dist < _hint_dist) {
        _hint_obj = _candidate;
        _hint_text = "[E] Pegar " + _candidate.nome_item;
        _hint_dist = _candidate_dist;
    }
}

                                   
if (!global.em_cutscene && can_move) {
    _candidate = instance_nearest(x, y, obj_porta);
    if (_candidate != noone) {
        _candidate_dist = point_distance(x, y, _candidate.x, _candidate.y);
        if (_candidate_dist < 20 && _candidate_dist < _hint_dist) {
            _hint_obj = _candidate;
            _hint_text = "Aperte E";
            _hint_dist = _candidate_dist;
        }
    }

    _candidate = instance_nearest(x, y, obj_cadeira);
    if (_candidate != noone) {
        _candidate_dist = point_distance(x, y, _candidate.x, _candidate.y);
        if (_candidate_dist < 20 && _candidate_dist < _hint_dist) {
            _hint_obj = _candidate;
            _hint_text = "Aperte E";
            _hint_dist = _candidate_dist;
        }
    }

}

if (_hint_obj != noone && _hint_text != ""
    && (!global.dialogue_open || _hint_obj.object_index == obj_bar)) {
    var _max_w_world = max(1, min(_cam_w - 24, 256));
    var _text_h_world = string_height_ext(_hint_text, -1, _max_w_world);
    var _gui_text_w = _max_w_world * _scale_x;
    var _gui_text_h = _text_h_world * _scale_y;
    var _hint_x = clamp((_hint_obj.x - _cam_x) * _scale_x, _gui_text_w * 0.5 + 8, gui_w - _gui_text_w * 0.5 - 8);
    var _hint_y = clamp((_hint_obj.y - _cam_y - 46) * _scale_y, _gui_text_h * 0.5 + 8, gui_h - _gui_text_h * 0.5 - 8);

    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_set_color(c_black);
    draw_text_ext_transformed(_hint_x + 1, _hint_y + 1, _hint_text, -1, _max_w_world, _scale_x, _scale_y, 0);
    var _hint_color = c_white;
    if (_hint_obj.object_index == obj_mapa || _hint_obj.object_index == obj_correa
        || _hint_obj.object_index == obj_engrenagem || _hint_obj.object_index == obj_parafuso) {
        _hint_color = c_yellow;
    }
    draw_set_color(_hint_color);
    draw_text_ext_transformed(_hint_x, _hint_y, _hint_text, -1, _max_w_world, _scale_x, _scale_y, 0);
}

                                                                   
var _tree_progress = instance_nearest(x, y, obj_tree_fernando);
if (_tree_progress != noone && global.trees_cut < global.trees_goal
    && variable_instance_exists(_tree_progress, "being_chopped")
    && _tree_progress.being_chopped) {
    var _tree_w = 60 * _scale_x;
    var _tree_h = 8 * _scale_y;
    var _tree_x = (_tree_progress.x - _cam_x) * _scale_x;
    var _tree_y = (_tree_progress.y - _cam_y - 32) * _scale_y;
    var _tree_fill = clamp(_tree_progress.chop_timer / max(1, _tree_progress.chop_duration), 0, 1);
    draw_set_color(c_dkgray);
    draw_rectangle(_tree_x - _tree_w / 2, _tree_y - _tree_h / 2, _tree_x + _tree_w / 2, _tree_y + _tree_h / 2, false);
    draw_set_color(c_lime);
    draw_rectangle(_tree_x - _tree_w / 2, _tree_y - _tree_h / 2, _tree_x - _tree_w / 2 + _tree_w * _tree_fill, _tree_y + _tree_h / 2, false);
    draw_set_color(c_white);
    draw_rectangle(_tree_x - _tree_w / 2, _tree_y - _tree_h / 2, _tree_x + _tree_w / 2, _tree_y + _tree_h / 2, true);
}

var _fire_progress = instance_nearest(x, y, obj_fogueira);
if (_fire_progress != noone && (_fire_progress.roasting || _fire_progress.eating)) {
    var _fire_w = 60 * _scale_x;
    var _fire_h = 8 * _scale_y;
    var _fire_x = (_fire_progress.x - _cam_x) * _scale_x;
    var _fire_y = (_fire_progress.y - _cam_y - 32) * _scale_y;
    var _fire_timer = _fire_progress.roasting ? _fire_progress.roast_timer : _fire_progress.eat_timer;
    var _fire_duration = _fire_progress.roasting ? _fire_progress.roast_duration : _fire_progress.eat_duration;
    var _fire_fill = clamp(_fire_timer / max(1, _fire_duration), 0, 1);
    draw_set_color(c_dkgray);
    draw_rectangle(_fire_x - _fire_w / 2, _fire_y - _fire_h / 2, _fire_x + _fire_w / 2, _fire_y + _fire_h / 2, false);
    draw_set_color(c_orange);
    draw_rectangle(_fire_x - _fire_w / 2, _fire_y - _fire_h / 2, _fire_x - _fire_w / 2 + _fire_w * _fire_fill, _fire_y + _fire_h / 2, false);
    draw_set_color(c_white);
    draw_rectangle(_fire_x - _fire_w / 2, _fire_y - _fire_h / 2, _fire_x + _fire_w / 2, _fire_y + _fire_h / 2, true);
}



draw_set_alpha(1);
draw_set_color(c_white);
draw_set_halign(fa_left);
draw_set_valign(fa_top);
