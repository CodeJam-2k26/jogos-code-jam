draw_set_font(yes);
draw_self();

if (room == rm_floresta_fernando && !global.fernando_intro_seen) {
    var _cam = view_camera[0];
    var _view_x = camera_get_view_x(_cam);
    var _view_y = camera_get_view_y(_cam);
    var _view_w = camera_get_view_width(_cam);
    var _view_h = camera_get_view_height(_cam);
    var _bubble_w = min(220, _view_w - 16);
    var _bubble_h = 70;
    var _bubble_x = clamp(x - _bubble_w / 2, _view_x + 8, _view_x + _view_w - _bubble_w - 8);
    var _bubble_y = clamp(y - 82, _view_y + 8, _view_y + _view_h - _bubble_h - 16);
    var _bubble_tip_x = clamp(x, _bubble_x + 12, _bubble_x + _bubble_w - 12);

    draw_set_color(c_white);
    draw_roundrect(_bubble_x, _bubble_y, _bubble_x + _bubble_w, _bubble_y + _bubble_h, false);
    draw_set_color(c_black);
    draw_roundrect(_bubble_x, _bubble_y, _bubble_x + _bubble_w, _bubble_y + _bubble_h, true);
    draw_triangle(_bubble_tip_x - 10, _bubble_y + _bubble_h, _bubble_tip_x + 10, _bubble_y + _bubble_h, _bubble_tip_x, _bubble_y + _bubble_h + 15, false);
    draw_set_color(c_white);
    draw_triangle(_bubble_tip_x - 8, _bubble_y + _bubble_h - 2, _bubble_tip_x + 8, _bubble_y + _bubble_h - 2, _bubble_tip_x, _bubble_y + _bubble_h + 12, false);
    draw_set_color(c_black);
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_text_ext(_bubble_x + _bubble_w / 2, _bubble_y + _bubble_h / 2, intro_dialogue_text, -1, _bubble_w - 20);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_color(c_white);
}


// Evita que alinhamento/cor/transparência vazem para outros textos.
draw_set_alpha(1);
draw_set_color(c_white);
draw_set_halign(fa_left);
draw_set_valign(fa_top);
