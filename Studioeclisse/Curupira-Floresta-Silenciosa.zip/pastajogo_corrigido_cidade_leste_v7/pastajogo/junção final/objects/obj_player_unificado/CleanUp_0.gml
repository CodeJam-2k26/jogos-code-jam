if (variable_instance_exists(id, "light_surf") && surface_exists(light_surf)) {
    surface_free(light_surf);
}