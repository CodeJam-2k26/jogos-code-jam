draw_set_font(yes);
                                                      
var gui_w = display_get_gui_width();
var gui_h = display_get_gui_height();

if (global.txt_aviso > 0)
{
                                                                      
    if (!global.em_cutscene && !global.dialogue_open)
    {
        var _cam = view_camera[0];
        var _cam_w = max(1, camera_get_view_width(_cam));
        var _cam_h = max(1, camera_get_view_height(_cam));
        var _scale_x = gui_w / _cam_w;
        var _scale_y = gui_h / _cam_h;
        var _toast_wrap_world = max(1, min(_cam_w - 24, (gui_w - 40) / _scale_x));
        var _toast_scale_x = 0.5 * _scale_x;
        var _toast_scale_y = 0.5 * _scale_y;
        var _toast_text_h = string_height_ext(mensagem, -1, _toast_wrap_world) * _toast_scale_y;
        var _toast_text_w = min(string_width(mensagem), _toast_wrap_world) * _toast_scale_x;
        var _toast_box_w = min(gui_w - 24, _toast_text_w + 16);
        var _toast_box_h = _toast_text_h + 12;
        var _toast_x = gui_w * 0.5;
        var _toast_y = gui_h - max(12, _toast_box_h * 0.5 + 8);

        draw_set_halign(fa_center);
        draw_set_valign(fa_middle);
        draw_set_color(c_black);
        draw_set_alpha(0.85);
        draw_roundrect(_toast_x - _toast_box_w * 0.5, _toast_y - _toast_box_h * 0.5, _toast_x + _toast_box_w * 0.5, _toast_y + _toast_box_h * 0.5, false);
        draw_set_color(c_white);
        draw_set_alpha(1);
        draw_text_ext_transformed(_toast_x, _toast_y, mensagem, -1, _toast_wrap_world, _toast_scale_x, _toast_scale_y, 0);
    }

    global.txt_aviso--;
}

draw_set_alpha(1);
draw_set_color(c_white);
draw_set_halign(fa_left);
draw_set_valign(fa_top);
