if (!variable_global_exists("em_cutscene")) global.em_cutscene = false;
if (!variable_global_exists("water_cutscene_started")) global.water_cutscene_started = false;
if (!variable_global_exists("cutscene_bar_feita")) global.cutscene_bar_feita = false;

// A entrada do bar só funciona diante da porta. O objeto do prédio tem origem
// no canto superior, portanto usar distance_to_object(obj_bar) tornava a porta
// inalcançável mesmo com o jogador parado na frente dela.
var _na_porta_do_bar = false;
if (room == rm_cutscene_bar_fora && instance_exists(obj_bar)) {
    var _bar_da_entrada = instance_find(obj_bar, 0);
    var _largura_bar = sprite_get_width(_bar_da_entrada.sprite_index) * abs(_bar_da_entrada.image_xscale);
    var _porta_x = _bar_da_entrada.x + (_largura_bar * 0.5);
    // A base visível do sprite fica antes do fim da imagem (há transparência
    // abaixo dela), por isso a caixa da porta usa a base da máscara.
    var _porta_y = _bar_da_entrada.y
        + sprite_get_bbox_bottom(_bar_da_entrada.sprite_index) * abs(_bar_da_entrada.image_yscale);

    _na_porta_do_bar = abs(x - _porta_x) <= 22
        && y >= _porta_y - 20
        && y <= _porta_y + 34;
}

if (room == rm_cutscene_bar_fora
    && !global.cutscene_bar_feita
    && _na_porta_do_bar
    && !instance_exists(obj_cutscene_bar)
    && keyboard_check_pressed(ord("E"))) {
    if (!variable_global_exists("quest") || global.quest < 1) global.quest = 1;
    global.dialogue_open = false;
    global.dialogue_owner = noone;
    can_move = false;
    instance_create_depth(x, y, -50000, obj_cutscene_bar);
    exit;
}
// Recupera a renderizacao normal apos sair de um esconderijo/cutscene.
if (!global.player_hidden && !global.player_morto && !global.em_cutscene) visible = true;
if (room == rm_acampamento_noite3 && !global.player_morto) {
    visible = true;
    can_move = true;
    global.em_cutscene = false;
}
if (room == rm_vila && instance_exists(obj_control_vila)
    && obj_control_vila.cutscene_estado == 0
    && !obj_control_vila.game_over) {
    visible = true;
    can_move = true;
    global.em_cutscene = false;
}
if (global.player_morto) {
    can_move = false;
    exit;
}

if (invincible_timer > 0) invincible_timer -= 1;
if (attack_cooldown > 0) attack_cooldown -= 1;

var _intro_pending = (room == rm_floresta_fernando && !global.fernando_intro_seen);
intro_dialogue_shown = !_intro_pending;
if (_intro_pending) {
    can_move = false;
    if (keyboard_check_pressed(vk_space) || keyboard_check_pressed(ord("E"))) {
        global.fernando_intro_seen = true;
        intro_dialogue_shown = true;
        can_move = true;
    }
}

// Player sempre acima dos tiles/camadas da sala (antes ficava atrás do chão e sumia).
if (depth != -100) depth = -100;
if (!global.player_hidden && !global.player_morto) { image_alpha = 1; image_xscale = abs(image_xscale) < 0.1 ? 1 : image_xscale; image_yscale = abs(image_yscale) < 0.1 ? 1 : image_yscale; }

if (!global.em_cutscene && !global.dialogue_open) {

    if (spawn_lado != "" && room == spawn_room) {
        var _margem = 24;
        switch (spawn_lado) {
            case "direita":  x = _margem; break;
            case "esquerda": x = room_width - _margem; break;
            case "cima":     y = room_height - _margem; break;
            case "baixo":    y = _margem; break;
        }
        spawn_lado = "";
    }

    if (room == rm_cidade_norte && variable_global_exists("norte_ret_valido") && global.norte_ret_valido) {
        x = global.norte_ret_x;
        y = global.norte_ret_y;
        global.norte_ret_valido = false;
    }

    // Colisão centralizada: além dos blocos invisíveis, considera objetos grandes
    // que antes podiam ser atravessados (ou deixar o jogador sobreposto).
    // Colisão pela caixa dos "pés" (o sprite inteiro prendia a cabeça em árvores/paredes)
    // e inclui objetos decorativos que antes eram atravessados.
    var _player_blocked = function(_px, _py) {
        // Depois da cena do bar, libera o vão central da porta. A fachada e
        // a máscara de obj_bar cobriam o mesmo trecho, prendendo o jogador.
        var _porta_bar_aberta = room == rm_cutscene_bar_fora
            && global.cutscene_bar_feita
            && _px >= 466 && _px <= 492
            && _py >= 0 && _py <= 76;

        if (!_porta_bar_aberta
            && collision_rectangle(_px - 5, _py - 5, _px + 5, _py, obj_pai_colision, true, true) != noone) return true;
        var _solidos = solidos_player;
        for (var _i = 0; _i < array_length(_solidos); _i++) {
            if (_porta_bar_aberta && _solidos[_i] == obj_bar) continue;
            if (collision_rectangle(_px - 5, _py - 5, _px + 5, _py, _solidos[_i], true, true) != noone) return true;
        }
        if (colisao_arvores_tile) {
            var _tms = tiles_arvore;
            for (var _t = 0; _t < array_length(_tms); _t++) {
                if (tilemap_get_at_pixel(_tms[_t], _px, _py) != 0
                    || tilemap_get_at_pixel(_tms[_t], _px - 5, _py) != 0
                    || tilemap_get_at_pixel(_tms[_t], _px + 5, _py) != 0) return true;
            }
        }
        return false;
    };

    // Recupera posições inválidas (por exemplo, depois de uma troca de sala ou
    // se uma colisão antiga deixou o personagem parcialmente dentro de um objeto).
    // Procura a posição livre mais próxima sem teleportes grandes.
    if (_player_blocked(x, y)) {
        var _found_free = false;
        var _best_dx = 0;
        var _best_dy = 0;
        var _best_dist = 1000000;
        for (var _oy = -64; _oy <= 64; _oy += 4) {
            for (var _ox = -64; _ox <= 64; _ox += 4) {
                var _dist_sq = _ox * _ox + _oy * _oy;
                if (_dist_sq > 64 * 64 || _dist_sq >= _best_dist) continue;
                if (!_player_blocked(x + _ox, y + _oy)) {
                    _best_dist = _dist_sq;
                    _best_dx = _ox;
                    _best_dy = _oy;
                    _found_free = true;
                }
            }
        }
        if (_found_free) {
            x += _best_dx;
            y += _best_dy;
        }
    }

    var _dir_x = 0;
    var _dir_y = 0;
    var _hspd = 0;
    var _vspd = 0;

    if (auto_walk_active) {
        var _dist_auto = point_distance(x, y, auto_walk_target_x, auto_walk_target_y);
        if (_dist_auto > 4) {
            var _dir_auto = point_direction(x, y, auto_walk_target_x, auto_walk_target_y);
            _dir_x = lengthdir_x(1, _dir_auto);
            _dir_y = lengthdir_y(1, _dir_auto);
        } else {
            auto_walk_pause_timer += 1;
            if (auto_walk_pause_timer >= 60) {
                auto_walk_active = false;
                can_move = true;
                room_goto(rm_acampamento_noite3);
                exit;
            }
        }
    } else if (can_move) {
        var _key_right = keyboard_check(vk_right) || keyboard_check(ord("D"));
        var _key_left = keyboard_check(vk_left) || keyboard_check(ord("A"));
        var _key_down = keyboard_check(vk_down) || keyboard_check(ord("S"));
        var _key_up = keyboard_check(vk_up) || keyboard_check(ord("W"));
        _dir_x = (_key_right ? 1 : 0) - (_key_left ? 1 : 0);
        _dir_y = (_key_down ? 1 : 0) - (_key_up ? 1 : 0);
    }

    // Mantém a mesma velocidade na diagonal e nos eixos retos.
    if (_dir_x != 0 && _dir_y != 0) {
        _dir_x *= 0.70710678;
        _dir_y *= 0.70710678;
    }
    _hspd = _dir_x * vel;
    _vspd = _dir_y * vel;

    if (_dir_x != 0) facing = sign(_dir_x);

    if (attack_timer <= 0) {
        if (_dir_x != 0 || _dir_y != 0) {
            if (_dir_y < 0) {
                sprite_index = spr_player_costa_walk;
                dir_olhar = 1;
            } else if (_dir_y > 0) {
                sprite_index = spr_player_walk;
                dir_olhar = 2;
            } else if (_dir_x < 0) {
                sprite_index = spr_player_lado_esquerdo_1_walk;
                dir_olhar = 3;
            } else {
                sprite_index = spr_player_lado_walk;
                dir_olhar = 4;
            }
        } else {
            switch (dir_olhar) {
                case 1: sprite_index = spr_player_costa; break;
                case 2: sprite_index = spr_player_frente; break;
                case 3: sprite_index = spr_player_lado_esquerdo; break;
                case 4: sprite_index = spr_player_lado; break;
            }
        }
    }

    // Movimento em pequenos passos: evita atravessar colisores em velocidades
    // altas e mantém a colisão horizontal/vertical independente.
    if (_hspd != 0) {
        var _steps_x = max(1, ceil(abs(_hspd)));
        var _step_x = _hspd / _steps_x;
        repeat (_steps_x) {
            if (_player_blocked(x + _step_x, y)) {
                break;
            }
            x += _step_x;
        }
    }

    if (_vspd != 0) {
        var _steps_y = max(1, ceil(abs(_vspd)));
        var _step_y = _vspd / _steps_y;
        repeat (_steps_y) {
            if (_player_blocked(x, y + _step_y)) {
                break;
            }
            y += _step_y;
        }
    }


    // Não deixa sair da sala por lados sem saída (controlador define direita/esquerda/cima/baixo).
    var _ct = instance_find(controlador, 0);
    if (_ct != noone) {
        if (_ct.direita  == noone) x = min(x, room_width - 6);
        if (_ct.esquerda == noone) x = max(x, 6);
        if (_ct.cima     == noone) y = max(y, 12);
        if (_ct.baixo    == noone) y = min(y, room_height - 1);
    }

    if (can_move && !auto_walk_active) {
        // Prioridade máxima para a interação da água: processada pelo jogador
        // antes de portas/casas para impedir duas trocas de sala no mesmo E.
        if (keyboard_check_pressed(ord("E"))
            && !global.em_cutscene
            && !global.water_cutscene_started
            && global.quest == 0) {
            var _garrafa_agua = instance_nearest(x, y, obj_garrafa_agua);
            var _mesa_agua = instance_nearest(x, y, obj_mesa);
            var _perto_garrafa = (_garrafa_agua != noone && point_distance(x, y, _garrafa_agua.x, _garrafa_agua.y) <= 24);
            var _perto_mesa = (_mesa_agua != noone && point_distance(x, y, _mesa_agua.x, _mesa_agua.y) <= 24);
            if (_perto_garrafa || _perto_mesa) {
                global.water_cutscene_started = true;
                global.em_cutscene = true;
                global.quest = 1;
                room_goto(rm_cutscene_agua);
                exit;
            }
        }

        var _porta = instance_nearest(x, y, obj_porta);
        if (_porta != noone && distance_to_object(_porta) < 40 && keyboard_check_pressed(ord("E"))) {
            if (variable_instance_exists(_porta, "proxima_sala") && room_exists(_porta.proxima_sala)) {
                room_goto(_porta.proxima_sala);
                exit;
            }
        }

        var _cadeira = instance_nearest(x, y, obj_cadeira);
        if (_cadeira != noone && distance_to_object(_cadeira) < 40
            && keyboard_check_pressed(ord("E")) && !global.cutscene_bar_feita
            && !instance_exists(obj_cutscene_bar)) {
            x = _cadeira.x;
            y = _cadeira.y;
            if (layer_get_id("Instances") != -1) {
                instance_create_depth(x, y, -50000, obj_cutscene_bar);
            }
        }

        // A casa inicial só é utilizável no mapa externo dela. Nas demais
        // rooms, especialmente na vila, as casas são cenário e não podem
        // capturar o mesmo E usado para pegar itens próximos.
        var _casa_player = instance_nearest(x, y, obj_casa_player);
        if (room == rm_fora_casa && _casa_player != noone && distance_to_object(_casa_player) < 40
            && keyboard_check_pressed(ord("E"))) {
            room_goto(rm_dentro_casa);
            exit;
        }

        // Somente as casas da cidade norte são entradas neste ponto do jogo.
        // As casas da vila são decorativas; antes esta rota levava de volta
        // à casa do começo quando o jogador tentava pegar o parafuso.
        var _casa = instance_nearest(x, y, obj_casa);
        if (room == rm_cidade_norte) {
            var _casa_costa = instance_nearest(x, y, obj_casa_costa);
            if (_casa_costa != noone && (_casa == noone || distance_to_object(_casa_costa) < distance_to_object(_casa))) _casa = _casa_costa;
        }
        if (room == rm_cidade_norte && _casa != noone && distance_to_object(_casa) < 40
            && keyboard_check_pressed(ord("E"))) {
            global.norte_ret_valido = true;
            global.norte_ret_x = clamp((_casa.bbox_left + _casa.bbox_right) / 2, 16, room_width - 16);
            global.norte_ret_y = clamp(_casa.bbox_bottom + 14, 16, room_height - 8);
            x = 101;
            y = 46;
            room_goto(rm_casa_cidade_norte);
            exit;
        }

        var _barco_vapor = instance_nearest(x, y, obj_barco_vapor);
        if (_barco_vapor != noone && distance_to_object(_barco_vapor) < 48
            && keyboard_check_pressed(ord("E"))) {
            room_goto(rm_cutscene_intro_fernando);
            exit;
        }

        var _porta_fernando = instance_nearest(x, y, obj_door_fernando);
        if (_porta_fernando == noone || point_distance(x, y, _porta_fernando.x, _porta_fernando.y) > 48) {
            _porta_fernando = instance_nearest(x, y, obj_door);
        }
        near_door = (_porta_fernando != noone && point_distance(x, y, _porta_fernando.x, _porta_fernando.y) <= 48);
        if (near_door && keyboard_check_pressed(ord("E"))) {
            var _destino_valido = variable_instance_exists(_porta_fernando, "target_room")
                && room_exists(_porta_fernando.target_room)
                && variable_instance_exists(_porta_fernando, "target_x")
                && variable_instance_exists(_porta_fernando, "target_y");
            if (_destino_valido) {
                x = _porta_fernando.target_x;
                y = _porta_fernando.target_y;
                room_goto(_porta_fernando.target_room);
                exit;
            }
        }

        if (keyboard_check_pressed(ord("E")) || keyboard_check_pressed(vk_space)) {
            var _itens = [obj_parafuso, obj_engrenagem, obj_correa];
            for (var i = 0; i < array_length(_itens); i++) {
                var _inst_item = instance_nearest(x, y, _itens[i]);
                var _alcance_item = 32;
                if (_inst_item != noone && variable_instance_exists(_inst_item, "distancia_interacao")) {
                    _alcance_item = _inst_item.distancia_interacao;
                }
                if (_inst_item != noone && point_distance(x, y, _inst_item.x, _inst_item.y) <= _alcance_item) {
                    var _controller_asset = asset_get_index("obj_control_vila");
                    if (_controller_asset != -1 && instance_exists(_controller_asset)) {
                        with (_controller_asset) {
                            if (variable_instance_exists(id, "itens_coletados")) itens_coletados += 1;
                        }
                    }
                    instance_destroy(_inst_item);
                    break;
                }
            }
        }

        if (keyboard_check_pressed(ord("Q"))) {
            var _pedra = instance_nearest(x, y, obj_pedra);
            if (_pedra != noone && point_distance(x, y, _pedra.x, _pedra.y) <= 40) {
                global.pedras += 1;
                instance_destroy(_pedra);
            } else {
                flashlight_on = !flashlight_on;
            }
        }

        var _r_ocupado = global.pedras > 0;
        if (instance_exists(obj_fogueira) && distance_to_object(obj_fogueira) <= 48) _r_ocupado = true;
        if (instance_exists(obj_lampiao) && distance_to_object(obj_lampiao) <= 48) _r_ocupado = true;
        if (instance_exists(obj_barco_acampamento) && distance_to_object(obj_barco_acampamento) <= 48) _r_ocupado = true;
        if (instance_exists(obj_barco_floresta) && distance_to_object(obj_barco_floresta) <= 48) _r_ocupado = true;
        if (instance_exists(obj_cabana2) && distance_to_object(obj_cabana2) <= 48) _r_ocupado = true;
        if (instance_exists(obj_cacador_npc_fernando) && distance_to_object(obj_cacador_npc_fernando) <= 48) _r_ocupado = true;
        if (!_r_ocupado && keyboard_check_pressed(ord("R"))) has_sword = true;

        if (has_sword && mouse_check_button_pressed(mb_left) && attack_cooldown <= 0) {
            attack_cooldown = 20;
            attack_timer = 10;
            sprite_index = sprite_attack;

            var _attack_x = x;
            var _attack_y = y;
            var _attack_range = 32;
            switch (dir_olhar) {
                case 1: _attack_y -= _attack_range; break;
                case 2: _attack_y += _attack_range; break;
                case 3: _attack_x -= _attack_range; break;
                case 4: _attack_x += _attack_range; break;
            }

            var _enemy_hit = instance_place(_attack_x, _attack_y, obj_enemy);
            if (_enemy_hit != noone && variable_instance_exists(_enemy_hit, "hp")) {
                _enemy_hit.hp -= 25;
                if (_enemy_hit.hp <= 0) instance_destroy(_enemy_hit);
            }

            var _tree_hit = instance_place(_attack_x, _attack_y, obj_tree);
            if (_tree_hit != noone
                && global.trees_cut < global.trees_goal
                && variable_instance_exists(_tree_hit, "hits_taken")
                && variable_instance_exists(_tree_hit, "hits_needed")) {
                _tree_hit.hits_taken += 1;
                if (_tree_hit.hits_taken >= _tree_hit.hits_needed) {
                    instance_destroy(_tree_hit);
                    global.trees_cut = min(global.trees_cut + 1, global.trees_goal);
                }
            }
        }
    }
}

if (attack_timer > 0) {
    attack_timer -= 1;
    if (attack_timer <= 0) {
        switch (dir_olhar) {
            case 1: sprite_index = spr_player_costa; break;
            case 2: sprite_index = spr_player_frente; break;
            case 3: sprite_index = spr_player_lado_esquerdo; break;
            case 4: sprite_index = spr_player_lado; break;
        }
    }
}

var _tocou_inimigo = place_meeting(x, y, obj_enemy) || place_meeting(x, y, obj_enemy_fernando);
if (_tocou_inimigo && invincible_timer <= 0) {
    hp -= 20;
    invincible_timer = 60;
    if (hp <= 0) {
        if (room == rm_acampamento_noite3) {
            global.player_morto = true;
            visible = false;
            can_move = false;
        } else {
            hp = hp_max;
            x = spawn_x;
            y = spawn_y;
        }
    }
}

if (global.trees_cut >= global.trees_goal && !global.objective_done) {
    global.objective_done = true;
    if (room == Room1) room_goto(rm_cutscene_parte2);
}
