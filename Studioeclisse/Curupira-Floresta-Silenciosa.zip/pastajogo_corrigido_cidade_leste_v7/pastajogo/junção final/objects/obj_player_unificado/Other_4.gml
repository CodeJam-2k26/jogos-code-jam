                                                                           
if (!instance_exists(obj_cam)) {
    instance_create_depth(x, y, -100000, obj_cam);
}

var _cam = view_camera[0];
if (_cam != -1 && instance_exists(obj_cam)) {
    var _view_w = max(1, camera_get_view_width(_cam));
    var _view_h = max(1, camera_get_view_height(_cam));
    obj_cam.alvo = id;
    obj_cam.x = clamp(x - _view_w * 0.5, 0, max(0, room_width - _view_w));
    obj_cam.y = clamp(y - _view_h * 0.5, 0, max(0, room_height - _view_h));
    camera_set_view_pos(_cam, obj_cam.x, obj_cam.y);
}

// Algumas cutscenes antigas removiam este HUD ao trocar de room. Garanta que
// ele exista sempre, inclusive ao voltar de uma cena ou carregar um save.
if (!instance_exists(obj_aviso)) {
    instance_create_depth(0, 0, -10000, obj_aviso);
}

// Evita personagem invisível/travado por estados que "vazaram" de outra sala,
// sem cancelar uma cutscene que acabou de iniciar nesta sala.
var _cutscene_da_sala = instance_exists(obj_cutscene_bar)
    || instance_exists(obj_cutscene_intro_fernando)
    || instance_exists(obj_cutscene_parte2_fernando)
    || instance_exists(obj_cutscene_parte3)
    || instance_exists(obj_cutscene_parte4)
    || instance_exists(obj_cutscene_parte5)
    || instance_exists(obj_cutscene_lampiao)
    || instance_exists(obj_cutscene_agua)
    || instance_exists(obj_cutscene_vila)
    || instance_exists(obj_final_controle)
    || instance_exists(obj_fim_controle);
if (!instance_exists(obj_player_yuri) && !_cutscene_da_sala) global.em_cutscene = false;
global.player_hidden = false;
global.dialogue_open = false;
global.dialogue_owner = noone;
if (!global.player_morto) {
    visible = true;
    image_alpha = 1;
    if (abs(image_xscale) < 0.1) image_xscale = 1;
    if (abs(image_yscale) < 0.1) image_yscale = 1;
    if (sprite_index == -1) {
        sprite_index = spr_player_frente;
        image_index = 0;
    }
    can_move = !_cutscene_da_sala;
}

// Tilemaps de árvores da sala atual (para colisão).
tiles_arvore = [];
var _layers = layer_get_all();
for (var _i = 0; _i < array_length(_layers); _i++) {
    var _nm = string_lower(layer_get_name(_layers[_i]));
    if (string_pos("arvore", _nm) > 0) {
        var _tm = layer_tilemap_get_id(_layers[_i]);
        if (_tm != -1) array_push(tiles_arvore, _tm);
    }
}
