vel = 2;
hspd = 0;
vspd = 0;
light_surf = -1;

if (!variable_global_exists("em_cutscene")) {
    global.em_cutscene = false;
}

if (!variable_global_exists("water_cutscene_started")) {
    global.water_cutscene_started = false;
}

                                                                          
with (obj_player) instance_destroy();
with (obj_player_yuri) instance_destroy();
with (obj_player_fernando) instance_destroy();

if (instance_number(obj_player_unificado) > 1) {
    instance_destroy();
    exit;
}

spawn_lado = "";
spawn_room = noone;
dir_olhar = 2;
draw_set_font(yes);

move_speed = vel;
facing = 1;
hp = 100;
hp_max = 100;
invincible_timer = 0;
spawn_x = x;
spawn_y = y;
near_door = false;
has_sword = false;
attack_cooldown = 0;
attack_timer = 0;
sprite_normal = spr_player_frente;
sprite_attack = spr_player_frente;
can_move = true;
intro_dialogue_shown = false;
intro_dialogue_text = "Preciso pegar lenha para a fogueira. Vou derrubar algumas árvores.";
auto_walk_active = false;
auto_walk_target_x = 0;
auto_walk_target_y = 0;
auto_walk_pause_timer = 0;
flashlight_on = false;
flashlight_hint_shown = false;
sprite_no_lantern = spr_player_frente;
sprite_with_lantern = spr_player_lanterna;
mensagem = "";

if (!variable_global_exists("game_started")) {
    global.game_started = true;
    global.hunters_called = 0;
    global.trees_cut = 0;
    global.trees_goal = 3;
    global.objective_done = false;
    global.dialogue_open = false;
    global.wood_delivered = false;
    global.camp_stage = 0;
    global.camp_has_wood = false;
    global.arrived_at_cabin2 = false;
    global.has_slept = false;
    global.is_night = false;
    global.lamp_analyzed = false;
    global.casa_stage = 0;
    global.map_picked = false;
    global.player_hidden = false;
    global.casa_alerta = false;
}

if (!variable_global_exists("hunters_called")) global.hunters_called = 0;
if (!variable_global_exists("trees_cut")) global.trees_cut = 0;
if (!variable_global_exists("trees_goal")) global.trees_goal = 3;
if (!variable_global_exists("objective_done")) global.objective_done = false;
if (!variable_global_exists("dialogue_open")) global.dialogue_open = false;
if (!variable_global_exists("dialogue_owner")) global.dialogue_owner = noone;
if (!variable_global_exists("wood_delivered")) global.wood_delivered = false;
if (!variable_global_exists("camp_stage")) global.camp_stage = 0;
if (!variable_global_exists("camp_has_wood")) global.camp_has_wood = false;
if (!variable_global_exists("arrived_at_cabin2")) global.arrived_at_cabin2 = false;
if (!variable_global_exists("has_slept")) global.has_slept = false;
if (!variable_global_exists("is_night")) global.is_night = false;
if (!variable_global_exists("lamp_analyzed")) global.lamp_analyzed = false;
if (!variable_global_exists("casa_stage")) global.casa_stage = 0;
if (!variable_global_exists("map_picked")) global.map_picked = false;
if (!variable_global_exists("player_hidden")) global.player_hidden = false;
if (!variable_global_exists("casa_alerta")) global.casa_alerta = false;
if (!variable_global_exists("fernando_intro_seen")) global.fernando_intro_seen = false;

if (!variable_global_exists("barco_consertos")) global.barco_consertos = 0;
if (!variable_global_exists("pedras")) global.pedras = 0;
if (!variable_global_exists("consertando")) global.consertando = false;
if (!variable_global_exists("conserto_prog")) global.conserto_prog = 0;
if (!variable_global_exists("perto_barco")) global.perto_barco = false;
if (!variable_global_exists("player_morto")) global.player_morto = false;
if (!variable_global_exists("barulho_ativo")) global.barulho_ativo = false;
if (!variable_global_exists("barulho_x")) global.barulho_x = 0;
if (!variable_global_exists("barulho_y")) global.barulho_y = 0;
if (!variable_global_exists("txt_aviso")) global.txt_aviso = 0;
if (!variable_global_exists("cutscene_bar_feita")) global.cutscene_bar_feita = false;

solidos_player = [
    obj_wall_fernando, obj_wall,
    // Barreiras invisíveis usadas para fechar paredes, cercas e passagens.
    obj_block, obj_block_bar, obj_block_bar2, obj_block_cerca,
    obj_block_cidade, obj_block_cidade_npc,
    obj_tree, obj_tree_fernando, obj_mesa, obj_bau, obj_jarra,
    obj_cabana, obj_cabana2, obj_casinha_entrada, obj_barco, obj_barco_vapor, obj_bar,
    obj_fogueira, obj_lampiao, obj_casa, obj_casa_player, obj_casa_costa,
    obj_cama, obj_cerca, obj_cerca_pe, obj_arvore_grande, obj_arvore_pequena,
    obj_barracas, obj_barracas_1, obj_barracas_2, obj_barracas_3, obj_barracas_4,
    obj_barracas_5, obj_barracas_6, obj_barracas_7, obj_barracas_8, barraca_lado
];

colisao_arvores_tile = true; // false = desliga a colisão com tiles das camadas "arvore*"
tiles_arvore = [];
