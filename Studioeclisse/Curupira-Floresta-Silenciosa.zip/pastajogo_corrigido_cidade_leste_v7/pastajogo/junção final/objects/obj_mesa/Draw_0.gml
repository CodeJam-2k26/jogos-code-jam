draw_set_font(yes);
draw_self();

                                                                    
if (global.quest == 0
    && instance_exists(obj_player_unificado)
    && point_distance(x, y, obj_player_unificado.x, obj_player_unificado.y) <= 48)
{
    var _hint_x = x;
    var _hint_y = y - 32;
    var _hint_text = "Aperte E";
    var _hint_scale = 0.75;
    var _hint_w = string_width(_hint_text) * _hint_scale;
    var _hint_h = string_height(_hint_text) * _hint_scale;

    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_set_alpha(0.75);
    draw_set_color(c_black);
    draw_roundrect(
        _hint_x - _hint_w * 0.5 - 2,
        _hint_y - _hint_h * 0.5 - 1,
        _hint_x + _hint_w * 0.5 + 2,
        _hint_y + _hint_h * 0.5 + 1,
        false
    );
    draw_set_alpha(1);
    draw_set_color(c_white);
    draw_text_transformed(_hint_x, _hint_y, _hint_text, _hint_scale, _hint_scale, 0);

    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_color(c_white);
}
