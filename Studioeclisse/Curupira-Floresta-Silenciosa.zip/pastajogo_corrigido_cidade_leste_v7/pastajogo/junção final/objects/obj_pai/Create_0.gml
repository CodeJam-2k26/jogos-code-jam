                                          
if (global.cutscene_bar_feita)
{
                                                           
    instance_destroy();
}