// Interação centralizada em obj_player_unificado/Step_0.gml para evitar room_goto duplicado.
