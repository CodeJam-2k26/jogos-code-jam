depth = -50000; // cutscene sempre acima de HUD, aviso, fader e neblina
story_text[0] = "Como o local é muito distante e explorar toda a região em apenas um dia seria impossível, um dos caçadores sugere que montem um acampamento e permaneçam ali por alguns dias.";
story_text[1] = "Todos concordam. Antes do anoitecer, montam duas pequenas cabanas e passam o restante do dia explorando os arredores, marcando árvores e planejando por onde começariam a retirada da madeira na manhã seguinte.";
story_text[2] = "Durante a madrugada, um dos caçadores acorda sentindo-se mal e decide sair da cabana para tomar um pouco de ar.";
story_text[3] = "Enquanto caminha pela mata escura, ouve um estranho barulho vindo dos arbustos.";
story_text[4] = "Curioso, aproxima-se lentamente para investigar.";
story_text[5] = "Em poucos segundos, um forte assobio ecoa pela floresta.";
story_text[6] = "O silêncio toma conta do lugar.";
story_text[7] = "O caçador desaparece sem deixar rastros.";
story_text[8] = "Algum tempo depois, o companheiro que dividia a cabana com ele desperta e percebe que ele não voltou. Após procurá-lo nas proximidades sem sucesso, corre até a outra cabana para avisar os demais de que um dos caçadores desapareceu.";

total_pages = 9;
current_page = 0;
fade_alpha = 1;
fade_state = "in";