depth = -50000; // cutscene sempre acima da HUD
if (!variable_global_exists("em_cutscene")) global.em_cutscene = false;
if (!variable_global_exists("water_cutscene_started")) global.water_cutscene_started = false;
global.em_cutscene = true;
global.water_cutscene_started = true;
global.estado_jogo = "cutscene";
exiting = false;

// A interface persistente desenha uma cópia segura da fala na GUI.
if (!instance_exists(obj_aviso)) {
    instance_create_depth(0, 0, -10000, obj_aviso);
}

if (instance_exists(obj_player_unificado)) {
    obj_player_unificado.can_move = false;
}

tempo_espera = 60;
exibir_continuar = false;
alpha_texto = 1;
alpha_dir = -0.03;
