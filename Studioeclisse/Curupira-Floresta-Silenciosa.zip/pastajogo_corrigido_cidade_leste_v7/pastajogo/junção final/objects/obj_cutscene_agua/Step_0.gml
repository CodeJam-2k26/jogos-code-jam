// Mantém o jogador bloqueado durante a cena para impedir room_goto concorrente.
if (exiting) exit;
if (!variable_global_exists("em_cutscene")) global.em_cutscene = true;
else global.em_cutscene = true;

if (tempo_espera > 0)
{
    tempo_espera--;
    if (tempo_espera <= 0) exibir_continuar = true;
}

if (exibir_continuar)
{
    alpha_texto += alpha_dir;
    if (alpha_texto <= 0.2) alpha_dir = 0.03;
    if (alpha_texto >= 1.0) alpha_dir = -0.03;

    if (keyboard_check_pressed(vk_space) || keyboard_check_pressed(ord("E")))
    {
        exiting = true;
        // Libera o controle ao sair da cutscene; o pressionamento atual já é pressed,
        // então não será reinterpretado como uma nova interação na próxima sala.
        global.em_cutscene = false;
        global.water_cutscene_started = false;
        global.estado_jogo = "gameplay";
        global.player_hidden = false;
        if (instance_exists(obj_player_unificado)) {
            with (obj_player_unificado) {
                visible = true;
                image_alpha = 1;
                can_move = true;
            }
        }
        room_goto(rm_dentro_casa);
        exit;
    }
}
