                                                  
if (global.quest_feira == 0)                                 
{
                                                                 
    if (place_meeting(x, y, obj_player_unificado) || 
        distance_to_object(obj_player_unificado) <= 2)
    {
        obj_player_unificado.mensagem = "É perigoso ir por aqui";
        global.txt_aviso = 60;                                                  
    }
}