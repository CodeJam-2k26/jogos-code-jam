if (instance_exists(obj_player_unificado))
{
    var _p = obj_player_unificado;
    var _ocupado = instance_exists(obj_fader) && obj_fader.estado != 0;
    var _bloqueado_por_itens = false;

                                                                             
    if (room == rm_vila)
    {
        var _controle_vila = instance_find(obj_control_vila, 0);
        _bloqueado_por_itens = (_controle_vila == noone)
            || (_controle_vila.itens_coletados < _controle_vila.total_itens_necessarios);
    }

    if (!_ocupado && !_bloqueado_por_itens)
    {
        // A vila possui colisores contínuos nas duas bordas. As transições
        // precisam disparar um pouco antes da parede, como já ocorre no píer.
        if (room == rm_vila && direita != noone
            && _p.x >= room_width - 42
            && (keyboard_check(vk_right) || keyboard_check(ord("D"))))
        {
            trocar_sala_fade(direita, "direita");
        }
        else if (room == rm_vila && esquerda != noone
            && _p.x <= 42
            && (keyboard_check(vk_left) || keyboard_check(ord("A"))))
        {
            trocar_sala_fade(esquerda, "esquerda");
        }
        // Na cidade, a parede de borda impede o jogador de alcançar room_width.
        // Dispare as saídas no vão da passagem, antes da colisão com a borda.
        if (room == rm_cidade && global.quest_feira >= 1
            && cima != noone && _p.y <= 24 && _p.x >= 480 && _p.x <= 530)
        {
            trocar_sala_fade(cima, "cima");
        }
        else if (room == rm_cidade && global.quest_feira >= 2
            && direita != noone && _p.x >= room_width - 40
            && _p.y >= 280 && _p.y <= 350)
        {
            trocar_sala_fade(direita, "direita");
        }
        // A borda possui colisão antes do limite da sala. Por isso a passagem
        // para o píer precisa ser detectada dentro da abertura visual.
        else if (room == rm_cutscene_bar_fora
            && variable_global_exists("cutscene_bar_feita") && global.cutscene_bar_feita
            && direita != noone && _p.x >= room_width - 44
            && _p.y >= 136 && _p.y <= 187
            && (keyboard_check(vk_right) || keyboard_check(ord("D"))))
        {
            trocar_sala_fade(direita, "direita");
        }
        // Use a mesma faixa ao voltar, para o jogador não reaparecer dentro
        // de uma parede na sala externa do bar.
        else if (room == rm_pier
            && esquerda != noone && _p.x <= 40
            && _p.y >= 136 && _p.y <= 187
            && (keyboard_check(vk_left) || keyboard_check(ord("A"))))
        {
            trocar_sala_fade(esquerda, "esquerda");
        }
        else if (_p.x >= room_width && direita  != noone) trocar_sala_fade(direita,  "direita");
        else if (_p.x <= 0          && esquerda != noone) trocar_sala_fade(esquerda, "esquerda");
        else if (_p.y <= 12         && cima     != noone) trocar_sala_fade(cima,     "cima");
        else if (_p.y >= room_height && baixo   != noone) trocar_sala_fade(baixo,   "baixo");
    }
}
