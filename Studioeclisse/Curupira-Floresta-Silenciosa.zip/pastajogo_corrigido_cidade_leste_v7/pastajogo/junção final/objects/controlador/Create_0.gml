                         
if (!variable_global_exists("quest"))
{
    global.cutscene_bar_feita = false;
    global.quest = 0;
    global.quest_feira = 0;
    global.musica = noone;
    global.objetivo_texto = "";
}


global.em_cutscene = false;
global.estado_jogo = "gameplay";
global.txt_aviso = 0;

                  
direita = noone;
esquerda = noone;
cima = noone;
baixo = noone;

// Rotas fixas da ligação entre o bar e o píer.
// Isto também cobre o controlador duplicado que existe na sala externa do bar.
if (room == rm_cutscene_bar_fora) {
    direita = rm_pier;
    esquerda = rm_cidade;
} else if (room == rm_pier) {
    esquerda = rm_cutscene_bar_fora;
}

timer = 0;
