depth = -50000; // cutscene sempre acima de HUD, aviso, fader e neblina
// A duplicata antiga desta sala foi desativada na room. Este controlador usa
// a interface persistente para garantir que os avisos apareçam.
if (!instance_exists(obj_aviso)) {
    instance_create_depth(0, 0, -10000, obj_aviso);
}
state = 0;                                                                     
timer_max = 20 * game_get_speed(gamespeed_fps);
timer = timer_max;

dlg_count = 0;
dlg_i = 0;

monster_x = -64;
monster_y = 250;
monster_speed = 2;
monster_t = 0;
wp_x[0] = 150; wp_y[0] = 250;
wp_x[1] = 350; wp_y[1] = 300;
wp_x[2] = 250; wp_y[2] = 180;
wp_n = 3;
wp_i = 0;
exit_x = room_width + 64;
exit_y = 250;

obj_player_unificado.visible = true;
obj_player_unificado.can_move = true;
