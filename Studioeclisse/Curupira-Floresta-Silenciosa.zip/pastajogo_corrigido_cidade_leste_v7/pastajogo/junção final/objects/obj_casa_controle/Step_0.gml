switch (state) {
    case 0:
        // O mapa altera a missão para estágio 2. Usar o estágio como gatilho
        // também cobre retornos/testes em que o objeto do mapa já sumiu.
        if (global.casa_stage == 2 && !global.casa_alerta && !global.player_hidden) {
            dlg_count = 1;
            dlg_i = 0;
            dlg_col[0] = c_white;
            dlg_name[0] = "Caçador 2";
            dlg_text[0] = "Pessoal, acho que vi algo se aproximando... escondam-se!";
            dlg_port[0] = spr_cacador2_portrait;
            obj_player_unificado.can_move = false;
            state = 1;
        }
    break;

    case 1:
        if (keyboard_check_pressed(vk_space) || keyboard_check_pressed(ord("E"))) {
            dlg_i++;
            if (dlg_i >= dlg_count) {
                obj_player_unificado.can_move = true;
                global.casa_alerta = true;
                timer = timer_max;
                state = 2;
            }
        }
    break;

    case 2:
        timer--;
        if (global.player_hidden) {
            global.casa_alerta = false;
            state = 4;
        } else if (timer <= 0) {
            global.casa_alerta = false;
            obj_player_unificado.can_move = false;
            state = 3;
        }
    break;

    case 3:
        if (mouse_check_button_pressed(mb_left)) {
            var mx = device_mouse_x_to_gui(0);
            var my = device_mouse_y_to_gui(0);
            var dw = display_get_gui_width();
            var dh = display_get_gui_height();
            if (mx > dw/2 - 90 && mx < dw/2 + 90 && my > dh/2 && my < dh/2 + 50) {
                global.map_picked = false;
                global.casa_stage = 1;
                global.casa_alerta = false;
                global.player_hidden = false;
                room_restart();
            }
        }
    break;

    case 4:
        monster_t++;
        var patrulhando = (monster_t < 10 * game_get_speed(gamespeed_fps));
        var tx = patrulhando ? wp_x[wp_i] : exit_x;
        var ty = patrulhando ? wp_y[wp_i] : exit_y;

        if (point_distance(monster_x, monster_y, tx, ty) <= monster_speed) {
            if (patrulhando) {
                wp_i = (wp_i + 1) mod wp_n;
            } else {
                dlg_count = 3;
                dlg_i = 0;
                dlg_col[0] = c_white; dlg_col[1] = c_white;
                dlg_name[0] = "Caçador 1";
                dlg_text[0] = "O que era aquilo?";
                dlg_port[0] = spr_cacador1_portrait;
                dlg_name[1] = "Caçador 2";
                dlg_text[1] = "Não sei... acho que era um monstro.";
                dlg_port[1] = spr_cacador2_portrait;
                dlg_name[2] = "Caçador 3";
                dlg_text[2] = "Não importa, temos que ir até a vila o mais rápido possível.";
                dlg_port[2] = spr_cacador1_portrait;
                dlg_col[2] = make_colour_rgb(255, 205, 150); // Caçador 3 sem retrato próprio: tom diferente                                    
                state = 5;
            }
        } else {
            var d = point_direction(monster_x, monster_y, tx, ty);
            monster_x += lengthdir_x(monster_speed, d);
            monster_y += lengthdir_y(monster_speed, d);
        }
    break;

    case 5:
        if (keyboard_check_pressed(vk_space) || keyboard_check_pressed(ord("E"))) {
            dlg_i++;
            if (dlg_i >= dlg_count) {
                obj_player_unificado.visible = false;
                obj_player_unificado.can_move = false;
                global.em_cutscene = true;
                state = 7;
            }
        }
    break;

    case 6:
                                           
    break;

    case 7:
        if (keyboard_check_pressed(vk_space) || keyboard_check_pressed(ord("E"))) {
            obj_player_unificado.visible = true;
            obj_player_unificado.can_move = true;
            global.em_cutscene = false;
            global.player_hidden = false;
            global.casa_stage = 3;
            global.spawn_y_forcado = 320;
            trocar_sala_fade(rm_vila, "direita");
            state = 6;
        }
    break;
}
