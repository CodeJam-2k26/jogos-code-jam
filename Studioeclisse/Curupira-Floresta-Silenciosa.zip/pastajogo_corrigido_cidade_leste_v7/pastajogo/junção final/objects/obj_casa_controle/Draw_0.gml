if (state == 4) {
    draw_sprite(spr_monstro, 0, monster_x, monster_y);
}