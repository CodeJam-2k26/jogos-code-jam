// O obj_aviso usa Draw GUI persistente e é a camada confiável para as
// mensagens. Ele espelha esta interface quando está presente.
if (instance_exists(obj_aviso)) exit;

draw_set_alpha(1);
draw_set_color(c_white);
draw_set_font(yes);
var dw = display_get_gui_width();
var dh = display_get_gui_height();
draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_set_alpha(1);

if (state == 2) {
    var secs = ceil(timer / game_get_speed(gamespeed_fps));
    draw_set_halign(fa_center);
    draw_set_valign(fa_top);
    draw_set_color(secs <= 5 ? c_red : c_white);
    draw_text_ext(dw / 2, 16, "Esconda-se! Tempo: " + string(secs), -1, max(1, dw - 32));
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_color(c_white);
}

if (state == 1 || state == 5) {
    var _margin = min(24, dw * 0.04);
    var _box_x1 = _margin;
    var _box_x2 = dw - _margin;
    var _portrait_w = min(150, dw * 0.16);
    var _text_x = _box_x1 + _portrait_w + 20;
    var _text_w = max(1, _box_x2 - _text_x - 16);
    var _line_sep = clamp(dh * 0.032, 12, 24);
    var _dialogue_h = string_height_ext(dlg_text[dlg_i], _line_sep, _text_w);
    var _box_h = min(dh - 2 * _margin, max(dh * 0.23, _dialogue_h + 74));
    var _box_y2 = dh - _margin;
    var _box_y1 = _box_y2 - _box_h;

    draw_set_color(c_black);
    draw_set_alpha(0.8);
    draw_rectangle(_box_x1, _box_y1, _box_x2, _box_y2, false);
    draw_set_alpha(1);
    draw_set_color(c_white);
    var _portrait_sprite = dlg_port[dlg_i];
    var _portrait_scale = min(1, min((_portrait_w - 8) / max(1, sprite_get_width(_portrait_sprite)), (_box_h - 12) / max(1, sprite_get_height(_portrait_sprite))));
    draw_sprite_ext(_portrait_sprite, 0, _box_x1 + 4, _box_y1 + 6, _portrait_scale, _portrait_scale, 0, dlg_col[dlg_i], 1);
    draw_set_color(c_yellow);
    draw_text(_text_x, _box_y1 + 12, dlg_name[dlg_i] + ":");
    draw_set_color(c_white);
    draw_text_ext(_text_x, _box_y1 + 42, dlg_text[dlg_i], _line_sep, _text_w);
    draw_set_halign(fa_right);
    draw_set_valign(fa_bottom);
    draw_text(_box_x2 - 12, _box_y2 - 10, "[ESPAÇO] continuar");
    draw_set_valign(fa_top);
    draw_set_halign(fa_left);
}

if (state == 3) {
    draw_set_color(c_black);
    draw_set_alpha(0.85);
    draw_rectangle(0, 0, dw, dh, false);
    draw_set_alpha(1);
    draw_set_halign(fa_center);
    draw_set_color(c_red);
    draw_text(dw/2, dh/2 - 80, "VOCÊ MORREU");
    draw_set_color(c_dkgray);
    draw_rectangle(dw/2 - 90, dh/2, dw/2 + 90, dh/2 + 50, false);
    draw_set_color(c_white);
    draw_text(dw/2, dh/2 + 15, "Reiniciar");
    draw_set_halign(fa_left);
}

if (state == 7) {
    draw_set_color(c_black);
    draw_rectangle(0, 0, dw, dh, false);
    draw_set_color(c_white);
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_text_ext(dw / 2, dh / 2, "Algum tempo depois, eles chegam à vila.", 8, max(1, dw - 32));
    draw_set_color(c_gray);
    draw_text(dw / 2, dh - 18, "[ESPAÇO] continuar");
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_color(c_white);
}
