                                                                   
if (variable_global_exists("cutscene_bar_feita") && global.cutscene_bar_feita)
{
    instance_destroy();
    exit;
}

if (place_meeting(x - 2, y, obj_player_unificado) ||
    place_meeting(x + 2, y, obj_player_unificado) ||
    place_meeting(x, y - 2, obj_player_unificado) ||
    place_meeting(x, y + 2, obj_player_unificado))
{
    obj_player_unificado.mensagem = "Acho que não é por aqui";
    global.txt_aviso = 60;
}