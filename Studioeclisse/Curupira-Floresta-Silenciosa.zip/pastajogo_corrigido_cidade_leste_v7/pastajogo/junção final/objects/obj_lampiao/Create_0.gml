                                                                               

interact_range = 50;                                