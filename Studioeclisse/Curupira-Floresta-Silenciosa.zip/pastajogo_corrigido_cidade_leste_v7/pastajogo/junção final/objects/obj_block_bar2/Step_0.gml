                                                                      
if (global.cutscene_bar_feita)
{
    instance_destroy();
}
else if (place_meeting(x - 2, y, obj_player_unificado) ||
         place_meeting(x + 2, y, obj_player_unificado) ||
         place_meeting(x, y - 2, obj_player_unificado) ||
         place_meeting(x, y + 2, obj_player_unificado))
{
    obj_player_unificado.mensagem = "Preciso ir no bar primeiro";
    global.txt_aviso = 60;
}