                                            
if (!variable_global_exists("musica")) global.musica = -1;
if (!variable_global_exists("musica_campanha")) global.musica_campanha = -1;
if (!variable_global_exists("musica_campanha_ativa")) global.musica_campanha_ativa = false;
if (!variable_global_exists("emissor_musica_campanha")) global.emissor_musica_campanha = -1;
if (!variable_global_exists("bus_musica_campanha")) global.bus_musica_campanha = undefined;

                                                                             
if (room == rm_tittle)
{
    global.musica_campanha_ativa = false;

    if (global.musica_campanha != -1 && audio_is_playing(global.musica_campanha))
    {
        audio_stop_sound(global.musica_campanha);
    }
    global.musica_campanha = -1;

    if (global.emissor_musica_campanha != -1 && audio_emitter_exists(global.emissor_musica_campanha))
    {
        audio_emitter_free(global.emissor_musica_campanha);
    }
    global.emissor_musica_campanha = -1;
    global.bus_musica_campanha = undefined;

    if (!audio_is_playing(snd_casa))
    {
        global.musica = audio_play_sound(snd_casa, 10, true);
    }
}

                                                                                      
if (room == rm_acampamento)
{
    global.musica_campanha_ativa = true;

    if (global.musica != -1 && audio_is_playing(global.musica))
    {
        audio_stop_sound(global.musica);
    }
    global.musica = -1;

    if (global.emissor_musica_campanha == -1 || !audio_emitter_exists(global.emissor_musica_campanha))
    {
        global.emissor_musica_campanha = audio_emitter_create();
        global.bus_musica_campanha = audio_bus_create();
        audio_emitter_bus(global.emissor_musica_campanha, global.bus_musica_campanha);

                                                                                
        global.bus_musica_campanha.effects[0] = audio_effect_create(AudioEffectType.LPF2, { cutoff: 8500, q: 1 });
        global.bus_musica_campanha.effects[1] = audio_effect_create(AudioEffectType.Reverb1, { size: 0.35, damp: 0.65, mix: 0.12 });
    }

    if (global.musica_campanha == -1 || !audio_is_playing(global.musica_campanha))
    {
        global.musica_campanha = audio_play_sound_on(global.emissor_musica_campanha, snd_musica_campanha, true, 10, 0);
        if (global.musica_campanha != -1)
        {
            audio_sound_gain(global.musica_campanha, 0.48, 1500);
        }
    }
}

                                                                      
if (room == rm_dentro_casa || room == rm_fora_casa || room == rm_corredor || room == rm_cidade || room == rm_cidade_norte || room == rm_cutscene_bar_fora)
{
    var _lpf = audio_effect_create(AudioEffectType.LPF2);
    _lpf.cutoff = 500;
    audio_bus_main.effects[0] = _lpf;
}
