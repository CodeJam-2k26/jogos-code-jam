                                                                                
if (global.musica_campanha_ativa
    && room != rm_tittle
    && global.emissor_musica_campanha != -1
    && (global.musica_campanha == -1 || !audio_is_playing(global.musica_campanha)))
{
    global.musica_campanha = audio_play_sound_on(global.emissor_musica_campanha, snd_musica_campanha, true, 10, 0.48);
}
