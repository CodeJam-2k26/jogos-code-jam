// Cabana ao lado: acordar os outros -> cutscene (rm_cutscene_parte5).
// Distância medida até a caixa de colisão (não até a origem do sprite).
// Aceita E (padrão do jogo) ou R (tecla antiga).
if (!instance_exists(obj_player_unificado)) exit;

var near_player = distance_to_object(obj_player_unificado) <= interact_range;

if (near_player && !global.arrived_at_cabin2
    && (keyboard_check_pressed(ord("E")) || keyboard_check_pressed(ord("R")))) {
    global.arrived_at_cabin2 = true;
    room_goto(rm_cutscene_parte5);
}
