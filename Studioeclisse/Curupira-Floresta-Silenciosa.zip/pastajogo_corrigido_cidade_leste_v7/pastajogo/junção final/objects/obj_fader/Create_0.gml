alpha = 0;
estado = 0;           
velocidade = 0.05;  
destino_room = noone;
lado = "";
margem = 24;
show_debug_message("fader criado, persistent = " + string(persistent));