if (estado == 1) {
    alpha += velocidade;
    if (alpha >= 1) {
        alpha = 1;
        estado = 2;
        room_goto(destino_room);
    }
} else if (estado == 2) {
    alpha -= velocidade;
    if (alpha <= 0) {
        alpha = 0;
        estado = 0;
    }
}