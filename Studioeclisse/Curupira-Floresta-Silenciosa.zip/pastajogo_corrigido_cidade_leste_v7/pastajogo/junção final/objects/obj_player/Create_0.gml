                                                                     
if (instance_exists(obj_player_unificado)) {
    instance_destroy();
    exit;
}

move_speed = 3;
facing = 1;

hp = 100;
hp_max = 100;
invincible_timer = 0;

spawn_x = x;
spawn_y = y;

near_door = false;

has_sword = false;
attack_cooldown = 0;
attack_timer = 0;
sprite_normal = spr_player;                                   
sprite_attack = sprite_normal;

global.hunters_called = 0;
global.trees_cut = 0;
global.trees_goal = 3;
global.objective_done = false;