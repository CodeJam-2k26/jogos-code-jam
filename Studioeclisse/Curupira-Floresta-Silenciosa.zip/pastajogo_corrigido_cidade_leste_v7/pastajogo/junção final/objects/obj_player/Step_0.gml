show_debug_message("x: " + string(x) + " y: " + string(y));

                                           
var input_h = keyboard_check(vk_right) - keyboard_check(vk_left);
var input_v = keyboard_check(vk_down) - keyboard_check(vk_up);

if (input_h != 0 && input_v != 0) {
    input_h *= 0.7071;
    input_v *= 0.7071;
}

if (input_h != 0) {
    facing = input_h;
}

if (!place_meeting(x + input_h * move_speed, y, obj_wall)) {
    x += input_h * move_speed;
}
if (!place_meeting(x, y + input_v * move_speed, obj_wall)) {
    y += input_v * move_speed;
}

        
near_door = place_meeting(x, y, obj_door);

if (near_door && keyboard_check_pressed(ord("E"))) {
    var target_door = instance_place(x, y, obj_door);
    if (target_door != noone) {
        var _has_destination = variable_instance_exists(target_door, "target_room")
            && variable_instance_exists(target_door, "target_x")
            && variable_instance_exists(target_door, "target_y");
        if (_has_destination && room_exists(target_door.target_room)) {
            var _destination_room = target_door.target_room;
            var _destination_x = target_door.target_x;
            var _destination_y = target_door.target_y;
            x = _destination_x;
            y = _destination_y;
            room_goto(_destination_room);
        } else {
            show_debug_message("Door has no valid destination: " + string(target_door));
        }
    }
}

                 
if (keyboard_check_pressed(ord("R"))) {
    has_sword = true;
}

if (attack_cooldown > 0) {
    attack_cooldown -= 1;
}

         
if (has_sword && mouse_check_button_pressed(mb_left) && attack_cooldown <= 0) {
    attack_cooldown = 20;
    attack_timer = 10;
    sprite_index = sprite_attack;
    
    var attack_range = 32;
    var attack_x = x + (facing * attack_range);
    var attack_y = y;
    
    if (place_meeting(attack_x, attack_y, obj_enemy)) {
        var enemy_hit = instance_place(attack_x, attack_y, obj_enemy);
        with (enemy_hit) {
            hp -= 25;
            if (hp <= 0) {
                instance_destroy();
            }
        }
    }
    
    if (place_meeting(attack_x, attack_y, obj_tree)) {
        var tree_hit = instance_place(attack_x, attack_y, obj_tree);
        with (tree_hit) {
            hits_taken += 1;
            if (hits_taken >= hits_needed) {
                instance_destroy();
                global.trees_cut += 1;
            }
        }
    }
}

if (attack_timer > 0) {
    attack_timer -= 1;
    if (attack_timer <= 0) {
        sprite_index = sprite_normal;
    }
}

                                    
if (invincible_timer > 0) {
    invincible_timer -= 1;
}

if (place_meeting(x, y, obj_enemy) && invincible_timer <= 0) {
    hp -= 20;
    invincible_timer = 60;
    
    if (hp <= 0) {
        hp = hp_max;
        x = spawn_x;
        y = spawn_y;
    }
}

                                
if (global.trees_cut >= global.trees_goal && !global.objective_done) {
    global.objective_done = true;
    room_goto(rm_cutscene_parte2);
}