draw_set_font(yes);
                
var bar_x = 20;
var bar_y = 20;
var bar_width = 200;
var bar_height = 20;

draw_set_color(c_dkgray);
draw_rectangle(bar_x, bar_y, bar_x + bar_width, bar_y + bar_height, false);

draw_set_color(c_lime);
var hp_width = (hp / hp_max) * bar_width;
draw_rectangle(bar_x, bar_y, bar_x + hp_width, bar_y + bar_height, false);

draw_set_color(c_white);
draw_rectangle(bar_x, bar_y, bar_x + bar_width, bar_y + bar_height, true);

                                                                           
if (global.trees_cut < global.trees_goal && room == rm_floresta) {
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_text(20, 50, "Objetivo: Derrubar árvores (" + string(global.trees_cut) + "/" + string(global.trees_goal) + ")");
}

draw_set_color(c_white);         