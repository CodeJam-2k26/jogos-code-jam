                                                                       
alpha_fade = 1; 

                                                                    
fade_velocidade = 0.015; 

                                              
surf_vignette = -1;