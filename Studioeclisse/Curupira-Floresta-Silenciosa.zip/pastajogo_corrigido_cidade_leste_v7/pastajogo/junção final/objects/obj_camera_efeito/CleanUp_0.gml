if (surface_exists(surf_vignette)) 
{
    surface_free(surf_vignette);
}