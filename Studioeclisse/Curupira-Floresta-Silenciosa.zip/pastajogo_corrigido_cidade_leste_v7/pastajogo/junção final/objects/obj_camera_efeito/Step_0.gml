                                                      
if (alpha_fade > 0) 
{
    alpha_fade -= fade_velocidade;
}