var _largura = display_get_gui_width();
var _altura = display_get_gui_height();


var _espessura = _largura * 0.2;                                

draw_set_color(c_black);


draw_primitive_begin(pr_trianglestrip);
draw_vertex_color(0, 0, c_black, 0.7);
draw_vertex_color(_espessura, 0, c_black, 0);
draw_vertex_color(0, _altura, c_black, 0.7);
draw_vertex_color(_espessura, _altura, c_black, 0);
draw_primitive_end();


draw_primitive_begin(pr_trianglestrip);
draw_vertex_color(_largura - _espessura, 0, c_black, 0);
draw_vertex_color(_largura, 0, c_black, 0.7);
draw_vertex_color(_largura - _espessura, _altura, c_black, 0);
draw_vertex_color(_largura, _altura, c_black, 0.7);
draw_primitive_end();


draw_primitive_begin(pr_trianglestrip);
draw_vertex_color(0, 0, c_black, 0.7);
draw_vertex_color(_largura, 0, c_black, 0.7);
draw_vertex_color(0, _espessura, c_black, 0);
draw_vertex_color(_largura, _espessura, c_black, 0);
draw_primitive_end();


draw_primitive_begin(pr_trianglestrip);
draw_vertex_color(0, _altura - _espessura, c_black, 0);
draw_vertex_color(_largura, _altura - _espessura, c_black, 0);
draw_vertex_color(0, _altura, c_black, 0.7);
draw_vertex_color(_largura, _altura, c_black, 0.7);
draw_primitive_end();


if (alpha_fade > 0) 
{
    draw_set_alpha(alpha_fade);
    draw_set_color(c_black);
    draw_rectangle(0, 0, _largura, _altura, false);
}

                                             
draw_set_alpha(1);
draw_set_color(c_white);