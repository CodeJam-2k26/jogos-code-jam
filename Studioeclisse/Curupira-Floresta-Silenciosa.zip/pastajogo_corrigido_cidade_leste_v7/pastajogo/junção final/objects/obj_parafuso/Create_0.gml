                                                                                          
nome_item = "Parafuso";
// O primeiro parafuso fica ao lado da parede de uma casa; um alcance maior
// permite pegá-lo sem encostar na colisão do cenário.
distancia_interacao = 48;
