                                                                                          
nome_item = "Engrenagem";
distancia_interacao = 32;                                                          