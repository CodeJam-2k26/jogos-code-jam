if (!instance_exists(obj_player_unificado)) exit;

var _near_player = point_distance(x, y, obj_player_unificado.x, obj_player_unificado.y) <= interact_range;
var _owns_dialogue = global.dialogue_open && global.dialogue_owner == id;

if (_near_player && keyboard_check_pressed(ord("E"))
    && (!global.dialogue_open || _owns_dialogue)) {
    if (!_owns_dialogue) {
        global.dialogue_open = true;
        global.dialogue_owner = id;
        show_dialogue = true;
        if (!was_called) {
            was_called = true;
            global.hunters_called += 1;
        }
    } else {
        show_dialogue = false;
        global.dialogue_open = false;
        global.dialogue_owner = noone;
    }
}

if (!_near_player && _owns_dialogue) {
    show_dialogue = false;
    global.dialogue_open = false;
    global.dialogue_owner = noone;
}
