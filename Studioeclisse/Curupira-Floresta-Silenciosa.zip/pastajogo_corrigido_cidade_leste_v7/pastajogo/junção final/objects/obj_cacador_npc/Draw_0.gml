draw_set_font(yes);
draw_self();

if (!instance_exists(obj_player_unificado)) exit;
var _near_player = point_distance(x, y, obj_player_unificado.x, obj_player_unificado.y) <= interact_range;
if (_near_player && !global.dialogue_open) {
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_set_color(c_white);
    draw_text(x, y - 50, "Aperte E para chamar");
}
draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_set_color(c_white);
