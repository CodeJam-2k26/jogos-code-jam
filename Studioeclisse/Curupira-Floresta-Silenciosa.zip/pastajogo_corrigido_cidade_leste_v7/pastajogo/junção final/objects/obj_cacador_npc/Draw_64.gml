if (!show_dialogue || !global.dialogue_open || global.dialogue_owner != id) exit;

draw_set_font(yes);
var _gui_w = display_get_gui_width();
var _gui_h = display_get_gui_height();
var _box_w = min(640, _gui_w - 32);
var _box_h = min(120, _gui_h * 0.28);
var _left = (_gui_w - _box_w) * 0.5;
var _top = _gui_h - _box_h - 18;

draw_set_alpha(0.92);
draw_set_color(c_black);
draw_roundrect(_left, _top, _left + _box_w, _top + _box_h, false);
draw_set_alpha(1);
draw_set_color(c_white);
draw_roundrect(_left, _top, _left + _box_w, _top + _box_h, true);
draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_text_ext(_left + 14, _top + 14, dialogue_text, -1, _box_w - 28);
draw_set_halign(fa_right);
draw_set_valign(fa_bottom);
draw_text(_left + _box_w - 12, _top + _box_h - 8, "E: fechar");
draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_set_color(c_white);
