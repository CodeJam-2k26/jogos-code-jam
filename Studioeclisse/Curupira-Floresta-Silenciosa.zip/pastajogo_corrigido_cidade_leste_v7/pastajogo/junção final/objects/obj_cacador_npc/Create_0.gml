dialogue_text = "Caçador: Vamos até o barco!";
if (!variable_global_exists("dialogue_open")) global.dialogue_open = false;
if (!variable_global_exists("dialogue_owner")) global.dialogue_owner = noone;
interact_range = 60;
show_dialogue = false;
was_called = false;
