function trocar_sala_fade(_room, _lado) {
    if (!instance_exists(obj_fader)) instance_create_depth(0, 0, -10000, obj_fader);
    if (obj_fader.estado != 0) exit;
    obj_fader.destino_room = _room;
    obj_fader.estado = 1;
    with (obj_player_unificado) {
        spawn_lado = _lado;
        spawn_room = _room;
    }
}