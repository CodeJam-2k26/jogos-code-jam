global.is_night = false;
global.consertando = false;
obj_player_fernando.x = 928;
obj_player_fernando.y = 384;
obj_player_fernando.can_move = false;