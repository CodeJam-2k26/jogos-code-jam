global.is_night = true;
global.pedras = 0;
global.barco_consertos = 0;
global.conserto_prog = 0;
global.consertando = false;
global.barulho_ativo = false;
global.barulho_x = 0;
global.barulho_y = 0;
global.em_cutscene = false;
global.player_hidden = false;
global.player_morto = false;

                                                                               
if (instance_exists(obj_player_unificado)) {
    with (obj_player_unificado) {
        // A margem da água começa logo à direita daqui. O spawn antigo ficava
        // sobre o limite do tile de água e podia esconder o personagem.
        x = 544;
        y = 352;
        spawn_x = 544;
        spawn_y = 352;
        can_move = true;
        visible = true;
        image_alpha = 1;
        sprite_index = spr_player_frente;
        image_index = 0;
        flashlight_on = true;
        flashlight_hint_shown = true;
        hp = hp_max;
    }
}

