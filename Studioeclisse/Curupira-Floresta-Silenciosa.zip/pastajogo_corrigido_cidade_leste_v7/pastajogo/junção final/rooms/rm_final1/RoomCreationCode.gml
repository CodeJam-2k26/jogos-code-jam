global.is_night = false;
global.em_cutscene = true;
global.estado_jogo = "fim";
global.consertando = false;
global.perto_barco = false;
global.barulho_ativo = false;
global.player_hidden = false;
global.player_morto = false;

// A composição do encerramento: Curupira e Sprite31 ficam em terra, enquanto
// o jogador já está no barco, do outro lado da margem.
var _controle_final = instance_find(obj_final_controle, 0);
if (_controle_final != noone) _controle_final.depth = 50;

var _curupira_final = instance_find(obj_monstro_parado, 0);
if (_curupira_final != noone) {
    with (_curupira_final) {
        x = 470;
        y = 432;
        depth = -120;
        visible = true;
        image_alpha = 1;
        image_xscale = 2.5;
        image_yscale = 2.5;
        image_index = 0;
        image_speed = 0;
    }
}

var _sprite31_final = instance_find(obj_corpo_cacador4, 0);
if (_sprite31_final != noone) {
    with (_sprite31_final) {
        x = 570;
        y = 394;
        depth = -110;
        visible = true;
        image_alpha = 1;
        image_xscale = 1.5;
        image_yscale = 1.5;
        image_index = 0;
        image_speed = 0;
    }
}

if (!instance_exists(obj_barco_fernando)) {
    var _barco_final = instance_create_depth(900, 570, -50, obj_barco_fernando);
    with (_barco_final) {
        image_xscale = 1.05;
        image_yscale = 1.05;
        image_speed = 0;
        interact_range = 0;
    }
}

if (instance_exists(obj_player_unificado)) {
    with (obj_player_unificado) {
        x = 1105;
        y = 522;
        spawn_x = 1105;
        spawn_y = 522;
        can_move = false;
        visible = true;
        image_alpha = 1;
        image_xscale = 2;
        image_yscale = 2;
        sprite_index = spr_player_costa;
        image_index = 0;
        dir_olhar = 1;
    }
}
