// O projeto usa obj_player_unificado. A referência antiga fazia o spawn desta
// sequência ficar indefinido ao retornar de uma cutscene.
if (instance_exists(obj_player_unificado)) {
    with (obj_player_unificado) {
        x = 200;
        y = 300;
        spawn_x = 200;
        spawn_y = 300;
        visible = true;
        image_alpha = 1;
        can_move = true;
    }
}

global.player_hidden = false;
global.em_cutscene = false;
global.is_night = true;
