obj_player_unificado.x = 200;
obj_player_unificado.y = 300;

global.casa_stage = 1;
global.map_picked = false;
global.player_hidden = false;
global.casa_alerta = false;
obj_player_unificado.x = 200;
obj_player_unificado.y = 300;