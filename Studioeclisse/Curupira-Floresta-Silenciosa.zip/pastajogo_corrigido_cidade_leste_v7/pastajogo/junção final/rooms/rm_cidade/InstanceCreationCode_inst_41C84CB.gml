direita = rm_cutscene_bar_fora;
esquerda = rm_corredor;
cima = rm_cidade_norte;
