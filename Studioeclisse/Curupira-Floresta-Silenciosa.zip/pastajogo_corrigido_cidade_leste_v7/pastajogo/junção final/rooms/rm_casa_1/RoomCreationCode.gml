obj_player_unificado.x = 282;
obj_player_unificado.y = 114;
                                                                       
global.is_night = false;
