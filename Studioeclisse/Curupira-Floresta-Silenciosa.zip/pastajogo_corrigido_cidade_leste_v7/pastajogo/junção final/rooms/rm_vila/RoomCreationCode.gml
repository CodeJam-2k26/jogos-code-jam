                                                                              
global.em_cutscene = false;
global.player_hidden = false;
global.player_morto = false;
if (!variable_global_exists("vila_pecas_reunidas")) global.vila_pecas_reunidas = false;

if (global.vila_pecas_reunidas) {
    // Ao voltar para a vila, não reapresente peças já concluídas.
    with (obj_parafuso) instance_destroy();
    with (obj_engrenagem) instance_destroy();
    with (obj_correa) instance_destroy();
}

if (instance_exists(obj_player_unificado)) {
    with (obj_player_unificado) {
        visible = true;
        can_move = true;
    }
}

                                                                             
if (!instance_exists(obj_control_vila)) {
    instance_create_layer(0, 0, "Instances", obj_control_vila);
}

// A vila também pode ser aberta diretamente para teste. Garanta que o HUD
// persistente exista nesses casos, para o contador não depender da ordem das
// salas anteriores.
if (!instance_exists(obj_aviso)) {
    instance_create_depth(0, 0, -10000, obj_aviso);
}
