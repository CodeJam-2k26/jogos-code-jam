// Depois das três peças, a cidade antiga não é a continuação desta etapa.
// A saída leva à cena curta que prepara a noite final.
direita = rm_cutscene_parte6;
esquerda = rm_fora_casa;
