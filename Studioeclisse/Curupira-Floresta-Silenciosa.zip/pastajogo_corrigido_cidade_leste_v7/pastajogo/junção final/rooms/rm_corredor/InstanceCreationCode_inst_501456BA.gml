esquerda = rm_fora_casa;
direita = rm_cidade;