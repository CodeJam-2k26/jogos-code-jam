direita = rm_pier;
esquerda = rm_cidade;
