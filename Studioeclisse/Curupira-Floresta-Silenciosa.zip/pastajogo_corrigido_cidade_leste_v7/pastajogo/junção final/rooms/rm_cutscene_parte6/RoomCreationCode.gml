global.em_cutscene = true;
global.estado_jogo = "cutscene";

if (!instance_exists(obj_aviso)) {
    instance_create_depth(0, 0, -10000, obj_aviso);
}

if (!instance_exists(obj_cutscene_vila)) {
    instance_create_depth(0, 0, -50000, obj_cutscene_vila);
}

if (instance_exists(obj_player_unificado)) {
    with (obj_player_unificado) {
        visible = true;
        image_alpha = 1;
        can_move = false;
    }
}
