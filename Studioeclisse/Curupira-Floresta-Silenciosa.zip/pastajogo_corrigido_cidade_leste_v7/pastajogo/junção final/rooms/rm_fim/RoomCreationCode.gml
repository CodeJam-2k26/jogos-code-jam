global.em_cutscene = true;
global.estado_jogo = "fim";

if (instance_exists(obj_player_unificado)) {
    with (obj_player_unificado) {
        can_move = false;
        visible = false;
    }
}
