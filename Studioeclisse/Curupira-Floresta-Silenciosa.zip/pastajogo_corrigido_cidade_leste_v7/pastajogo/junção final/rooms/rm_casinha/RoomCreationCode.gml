// Posiciona o jogador ao entrar na casa.
if (instance_exists(obj_player_unificado)) {
    obj_player_unificado.x = 200;
    obj_player_unificado.y = 300;
}

// Evita que estados de esconderijo/cutscene de outra sala deixem o jogador invisível.
if (!variable_global_exists("player_hidden")) global.player_hidden = false;
if (!variable_global_exists("em_cutscene")) global.em_cutscene = false;
if (!variable_global_exists("player_morto")) global.player_morto = false;

global.player_hidden = false;
global.em_cutscene = false;
global.is_night = true;

if (instance_exists(obj_player_unificado) && !global.player_morto) {
    obj_player_unificado.visible = true;
    obj_player_unificado.image_alpha = 1;
    obj_player_unificado.can_move = true;
}
