direita = rm_corredor;
