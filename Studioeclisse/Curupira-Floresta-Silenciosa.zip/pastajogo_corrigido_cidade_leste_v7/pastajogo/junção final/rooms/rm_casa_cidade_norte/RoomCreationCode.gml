// sala duplicada de rm_dentro_casa (casas da cidade norte)
