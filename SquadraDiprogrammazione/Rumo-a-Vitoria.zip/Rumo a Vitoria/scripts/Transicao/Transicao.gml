
function TransicaoParaSala(_sala)
{
	if (instance_exists(oTransicao)) return;
	instance_create_depth(0, 0, -99999, oTransicao, { sala_destino: _sala });
}