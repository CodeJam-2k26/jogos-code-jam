function NewEncounter(_enemies, _bg){
	if (instance_exists(oTransicao)) return;
	var _creator = id;
	instance_create_depth(0, 0, -99999, oTransicao,
	{
		sala_destino: noone,
		velocidade: 0.06,
		batalhaInimigos: _enemies,
		batalhaFundo: _bg,
		batalhaCriador: _creator
	});
}

function IniciarEncontro(_enemies, _bg, _creator)
{
	instance_create_depth
	(
		camera_get_view_x(view_camera [0]),
		camera_get_view_y(view_camera [0]),
		-9999,
		oBattle,
		{enemies: _enemies, creator: _creator, battleBackground: _bg}
	
	);
}
function BattleChangeHP(_target, _amount, _AliveDeadOrEither = 0)
{
	//_AliveDeadOrEither: 0 =alive only, 1 =dead only, 2 = any
	var _failed = false
	if( _AliveDeadOrEither == 0) && (_target.hp <=0) _failed =true
	if( _AliveDeadOrEither == 1) && (_target.hp > 0) _failed =true
	
	var _col = c_white;
	if (_amount > 0) _col = c_lime;
	if(_failed)
	{
		_col = c_white
		_amount = "failed";
	}
	instance_create_depth
	(
		_target.x,
		_target.y,
		_target.depth-1,
		oBattleFloatingText,
		{font: Regular_Pixel, col: _col, text: string(_amount)}
	);
	if (!_failed) _target.hp = clamp(_target.hp + _amount,0, _target.hpMax);
}

//ganho de xp pra party
function PartyGainXP(_member, _amount)
{
	_member.xp += _amount;
	var _leveledUp = false;
	
	while (_member.xp >= _member.xpToNextLevel)
	{
		_member.xp -= _member.xpToNextLevel;
		_member.level++;
		_member.xpToNextLevel = _member.level * 25;
		
		//aumenta os status ao subir de nível
		_member.hpMax += 8;
		_member.mpMax += 3;
		_member.strength += 2;
		
		//cura totalmente ao subir de nível
		_member.hp = _member.hpMax;
		_member.mp = _member.mpMax;
		
		_leveledUp = true;
	}
	
	return _leveledUp;
}
function ApplyStatusEffect(_target, _effect)
{
	if (_effect == -1) return;
	if (random(1) > _effect.chance) return; //não aplicou dessa vez
	
	//se já tem esse efeito, só renova a duração
	for (var i = 0; i < array_length(_target.statusEffects); i++)
	{
		if (_target.statusEffects[i].name == _effect.name)
		{
			_target.statusEffects[i].duration = _effect.duration;
			return;
		}
	}
	
	array_push(_target.statusEffects, {
		name: _effect.name,
		duration: _effect.duration,
		damagePerTurn: _effect.damagePerTurn
	});
}

function TickStatusEffects(_unit)
{
	if (_unit.hp <= 0) return;
	
	for (var i = array_length(_unit.statusEffects) - 1; i >= 0; i--)
	{
		var _effect = _unit.statusEffects[i];
		if (_effect.damagePerTurn > 0)
		{
			BattleChangeHP(_unit, -_effect.damagePerTurn);
		}
		_effect.duration--;
		if (_effect.duration <= 0)
		{
			array_delete(_unit.statusEffects, i, 1);
		}
	}
}

function TickAllStatusEffects(_allUnits)
{
	for (var i = 0; i < array_length(_allUnits); i++)
	{
		var _unit = _allUnits[i];
		if (instance_exists(_unit)) && (_unit.hp > 0)
		{
			TickStatusEffects(_unit);
		}
	}
}

function ShuffleArray(_array)
{
	var _result = [];
	array_copy(_result, 0, _array, 0, array_length(_array));
	
	for (var i = array_length(_result) - 1; i > 0; i--)
	{
		var j = irandom(i);
		var _temp = _result[i];
		_result[i] = _result[j];
		_result[j] = _temp;
	}
	
	return _result;
}

function GetBattleBackground()
{
	switch (room)
	{
		case rm_cidade1: return sBgField_Cidade;
		default:    return sBgField_Hospital;
	}
}
