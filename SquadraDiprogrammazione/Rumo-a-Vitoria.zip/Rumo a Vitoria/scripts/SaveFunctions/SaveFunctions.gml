function SaveGame(_slot = 1)
{
	var _partyData = [];
	for (var i = 0; i < array_length(global.party); i++)
	{
		var _m = global.party[i];
		array_push(_partyData, {
			name: _m.name,
			hp: _m.hp,
			hpMax: _m.hpMax,
			mp: _m.mp,
			mpMax: _m.mpMax,
			strength: _m.strength,
			level: _m.level,
			xp: _m.xp,
			xpToNextLevel: _m.xpToNextLevel
		});
	}
	
	var _data = {
		party: _partyData,
		potionCount: global.inventory.potion.count,	
		muletaCount: global.inventory.muleta.count,
		chaveHospitalCount: global.inventory.chave_hospital.count,
		collectedItems: global.collectedItems,
		armariosVasculhados: global.armariosVasculhados,
		saciIntroducaoFeita: global.saciIntroducaoFeita,
		questyHospitalIntroducaoFeita: global.questyHospitalIntroducaoFeita,
		questyAcompanhando: global.questyAcompanhando,
		muletaEntregue: global.muletaEntregue,
		room: room_get_name(room),
		playerX: oPlayer.x,
		playerY: oPlayer.y
	};
	
	var _json = json_stringify(_data);
	var _file = file_text_open_write("save" + string(_slot) + ".sav");
	file_text_write_string(_file, _json);
	file_text_close(_file);
}

function LoadGame(_slot = 1)
{
	var _filename = "save" + string(_slot) + ".sav";
	if (!file_exists(_filename)) return false;
	
	var _file = file_text_open_read(_filename);
	if (_file < 0) return false;
	var _json = "";
	while (!file_text_eof(_file))
	{
		_json += file_text_readln(_file);
	}
	file_text_close(_file);
	
	var _data;
	try
	{
		_data = json_parse(_json);
	}
	catch (_exception)
	{
		return false;
	}
	
	// Valida o arquivo inteiro antes de alterar qualquer dado do jogo.
	if (!is_struct(_data)) return false;
	if (!variable_struct_exists(_data, "party") || !is_array(_data.party)) return false;
	if (array_length(_data.party) != array_length(global.party)) return false;
	if (!variable_struct_exists(_data, "potionCount") || !is_real(_data.potionCount)) return false;
	if (!variable_struct_exists(_data, "room") || !is_string(_data.room)) return false;
	var _roomAsset = asset_get_index(_data.room);
	if (_roomAsset < 0 || !room_exists(_roomAsset)) return false;
	if (!variable_struct_exists(_data, "playerX") || !is_real(_data.playerX)) return false;
	if (!variable_struct_exists(_data, "playerY") || !is_real(_data.playerY)) return false;
	if (variable_struct_exists(_data, "muletaCount") && !is_real(_data.muletaCount)) return false;
	if (variable_struct_exists(_data, "chaveHospitalCount") && !is_real(_data.chaveHospitalCount)) return false;
	for (var i = 0; i < array_length(_data.party); i++)
	{
		var _saved = _data.party[i];
		if (!is_struct(_saved)) return false;
		var _requiredFields = ["hp", "hpMax", "mp", "mpMax", "strength", "level", "xp", "xpToNextLevel"];
		for (var j = 0; j < array_length(_requiredFields); j++)
		{
			if (!variable_struct_exists(_saved, _requiredFields[j])) return false;
			if (!is_real(_saved[$ _requiredFields[j]])) return false;
		}
	}
	
	//aplica os dados salvos por cima do party já existente, sem perder actions/sprites
	for (var i = 0; i < array_length(global.party); i++)
	{
		var _saved = _data.party[i];
		var _m = global.party[i];
		_m.hp = _saved.hp;
		_m.hpMax = _saved.hpMax;
		_m.mp = _saved.mp;
		_m.mpMax = _saved.mpMax;
		_m.strength = _saved.strength;
		_m.level = _saved.level;
		_m.xp = _saved.xp;
		_m.xpToNextLevel = _saved.xpToNextLevel;
	}
	global.inventory.potion.count = _data.potionCount;
	global.inventory.muleta.count = variable_struct_exists(_data, "muletaCount") ? _data.muletaCount : 0;
	global.inventory.chave_hospital.count = variable_struct_exists(_data, "chaveHospitalCount") ? _data.chaveHospitalCount : 0;
	global.collectedItems = variable_struct_exists(_data, "collectedItems") && is_array(_data.collectedItems) ? _data.collectedItems : [];
	global.armariosVasculhados = variable_struct_exists(_data, "armariosVasculhados") && is_array(_data.armariosVasculhados) ? _data.armariosVasculhados : [];
	global.saciIntroducaoFeita = variable_struct_exists(_data, "saciIntroducaoFeita") && (_data.saciIntroducaoFeita == true);
	global.questyHospitalIntroducaoFeita = variable_struct_exists(_data, "questyHospitalIntroducaoFeita") && (_data.questyHospitalIntroducaoFeita == true);
	global.questyAcompanhando = variable_struct_exists(_data, "questyAcompanhando") && (_data.questyAcompanhando == true);
	global.muletaEntregue = variable_struct_exists(_data, "muletaEntregue") && (_data.muletaEntregue == true);
	
	global.introFeita = true;
	global.pilhaPortas = [];
	global.spawnPorta = undefined;
	global.loadPlayerX = _data.playerX;
	global.loadPlayerY = _data.playerY;
	global.justLoaded = true;
	
	room_goto(_roomAsset);
	return true;
}

function SaveFileExists(_slot = 1)
{
	return file_exists("save" + string(_slot) + ".sav");
}
