//faz um menu, [["name", fuction, argument], [>>]
function Menu(_x, _y, _options, _description = -1, _width = undefined, _height = undefined, _closable = false)
{ 
	with(instance_create_depth(_x, _y ,-99999,oMenu))
	{
		options = _options;
		description = _description;
		closable = _closable;
		baseWidth = _width;
		baseHeight = _height;
		xmargin = 14;
		ymargin = 6;
		heightLine = 16;
		MenuUpdateLayout();
	}
}

function MenuUpdateLayout()
{
	draw_set_font(Regular_Pixel);
	var _descriptionRows = (description == -1) ? 0 : 1;
	var _contentWidth = 0;
	if (_descriptionRows > 0) _contentWidth = string_width(description);
	for (var i = 0; i < array_length(options); i++)
	{
		_contentWidth = max(_contentWidth, string_width(options[i][0]));
	}
	// Deixa espaço para o cursor à esquerda e uma margem à direita.
	widthFull = max(is_undefined(baseWidth) ? 0 : baseWidth, _contentWidth + xmargin + 8);

	if (is_undefined(baseHeight))
	{
		heightFull = ymargin * 2 + heightLine * (array_length(options) + _descriptionRows);
	}
	else
	{
		heightFull = max(baseHeight, ymargin * 2 + heightLine * (_descriptionRows + 1));
	}
	var _rowsAvailable = max(1, floor((heightFull - ymargin * 2) / heightLine) - _descriptionRows);
	visibleOptionsMax = min(array_length(options), _rowsAvailable);
	scrolling = visibleOptionsMax < array_length(options);
}

function SubMenu(_options, _description = -1)
{
	//guarda opções e descrição atuais para poder voltar depois
	optionsAbove[subMenuLevel] = options;
	descriptionAbove[subMenuLevel] = description;
	subMenuLevel++;
	options = _options;
	description = _description;
	hover = 0;
	MenuUpdateLayout();
}

function MenuGoBack()
{
	subMenuLevel--;
	options = optionsAbove[subMenuLevel];
	description = descriptionAbove[subMenuLevel];
	hover = 0;
	MenuUpdateLayout();
}
function MenuSelectAction(_user, _action)
{
	with (oMenu) active = false;
	
	//activate the targetting cursor if needed, or simply begin the action
	with (oBattle)
	{
		if(_action.targetRequired)
		{
			with (cursor)
			{
				active = true;
				activeAction = _action;
				targetAll = _action.targetAll
				if (targetAll == MODE.VARIES) targetAll = true; // "toggle"
				activeUser = _user;
				
				//which side to target by default
				if(_action.targetEnemyByDefault) //target enemy by default
				{
					targetIndex = 0;
					targetSide = oBattle.enemyUnits;
					activeTarget = oBattle.enemyUnits[targetIndex];
				}
				else//target self by default
				{
					targetSide = oBattle.partyUnits;
					activeTarget = activeUser;
					var _findSelf = function(_element)
					{
						return (_element == activeTarget)
					}
					targetIndex = array_find_index(oBattle.partyUnits, _findSelf);
				}
			}
		}
		else
		{
			//sem alvo necessário: guarda na fila em vez de já executar
			with (oMenu) instance_destroy();
			QueueAction(_user, _action, -1);
		}
	}
}

function MenuAskSave()
{
	var _options = [
		["Sim", MenuConfirmSave, [1], true],
		["Não", MenuGoBack, -1, true]
	];
	
	with (oMenu) SubMenu(_options, "Salvar?");
}

function MenuCancel()
{
	with (oMenu) instance_destroy();
}

function MenuConfirmSave(_slot)
{
	//guarda a posição antes de destruir o menu
	var _msgX = oMenu.x;
	var _msgY = oMenu.y;
	
	SaveGame(_slot);
	
	with (oMenu) instance_destroy();
	
	//avisa que salvou
	instance_create_depth(_msgX, _msgY - 20, -99999, oBattleFloatingText, {font: Regular_Pixel, col: c_lime, text: "Jogo salvo!"});
}

function MenuLoadGame(_slot)
{
	with (oMenu) instance_destroy();
	if (!LoadGame(_slot)) instance_create_depth(0, 0, 0, oGameOverMenu);
}

function MenuRestartGame()
{
	with (oMenu) instance_destroy();
	InitGameData();
	global.pilhaPortas = [];
	global.spawnPorta = undefined;
	global.justLoaded = false;
	room_goto(rm_hospital1);
}

function MenuChooseOrder(_unit)
{
	with (oBattle)
	{
		array_push(partyOrder, _unit);
	}
	with (oMenu) instance_destroy();
}

function MenuOpenInventory()
{
	var _itemKeys = variable_struct_get_names(global.inventory);
	var _options = [];

	for (var i = 0; i < array_length(_itemKeys); i++)
	{
		var _item = global.inventory[$ _itemKeys[i]];
		if (variable_struct_exists(_item, "hideIfZero") && _item.hideIfZero && _item.count <= 0) continue;
		array_push(_options, [_item.name + " x" + string(_item.count), -1, -1, true]);
	}

	if (array_length(_options) == 0)
	{
		array_push(_options, ["(vazio)", -1, -1, true]);
	}

	array_push(_options, ["Voltar", MenuGoBack, -1, true]);

	with (oMenu) SubMenu(_options, "Inventário");
}

function MenuColetarItem(_obj, _itemKey)
{
	with (oMenu) instance_destroy();

	global.inventory[$ _itemKey].count += 1;
	array_push(global.collectedItems, _obj.itemId);

	instance_create_depth(oPlayer.x, oPlayer.y - 24, -99999, oBattleFloatingText, {font: Regular_Pixel, col: c_lime, text: "Obteve " + global.inventory[$ _itemKey].name + "!"});
	instance_destroy(_obj);
}

function SaciAbrirDialogo(_npc, _falas, _proximaEtapa = "")
{
	if (!instance_exists(_npc)) return;
	with (_npc)
	{
		dialogoAberto = true;
		proximaEtapa = _proximaEtapa;
		instance_create_depth(0, 0, -99999, oDialogo, {
			falas: _falas,
			nome: "Paciente",
			dono: id
		});
	}
}

function SaciAposDialogo(_npc)
{
	if (!instance_exists(_npc)) return;
	with (_npc)
	{
		dialogoAberto = false;
		var _etapa = proximaEtapa;
		proximaEtapa = "";
		var _cam = view_camera[0];
		var _menuX;
		var _menuY = camera_get_view_y(_cam) + camera_get_view_height(_cam) * 0.5;

		if (_etapa == "menu_resposta")
		{
			_menuX = camera_get_view_x(_cam) + camera_get_view_width(_cam) * 0.5 - 125;
			Menu(_menuX, _menuY, [
				["Mas sua perna esquerda nem existe.", SaciEscolherResposta, [id, 1], true],
				["Certeza de que está aqui por causa da sua perna?", SaciEscolherResposta, [id, 2], true]
			], -1, 250, 60, true);
		}
		else if (_etapa == "pedido")
		{
			global.saciIntroducaoFeita = true;
			SaciAbrirDialogo(id, [
				"O que é isso que você está levando?",
				"Uma muleta de andar de patinete!",
			"Me dê, por favor! Talvez assim eu possa sair daqui um dia."
			], "menu_entrega");
		}
		else if (_etapa == "menu_entrega")
		{
			_menuX = camera_get_view_x(_cam) + camera_get_view_width(_cam) * 0.5 - 55;
			Menu(_menuX, _menuY, [
				["Entregar a muleta", SaciEntregarMuleta, [id], global.inventory.muleta.count > 0],
				["Não entregar", SaciNaoEntregar, [id], true]
			], -1, 110, 52, true);
		}
	}
}

function SaciEscolherResposta(_npc, _resposta)
{
	with (oMenu) instance_destroy();
	if (_resposta == 1)
	{
		SaciAbrirDialogo(_npc, ["As enfermeiras disseram o mesmo, mas ela claramente nem se mexe."], "pedido");
	}
	else
	{
		SaciAbrirDialogo(_npc, ["Claro, por qual outro motivo eu estaria aqui?"], "pedido");
	}
}

function SaciEntregarMuleta(_npc)
{
	with (oMenu) instance_destroy();
	if (global.inventory.muleta.count <= 0)
	{
		SaciAbrirDialogo(_npc, ["Você ainda não tem uma muleta de andar de patinete para me dar." ]);
		return;
	}
	global.inventory.muleta.count -= 1;
	global.muletaEntregue = true;
	SaciAbrirDialogo(_npc, [
		"Muito obrigado mesmo. Vou lembrar de sua gentileza.",
		"Se está procurando um jeito de sair daqui, ouvi dizer que a chave está no escritório do diretor."
	]);
}

function SaciNaoEntregar(_npc)
{
	with (oMenu) instance_destroy();
	SaciAbrirDialogo(_npc, ["É mesmo? Por favor, me avise se mudar de ideia."]);
}
