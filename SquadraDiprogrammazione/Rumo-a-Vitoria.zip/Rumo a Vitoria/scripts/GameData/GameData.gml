enum MODE
{
	NEVER = 0,
	ALWAYS = 1,
	VARIES = 2
}
function InitGameData()
{
	global.saciIntroducaoFeita = false;
	global.questyHospitalIntroducaoFeita = false;
	global.questyAcompanhando = false;
	global.muletaEntregue = false;
	global.armariosVasculhados = [];

	//actions library
	global.actionLibrary =
	{
		gordura:
		{
			name: "Gordura",
			description: "{0} lançou Gordura!",
			subMenu: "Magia",
			mpCost: 5,
			targetRequired: true,
			targetEnemyByDefault: false,
			targetAll: MODE.NEVER,
			userAnimation: "attack",
			effectSprite: sAttackExplode,
			effectOnTarget: MODE.ALWAYS,
			basePower: 15,
			statusEffect: -1,
			previewDamage: function(_user, _target)
			{
				return -basePower;
			},
			func: function(_user, _targets)
			{
				BattleChangeHP(_targets[0], -basePower);
			}
		}
		,
		attack:
		{
			name: "Atacar",
			description: "{0} atacou!",
			subMenu: -1,
			targetRequired: true,
			targetEnemyByDefault: true,
			targetAll: MODE.NEVER,
			userAnimation: "attack",
			effectSprite: sAttackBonk,
			effectOnTarget: MODE.ALWAYS,
			basePower: 0,
			statusEffect: -1,
			previewDamage: function(_user, _target)
			{
				return -(basePower + _user.strength);
			},
			func: function(_user, _targets)
			{
				var _damage = basePower + _user.strength;
				BattleChangeHP(_targets[0], -_damage, 0);
				if (statusEffect != -1) ApplyStatusEffect(_targets[0], statusEffect);
			}
		},

		ice :
		{
			name : "Gelo",
			description: "{0} lançou Gelo!",
			subMenu: "Magia",
			mpCost : 4,
			targetRequired: true,
			targetEnemyByDefault: true,
			targetAll: MODE.VARIES,
			userAnimation: "cast",
			effectSprite: sAttackIce,
			effectOnTarget: MODE.ALWAYS,
			basePower: 12,
			statusEffect: { name: "Congelamento", chance: 1, duration: 2, damagePerTurn: 2 },
			previewDamage: function(_user, _target, _targetCount = 1)
			{
				if (_targetCount > 1) return -floor(basePower / _targetCount);
				return -basePower;
			},
			func : function(_user, _targets)
			{
				var _count = array_length(_targets);
				if (_count > 1)
				{
					//dano dividido entre todos os alvos, sem aplicar congelamento
					var _dmgPerTarget = floor(basePower / _count);
					for (var i = 0; i < _count; i++)
					{
						BattleChangeHP(_targets[i], -_dmgPerTarget);
					}
				}
				else
				{
					//alvo único: dano cheio + chance de congelar
					BattleChangeHP(_targets[0], -basePower);
					if (statusEffect != -1) ApplyStatusEffect(_targets[0], statusEffect);
				}
			}
		},

		cura :
		{
			name: "Poção",
			description: "{0} usou uma poção!",
			subMenu: "Item",
			itemKey: "potion",
			targetRequired: true,
			targetEnemyByDefault: false,
			targetAll: MODE.NEVER,
			userAnimation: "cura",
			effectSprite: sAttackHeal,
			effectOnTarget: MODE.ALWAYS,
			basePower: 10,
			statusEffect: -1,
			previewDamage: function(_user, _target)
			{
				return basePower;
			},
			func : function (_user, _targets)
			{
				if (global.inventory.potion.count <= 0) return;
				var _alive = (_targets[0].hp > 0);
				BattleChangeHP(_targets[0], basePower);
				if (_alive) global.inventory.potion.count -= 1;
			}
		}
	}

	//Inventory
	global.inventory =
	{
		potion:
		{
			name: "Poção",
			description: "Restaura um pouco de PV.",
			count: 0
		},
		muleta:
		{
			name: "Muleta",
			description: "Uma muleta.",
			count: 0,
			hideIfZero: true
		},
		chave_hospital:
		{
			name: "Chave do Hospital",
			description: "Abre a porta trancada do hospital.",
			count: 0,
			hideIfZero: true
		}
	}

	global.collectedItems = [];

	//Enemy Data
	global.enemies =
	{
		Palito:
		{
			name: "Palito",
			hp: 30,
			hpMax:30,
			mp:10,
			mpMax: 10,
			strength: 9,
			sprites: {idle: sMagra, attack: sMagraAttacks},
			actions:[global.actionLibrary.attack],
			xpValue:16, 
			AIscript: function()
			{
				var _action = actions[0];
				var _possibleTargets = array_filter(oBattle.partyUnits, function(_unit, _index)
				{
					return(_unit.hp > 0);
				});
				var _target = _possibleTargets[irandom(array_length(_possibleTargets)-1)]
				return [_action, _target];
			}
		},
		uranus:
		{
			name: "Uranus",
			hp: 50,
			hpMax:50,
			mp:10000,
			mpMax: 10000,
			strength: 5,
			sprites: {idle: sUranus, attack: sUranusAttack},
			actions:[global.actionLibrary.gordura],
			xpValue:18,
			AIscript: function()
			{
				var _action = actions[0];
				var _possibleTargets = array_filter(oBattle.partyUnits, function(_unit, _index)
				{
					return(_unit.hp > 0);
				});
				var _target = _possibleTargets[irandom(array_length(_possibleTargets)-1)]
				return [_action, _target];
			}
		}
		,
		
		slimeG: 
		{
			name: "Slime",
			hp: 30,
			hpMax: 30,
			mp: 0,
			mpMax: 0,
			strength: 6,
			sprites: { idle: sSlime, attack: sSlimeAttack},
			actions: [global.actionLibrary.attack],
			xpValue : 15,
			AIscript : function()
			{
				var _action = actions[0];
				var _possibleTargets = array_filter(oBattle.partyUnits, function(_unit, _index)
				{
					return(_unit.hp > 0);
				});
				var _target = _possibleTargets[irandom(array_length(_possibleTargets)-1)]
				return [_action, _target];
			}
		}
		,
		bat: 
		{
			name: "Morcego",
			hp: 15,
			hpMax: 15,
			mp: 0,
			mpMax: 0,
			strength: 4,
			sprites: { idle: sBat, attack: sBatAttack},
			actions: [global.actionLibrary.attack],
			xpValue : 18,
			AIscript : function()
			{
				var _action = actions[0];
				var _possibleTargets = array_filter(oBattle.partyUnits, function(_unit, _index)
				{
					return(_unit.hp > 0);
				});
				var _target = _possibleTargets[irandom(array_length(_possibleTargets)-1)]
				return [_action, _target];
			}
		}
	}

	//Party data
	global.party = 
	[
		{
			name: "Boto",
			hp: 89,
			hpMax: 89,
			mp: 10,
			mpMax: 15,
			strength: 6,
			level: 1,
			xp: 0,
			xpToNextLevel: 25,
			sprites : { idle: sBotoIdle, attack: sBotoAttack, defend: sBotoIdle, down: sBotoIdle},
			actions : [global.actionLibrary.attack, global.actionLibrary.cura]
		}
		,
		{
			name: "Polpo",
			hp: 44,
			hpMax: 44,
			mp: 20,
			mpMax: 30,
			strength: 4,
			level: 1,
			xp: 0,
			xpToNextLevel: 25,
			sprites : { idle: sPolpoIdle, attack: sPolpoAttacks, cast: sPolpoAttacks, down: sPolpoDown},
			actions : [global.actionLibrary.attack, global.actionLibrary.ice, global.actionLibrary.cura]
		}
	]
}
InitGameData();
