// true se existe uma instância ainda FECHADA de _obj tocando a posição (_x, _y)
// usado por objetos que só bloqueiam enquanto não foram abertos (cortinas e portas)
function BloqueadoPorFechado(_x, _y, _obj)
{
	var _lista = ds_list_create();
	var _n = instance_place_list(_x, _y, _obj, _lista, false);
	var _bloq = false;

	for (var i = 0; i < _n; i++)
	{
		if (!_lista[| i].aberta) { _bloq = true; break; }
	}

	ds_list_destroy(_lista);
	return _bloq;
}

// true se a posição (_x, _y) está bloqueada
function Bloqueado(_x, _y)
{
	// objetos de cenário que sempre bloqueiam (usam a máscara do próprio sprite)
	// para deixar outro objeto sólido, é só colocar o nome dele nesta lista
	static _solidos = [
		oAparelhos, oArmario, oBalcao, oCabine, oCadeira, oCadeira_lado,
		oCama, oCama_Paciente, oCama_Saci, oLixo, oMaquina, oMesa, oPia,
		oVaso, oVasoCacto, oVasoPlanta, oPisadeira, oMaoDeCabelo
	];

	if (place_meeting(_x, _y, oColisao)) return true;

	for (var i = 0; i < array_length(_solidos); i++)
	{
		if (place_meeting(_x, _y, _solidos[i])) return true;
	}

	// cortinas e portas só bloqueiam enquanto estiverem fechadas
	if (BloqueadoPorFechado(_x, _y, oCortina)) return true;
	if (BloqueadoPorFechado(_x, _y, oPorta_Masculino)) return true;
	if (BloqueadoPorFechado(_x, _y, oPorta_Feminino)) return true;
	if (BloqueadoPorFechado(_x, _y, oPorta_Comum)) return true;

	return false;
}

// Retorna true quando o jogador está visível, sem parede ou móvel bloqueando a linha.
function VisaoDesobstruida(_x1, _y1, _x2, _y2)
{
	if (collision_line(_x1, _y1, _x2, _y2, oColisao, true, true) != noone) return false;

	static _obstaculosVisao = [
		oAparelhos, oArmario, oBalcao, oCabine, oCadeira, oCadeira_lado,
		oCama, oCama_Paciente, oCama_Saci, oLixo, oMaquina, oMesa, oPia,
		oVaso, oVasoCacto, oVasoPlanta, oPisadeira, oMaoDeCabelo
	];
	for (var i = 0; i < array_length(_obstaculosVisao); i++)	
	{
		if (collision_line(_x1, _y1, _x2, _y2, _obstaculosVisao[i], true, true) != noone) return false;
	}

	static _portas = [oCortina, oPorta_Masculino, oPorta_Feminino, oPorta_Comum];
	for (var i = 0; i < array_length(_portas); i++)
	{
		var _porta = collision_line(_x1, _y1, _x2, _y2, _portas[i], true, true);
		if (_porta != noone && !_porta.aberta) return false;
	}

	return true;
}

// igual ao Bloqueado, mas também impede o inimigo de se sobrepor a outro inimigo
// (só barra se ele ainda não estiver encostado nesse outro, para ninguém ficar preso)
function BloqueadoInimigo(_x, _y)
{
	if (Bloqueado(_x, _y)) return true;

	var _outro = instance_place(_x, _y, oSlime);   // oBat também conta (herda do oSlime)
	if (_outro != noone && !place_meeting(x, y, _outro)) return true;

	return false;
}

function MoveAndCollide(_moveX, _moveY)
{
	if (!Bloqueado(x + _moveX, y))
	{
		x += _moveX;
	}

	if (!Bloqueado(x, y + _moveY))
	{
		y += _moveY;
	}
}

// move a instância para o ponto livre mais próximo, sempre dentro da room
function PosicaoLivre(_margem = 16)
{
	x = clamp(x, _margem, room_width - _margem);
	y = clamp(y, _margem, room_height - _margem);

	if (!Bloqueado(x, y)) return;   // já está num lugar livre

	var _ox = x;
	var _oy = y;

	// procura em círculos cada vez maiores ao redor do ponto original
	for (var _r = 4; _r <= 160; _r += 4)
	{
		for (var _a = 0; _a < 360; _a += 30)
		{
			var _nx = clamp(_ox + lengthdir_x(_r, _a), _margem, room_width - _margem);
			var _ny = clamp(_oy + lengthdir_y(_r, _a), _margem, room_height - _margem);

			if (!Bloqueado(_nx, _ny))
			{
				x = _nx;
				y = _ny;
				return;
			}
		}
	}
}
