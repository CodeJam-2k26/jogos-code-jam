global.musicaCampoAsset = -1;  
global.musicaCampoId    = -1;  
global.musicaBatalhaId  = -1;


function MusicaCampo(_snd)
{
	if (_snd == -1)
	{
		if (global.musicaCampoId != -1) audio_stop_sound(global.musicaCampoId);
		global.musicaCampoId = -1;
		global.musicaCampoAsset = -1;
		return;
	}

	if (global.musicaCampoAsset == _snd) && (global.musicaCampoId != -1)
	{
		if (audio_is_playing(global.musicaCampoId)) || (audio_is_paused(global.musicaCampoId)) return;
	}

	if (global.musicaCampoId != -1) audio_stop_sound(global.musicaCampoId);

	global.musicaCampoAsset = _snd;
	global.musicaCampoId = audio_play_sound(_snd, 10, true);   
}

// Pausa a música de campo (guarda o ponto) e toca a de batalha em loop
function MusicaBatalhaIniciar(_snd)
{
	if (global.musicaCampoId != -1) audio_pause_sound(global.musicaCampoId);
	if (global.musicaBatalhaId != -1) audio_stop_sound(global.musicaBatalhaId);

	global.musicaBatalhaId = audio_play_sound(_snd, 20, true);
}

// Para a de batalha e, se _voltarCampo for true, continua a de campo de onde parou
function MusicaBatalhaFinalizar(_voltarCampo)
{
	if (global.musicaBatalhaId != -1)
	{
		audio_stop_sound(global.musicaBatalhaId);
		global.musicaBatalhaId = -1;
	}

	if (global.musicaCampoId != -1)
	{
		if (_voltarCampo) audio_resume_sound(global.musicaCampoId);
		else MusicaCampo(-1);   // derrota: silêncio
	}
}