global.inventory.potion.count += 1;
array_push(global.collectedItems, itemId);
instance_destroy();