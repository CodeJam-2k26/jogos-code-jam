//se essa poção específica já foi coletada antes, ela nem aparece

var _alreadyCollected = false;
for (var i = 0; i < array_length(global.collectedItems); i++)
{
	if (global.collectedItems[i] == itemId) { _alreadyCollected = true; break; }
}
if (_alreadyCollected) instance_destroy();
