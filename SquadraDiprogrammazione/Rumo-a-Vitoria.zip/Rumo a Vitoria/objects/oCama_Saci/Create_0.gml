dialogoAberto = false;
proximaEtapa = "";

function AoFecharDialogo()
{
	SaciAposDialogo(id);
}
