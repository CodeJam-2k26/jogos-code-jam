if (!instance_exists(oPlayer) || dialogoAberto || instance_exists(oMenu)
	|| instance_exists(oBattle) || instance_exists(oDialogo) || instance_exists(oTransicao)) exit;

if (!oPlayer.parado && distance_to_object(oPlayer) <= 16 && keyboard_check_pressed(ord("Z")))
{
	if (global.muletaEntregue)
	{
		SaciAbrirDialogo(id, ["Se não me engano a chave do hospital está no escritório do diretor."]);
	}
	else if (!global.saciIntroducaoFeita)
	{
		SaciAbrirDialogo(id, [
			"Quem é você?",
			"Como pode ver, estou com minha perna esquerda quebrada.",
			"Não posso sair do hospital."
		], "menu_resposta");
	}
	else
	{
		SaciAbrirDialogo(id, [
			"O que é isso que você está levando?",
			"Uma muleta de andar de patinete!",
			"Me dê, por favor! Talvez assim eu possa sair daqui um dia."
		], "menu_entrega");
	}
}
