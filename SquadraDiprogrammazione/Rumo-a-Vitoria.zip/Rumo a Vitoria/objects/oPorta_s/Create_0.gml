aberta = false;
