// Esta interação só vale para a porta da sala 6.
if (room != rm_hospital6) exit;

if (!aberta && instance_exists(oPlayer) && !instance_exists(oMenu)
	&& !instance_exists(oBattle) && !instance_exists(oDialogo))
{
	if (distance_to_object(oPlayer) <= 10 && keyboard_check_pressed(ord("Z")))
	{
		aberta = true;
		sprite_index = sPorta_Aberta;
		image_index = 0;
	}
}
