if (!perseguir || velocidade <= 0) exit;

// só persegue quando o jogo está "solto" (sem menu, diálogo, batalha, fade ou cutscene)
if (!instance_exists(oPlayer) || oPlayer.parado
	|| instance_exists(oMenu) || instance_exists(oBattle)
	|| instance_exists(oDialogo) || instance_exists(oTransicao)) exit;

// O inimigo só percebe e persegue o jogador dentro do alcance e sem obstáculos no caminho.
if (point_distance(x, y, oPlayer.x, oPlayer.y) > alcanceVisao) exit;
if (!VisaoDesobstruida(x, y, oPlayer.x, oPlayer.y)) exit;
if (point_distance(x, y, oPlayer.x, oPlayer.y) <= velocidade) exit;

var _dir = point_direction(x, y, oPlayer.x, oPlayer.y);
var _mx = lengthdir_x(velocidade, _dir);
var _my = lengthdir_y(velocidade, _dir);

// eixos separados: ao bater numa parede ele desliza por ela
if (!BloqueadoInimigo(x + _mx, y)) x += _mx;
if (!BloqueadoInimigo(x, y + _my)) y += _my;
