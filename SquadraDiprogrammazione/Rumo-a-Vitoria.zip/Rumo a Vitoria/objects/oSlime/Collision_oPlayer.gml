if (!variable_instance_exists(id, "possibleEncounters"))
{
	possibleEncounters = [
		[global.enemies.slimeG],
		[global.enemies.slimeG, global.enemies.slimeG, global.enemies.bat],
		[global.enemies.slimeG, global.enemies.bat, global.enemies.bat],
		[global.enemies.slimeG, global.enemies.slimeG],
		[global.enemies.slimeG, global.enemies.bat],
		[global.enemies.bat, global.enemies.bat]
	];
}

var _sorteado = possibleEncounters[irandom(array_length(possibleEncounters) - 1)];
NewEncounter(_sorteado, GetBattleBackground());