// perseguição ao jogador (vale também para o oBat, que herda do oSlime)
// dá para mudar por instância: no Inspector da room (Variables) ou no código de criação da instância
//   perseguir  = true -> segue o jogador | false -> fica parado
//   velocidade = pixels por frame (o jogador anda 2.5)
if (!variable_instance_exists(id, "perseguir"))  perseguir  = true;
if (!variable_instance_exists(id, "velocidade")) velocidade = 1;
if (!variable_instance_exists(id, "alcanceVisao")) alcanceVisao = 128;
