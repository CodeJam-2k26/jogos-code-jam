if (!aberta && instance_exists(oPlayer) && !instance_exists(oMenu) && !instance_exists(oBattle) && !instance_exists(oDialogo) && !instance_exists(oTransicao))
{
	if (distance_to_object(oPlayer) <= 10 && keyboard_check_pressed(ord("Z")))
	{
		aberta = true;
		sprite_index = sPorta_feminino_Aberta;
	}
}
