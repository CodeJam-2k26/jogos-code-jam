alpha = 0;           // 0 = transparente, 1 = tudo preto
direcao = 1;         // 1 = escurece, -1 = clareia
// maior = mais rápido (0.05 ≈ 1/3 de segundo a 60 fps)
if (!variable_instance_exists(id, "velocidade")) velocidade = 0.05;

// o destino chega pelo instance_create_depth; só garante um valor padrão
if (!variable_instance_exists(id, "sala_destino")) sala_destino = noone;
