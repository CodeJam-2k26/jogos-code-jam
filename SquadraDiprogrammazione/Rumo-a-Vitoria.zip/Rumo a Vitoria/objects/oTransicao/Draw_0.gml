draw_set_alpha(alpha);
draw_rectangle_color(-1, -1, room_width + 1, room_height + 1, c_black, c_black, c_black, c_black, false);
draw_set_alpha(1);