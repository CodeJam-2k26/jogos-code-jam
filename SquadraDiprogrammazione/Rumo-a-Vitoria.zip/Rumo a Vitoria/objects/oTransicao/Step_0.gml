alpha += velocidade * direcao;

if (direcao == 1 && alpha >= 1)
{
	// tela toda preta: troca a room e começa a clarear
	alpha = 1;
	direcao = -1;
	if (variable_instance_exists(id, "batalhaInimigos"))
	{
		IniciarEncontro(batalhaInimigos, batalhaFundo, batalhaCriador);
	}
	else
	{
		room_goto(sala_destino);
	}
}
else if (direcao == -1 && alpha <= 0)
{
	instance_destroy();
}
