falas = ["É uma muleta normal."];
nome = "";
