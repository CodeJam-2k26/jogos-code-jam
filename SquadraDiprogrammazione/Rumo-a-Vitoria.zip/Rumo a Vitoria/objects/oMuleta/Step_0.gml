if (instance_exists(oPlayer) && !instance_exists(oMenu) && !instance_exists(oBattle) && !instance_exists(oDialogo))
{
	if (distance_to_object(oPlayer) <= 8 && keyboard_check_pressed(ord("Z")))
	{
		instance_create_depth(0, 0, -99999, oDialogo, {falas: falas, nome: nome});
	}
}
