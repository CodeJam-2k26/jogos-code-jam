//background art
var _battleViewWidth = camera_get_view_width(view_camera[0]);
var _battleViewHeight = camera_get_view_height(view_camera[0]);
draw_sprite_ext(
	battleBackground, 0, x, y,
	_battleViewWidth / sprite_get_width(battleBackground),
	_battleViewHeight / sprite_get_height(battleBackground),
	0, c_white, 1
);

//draw units in deph order
var _unitWithCurrentTurn = noone;
if (phase == "party") && (partySelecting) && (partyOrderIndex < array_length(partyOrder))
{
	_unitWithCurrentTurn = partyOrder[partyOrderIndex].id;
}
else if (phase == "party") && (!partySelecting) && (queueIndex < array_length(partyQueue))
{
	_unitWithCurrentTurn = partyQueue[queueIndex].user.id;
}
else if (phase == "enemy") && (enemyIndex < array_length(enemyUnits))
{
	_unitWithCurrentTurn = enemyUnits[enemyIndex].id;
}

for (var i =0; i<array_length(unitRenderOrder); i++)
{
	with(unitRenderOrder[i])
	{
		draw_self();
		
		//desenha ícone pra cada status effect ativo na unidade
		if (hp > 0)
		{
			var _iconScale = 0.15;    
			var _iconSpacing = 16;    // distancia vertilcal entre icones empilhados
			var _iconOffsetX = 10;    // o quanto o ícone fica pro lado do inimigo
			var _iconOffsetY = -10;   // altura inicial (relativa ao centro do inimigo)
		
			for (var s = 0; s < array_length(statusEffects); s++)
			{
				var _icon = noone;
				if (statusEffects[s].name == "Congelamento") _icon = sCongelado;
			
				if (_icon != noone)
				{
					draw_sprite_ext(_icon, 0, x + _iconOffsetX, y + _iconOffsetY + (s * _iconSpacing), _iconScale, _iconScale, 0, c_white, 1);
				}
			}
		}
	}
}

// draw UI boxes
draw_sprite_stretched(sBox2,0,x+85, y+115, 235,64);
draw_sprite_stretched(sBox2,0,x, y+115,79,64);

//positions
#macro COLUMN_ENEMY 15
#macro COLUMN_NAME 90
#macro COLUMN_HP 160
#macro COLUMN_MP 220

//draw headings
draw_set_font(Regular_Pixel);
draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_set_color(c_gray);
draw_text(x+COLUMN_ENEMY, y+120,"INIMIGO");
draw_text(x+COLUMN_NAME, y+120,"NOME");
draw_text(x+COLUMN_HP, y+120,"PV");
draw_text(x+COLUMN_MP, y+120,"PM");

//draw enemy names
draw_set_font(Regular_Pixel);
draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_set_color(c_white);
var _drawLimit = 3;
var _drawn = 0;
for (var i =0; (i<array_length(enemyUnits)) && ( _drawn < _drawLimit); i++)
{
	var _char = enemyUnits[i];
	if(_char.hp > 0)
	{
		var _row = _drawn;
		_drawn++;
		draw_set_halign(fa_left);
		draw_set_colour(c_white);
		if (_char.id == _unitWithCurrentTurn) draw_set_color(c_yellow);
		draw_text(x+COLUMN_ENEMY, y+130+(_row*16), _char.name);
	}
}

//draw party info
for (var i = 0; i <array_length(partyUnits); i++)
{
	draw_set_halign(fa_left);
	draw_set_color(c_white);
	var _char = partyUnits[i];
	if(_char.id == _unitWithCurrentTurn) draw_set_color(c_yellow);
	if( _char.hp <= 0) draw_set_colour(c_red);
	draw_text(x+COLUMN_NAME,y+130+(i*16),_char.name);
	draw_set_halign(fa_right);
	
	draw_set_color(c_white);
	if(_char.hp <(_char.hpMax * 0.5)) draw_set_color(c_orange);
	if(_char.hp <=0 ) draw_set_color(c_red);
	draw_text(x+COLUMN_HP+50,y+130+(i*16),string(_char.hp) + "/" + string(_char.hpMax));
	
	draw_set_color(c_white);
	if(_char.mp <(_char.mpMax * 0.5)) draw_set_color(c_orange);
	if(_char.hp <=0 ) draw_set_color(c_red);
	draw_text(x+COLUMN_MP+50,y+130+(i*16),string(_char.mp) + "/" + string(_char.mpMax));
	
	draw_set_color(c_white);
}
	
//draw target cursor
if(cursor.active)
{
	if (cursor.activeTarget != noone)
	{
		var _targetsToMark = is_array(cursor.activeTarget) ? cursor.activeTarget : [cursor.activeTarget];
		if (is_array(cursor.activeTarget)) draw_set_alpha(sin(get_timer()/50000)+1);
		for (var i = 0; i < array_length(_targetsToMark); i++)
		{
			var _target = _targetsToMark[i];
			var _sprite = _target.sprite_index;
			var _pointerX = _target.x + (sprite_get_width(_sprite)*0.5 - sprite_get_xoffset(_sprite)) * _target.image_xscale;
			var _pointerY = _target.y + (sprite_get_height(_sprite)*0.5 - sprite_get_yoffset(_sprite)) * _target.image_yscale;
			draw_sprite(sPointer, 0, _pointerX, _pointerY);
		}
		draw_set_alpha(1.0);
	}
}

//preview de vida e dano/cura ao mirar num alvo (funciona pra alvo único ou pra todos)
if (cursor.active) && (cursor.activeTarget != noone)
{
	var _targetsToPreview = is_array(cursor.activeTarget) ? cursor.activeTarget : [cursor.activeTarget];
	var _targetCount = array_length(_targetsToPreview);
	
	var _lineSpacing = 16;
	
	for (var t = 0; t < _targetCount; t++)
	{
		var _target = _targetsToPreview[t];
		var _dmgText = "";
		var _effectText = "";
		
		if (!is_undefined(cursor.activeAction[$ "previewDamage"]))
		{
			var _amount = cursor.activeAction.previewDamage(cursor.activeUser, _target, _targetCount);
			if (_amount < 0)
			{
				_dmgText = "Dano: " + string(-_amount);
			}
			else
			{
				_dmgText = "Cura: " + string(_amount);
			}
		}
		
		//o efeito de status só é mostrado (e só é aplicado) quando mira um único alvo
		if (_targetCount == 1) && (!is_undefined(cursor.activeAction[$ "statusEffect"])) && (cursor.activeAction.statusEffect != -1)
		{
			_effectText = "Aplica: " + cursor.activeAction.statusEffect.name;
		}
		
		var _hpText = "PV: " + string(max(_target.hp,0)) + "/" + string(_target.hpMax);
		var _previewLines = [_hpText];
		if (_dmgText != "") array_push(_previewLines, _dmgText);
		if (_effectText != "") array_push(_previewLines, _effectText);
		var _boxWidth = 0;
		draw_set_font(Regular_Pixel);
		for (var i = 0; i < array_length(_previewLines); i++)
		{
			_boxWidth = max(_boxWidth, string_width(_previewLines[i]));
		}
		_boxWidth += 12;
		var _boxHeight = 8 + (array_length(_previewLines) * _lineSpacing);
		var _boxX = clamp(_target.x-(_boxWidth/2), x+4, x+_battleViewWidth-_boxWidth-4);
		var _boxY = clamp(_target.y-50, y+4, y+111-_boxHeight);
		draw_sprite_stretched(sBox2, 0, _boxX, _boxY, _boxWidth, _boxHeight);
		draw_set_halign(fa_center);
		draw_set_valign(fa_top);
		draw_set_color(c_white);
		for (var i = 0; i < array_length(_previewLines); i++)
		{
			draw_text(_boxX+(_boxWidth/2), _boxY+4+(i*_lineSpacing), _previewLines[i]);
		}
	}
}
