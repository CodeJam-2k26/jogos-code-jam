instance_deactivate_all(true);
// A transição que iniciou o encontro precisa continuar ativa para revelar a batalha.
instance_activate_object(oTransicao);

MusicaBatalhaIniciar(musBatalha);

// guarda a configuração de view atual e coloca a batalha em tela cheia
viewAntesAtiva   = view_enabled;
viewAntesVisivel = view_visible[0];

if (view_camera[0] == -1) view_camera[0] = camera_create_view(0, 0, 320, 180);

view_enabled    = true;
view_visible[0] = true;
view_wport[0]   = 640;
view_hport[0]   = 360;
camera_set_view_size(view_camera[0], 320, 180);
camera_set_view_pos(view_camera[0], x, y);

//embaralha a ordem dos inimigos a cada encontro
enemies = ShuffleArray(enemies);

units =[];
turnCount = 0;
roundCount = 0;
battleWaitTimeFrames = 30
battleWaitTimeRemaining = 0;
currentUser = noone;
currentAction = -1;
currentTargets = noone;
unitRenderOrder =[];
outcomeStarted = false;

//controle de fase (party escolhe ordem e age, depois os inimigos agem)
phase = "party";
partyOrder = [];
partyOrderIndex = 0;
enemyIndex = 0;

//fila de ações da party: primeiro todo mundo escolhe, depois executa em ordem
partyQueue = [];
queueIndex = 0;
partySelecting = true;

//make targetting cursor
cursor =
{
	activeUser: noone,
	activeTarget: noone,
	activeAction: -1,
	targetSide: -1,
	targetIndex: 0,
	targetAll: false,
	confirmDelay: 0,
	active: false
};

//make enemies
for (var i =0; i < array_length(enemies); i++)
{
		var _enemyY = y+75+(i*17);
		if (i == 1) _enemyY -= 6;
		enemyUnits[i] = instance_create_depth(x+225+(i*26), _enemyY, depth-10,oBattleUnitEnemy, enemies[i]);
	array_push(units, enemyUnits[i]);
}

//make party
for (var i =0; i < array_length(global.party); i++)
{
	partyUnits[i] = instance_create_depth(x+62+(i*20), y+68+(i*25), depth-10,oBattleUnitPC, global.party[i]);
	array_push(units, partyUnits[i]);
}

// Guarda as posições de formação e prepara a entrada dos dois grupos.
for (var i = 0; i < array_length(enemyUnits); i++)
{
	var _unit = enemyUnits[i];
	_unit.entranceTargetX = _unit.x;
	_unit.entranceTargetY = _unit.y;
	_unit.entranceStartX = x + 350 + (i * 12);
	_unit.entranceDelay = i * 6;
	_unit.x = _unit.entranceStartX;
}
for (var i = 0; i < array_length(partyUnits); i++)
{
	var _unit = partyUnits[i];
	_unit.entranceTargetX = _unit.x;
	_unit.entranceTargetY = _unit.y;
	_unit.entranceStartX = x - 50 - (i * 12);
	_unit.entranceDelay = i * 6;
	_unit.x = _unit.entranceStartX;
}
introTimer = 0;

//Get render order
RefreshRenderOrder = function()
{
	unitRenderOrder =[];
	array_copy(unitRenderOrder,0,units,0,array_length(units));
	array_sort(unitRenderOrder,function(_1, _2)
	{
		return _1.y - _2.y;
	});
}
RefreshRenderOrder();

function BattleStateChooseOrder()
{
	if (!instance_exists(oMenu))
	{
		//lista quem da party ainda está vivo e ainda não foi escolhido nessa rodada
		var _remaining = [];
		for (var i = 0; i < array_length(partyUnits); i++)
		{
			var _candidate = partyUnits[i];
			if (!instance_exists(_candidate)) || (_candidate.hp <= 0) continue;
			
			var _alreadyChosen = false;
			for (var j = 0; j < array_length(partyOrder); j++)
			{
				if (partyOrder[j] == _candidate) { _alreadyChosen = true; break; }
			}
			if (!_alreadyChosen) array_push(_remaining, _candidate);
		}
		
		//todo mundo da party já foi escolhido, começa a agir
		if (array_length(_remaining) == 0)
		{
			phase = "party";
			partyOrderIndex = 0;
			partyQueue = [];
			queueIndex = 0;
			partySelecting = true;
			battleState = BattleStateSelectAction;
			BattleStateSelectAction();   // já roda no mesmo frame, sem esperar o próximo Step
			exit;
		}
		
		//só sobrou um vivo, escolhe automático sem precisar de menu
		if (array_length(_remaining) == 1)
		{
			array_push(partyOrder, _remaining[0]);
			BattleStateChooseOrder();   // processa a transição no mesmo frame também
			exit;
		}
		
		var _menuOptions = [];
		for (var i = 0; i < array_length(_remaining); i++)
		{
			array_push(_menuOptions, [_remaining[i].name, MenuChooseOrder, [_remaining[i]], true]);
		}
		
		Menu(x+10, y+110, _menuOptions, -1, 74, 60);
	}
}

function QueueAction(_user, _action, _targets)
{
	array_push(partyQueue, {user: _user, action: _action, targets: _targets});
	
	partyOrderIndex++;
	if (partyOrderIndex >= array_length(partyOrder))
	{
		//todo mundo da party já escolheu, começa a executar em ordem
		partySelecting = false;
		queueIndex = 0;
	}
	battleState = BattleStateSelectAction;
}

function MenuBackToOrder()
{
	with (oMenu) instance_destroy();
	with (oBattle)
	{
		//desfaz toda a ordem escolhida, pra escolher tudo de novo do zero
		partyOrder = [];
		battleState = BattleStateChooseOrder;
	}
}

function BattleStateSelectAction()
{	
	if(!instance_exists(oMenu))
	{
		//fase de EXECUÇÃO da fila da party: só toca as ações já escolhidas, sem abrir menu
		if (phase == "party") && (!partySelecting)
		{
			var _queued = partyQueue[queueIndex];
			if (!instance_exists(_queued.user)) || (_queued.user.hp <= 0)
			{
				battleState = BattleStateVictoryCheck;
				exit;
			}
			
			var _targets = _queued.targets;
			if (_queued.action.targetEnemyByDefault)
			{
				var _enemiesAlive = array_filter(enemyUnits, function(_unit, _index) { return (_unit.hp > 0); });
				if (array_length(_enemiesAlive) == 0)
				{
					battleState = BattleStateVictoryCheck;
					exit;
				}
				if (is_array(_targets))
				{
					if (array_length(_targets) > 0) && (_targets[0].object_index == oBattleUnitEnemy)
					{
						_targets = array_filter(_targets, function(_unit, _index) { return (_unit.hp > 0); });
						if (array_length(_targets) == 0) _targets = _enemiesAlive;
					}
				}
				else if (instance_exists(_targets)) && (_targets.object_index == oBattleUnitEnemy) && (_targets.hp <= 0)
				{
					_targets = _enemiesAlive[0];
				}
			}
			BeginAction(_queued.user, _queued.action, _targets);
			exit;
		}
		
	//Get Current unit dependendo da fase (party ou inimigos)
	var _unit;
	if (phase == "party")
	{
		_unit = partyOrder[partyOrderIndex];
	}
	else
	{
		_unit = enemyUnits[enemyIndex];
	}
	
	//is the unit dead or unable to act?
	if (!instance_exists(_unit)) || (_unit.hp <=0)
	{
		battleState = BattleStateVictoryCheck;
		exit;
	}
	
	//select an action to perform
	//BeginAction(_unit.id, global.actionLibrary.attack, _unit.id);
	
	if(_unit.object_index == oBattleUnitPC)
	{
		//compile the action menu
		var _menuOptions = [];
		var _subMenus = {};
		
		var _actionList = _unit.actions;
		
		for (var i =0; i < array_length(_actionList); i ++)
		{
			var _action = _actionList[i];
			var _avaible = true;
			var _nameAndCount = _action.name;

			//se a ação depende de um item, checa o estoque
			if (!is_undefined(_action[$ "itemKey"]))
			{
				var _itemCount = global.inventory[$ _action.itemKey].count;
				_nameAndCount = _action.name + " x" + string(_itemCount);
				_avaible = (_itemCount > 0);
			}
			
			//se a ação gasta MP, só fica disponível com MP suficiente
			if (!is_undefined(_action[$ "mpCost"]))
			{
				_avaible = (_unit.mp >= _action.mpCost);
			}
			if (_action.subMenu == -1)
			{
				array_push(_menuOptions, [_nameAndCount, MenuSelectAction, [_unit, _action], _avaible]);
			}
			else
			{
				//create or add subMenu
				if(is_undefined(_subMenus[$ _action.subMenu]))
				{
					variable_struct_set(_subMenus, _action.subMenu, [[_nameAndCount, MenuSelectAction, [_unit, _action], _avaible]]);
				}
				else
				{
					array_push(_subMenus[$ _action.subMenu], [_nameAndCount, MenuSelectAction, [_unit, _action], _avaible])
				}
			}
		}
		
			//turn sub menus into array
			var _subMenusArray = variable_struct_get_names(_subMenus);
			for (var i = 0; i < array_length(_subMenusArray); i++)
			{
				//sort submenu if needed
				//(here)
				
				//add back option at the end of each submenu
				array_push(_subMenus[$ _subMenusArray[i]], ["Voltar", MenuGoBack, -1, true]);
				//add submenus into main menu
				array_push(_menuOptions, [_subMenusArray[i], SubMenu, [_subMenus[$ _subMenusArray[i]]], true]);
			}
			
		//opção de voltar e escolher outro personagem pra agir 
		array_push(_menuOptions, ["Voltar", MenuBackToOrder, -1, true]);
			
		Menu(x+10, y+110, _menuOptions, -1, 74, 60);
	}
	else
	{

		var _enemyAction = _unit.AIscript();
		if( _enemyAction != -1) BeginAction(_unit.id, _enemyAction[0], _enemyAction[1]);
	}
	}
}

function BeginAction(_user, _action, _targets)
{
	currentUser = _user;
	currentAction = _action;
	currentTargets = _targets;
	if(!is_array(currentTargets)) currentTargets = [currentTargets];
	battleWaitTimeRemaining = battleWaitTimeFrames;
	with(_user)
	{
		acting = true;
		//vai usar a animação definida para essa ação e do user
		if (!is_undefined(_action[$ "userAnimation"])) && (!is_undefined(_user.sprites[$ _action.userAnimation]))
		{
			sprite_index = sprites[$ _action.userAnimation];
			image_index = 0;
		}
	}
	battleState = BattleStatePerformAction;
}

function BattleStatePerformAction()
{
	//se a animação se estiver rolando
	if(currentUser.acting)
	{
		//quando acabar, rola o efeito da ação se existir
		if (currentUser.image_index >= currentUser.image_number -1)
		{
			with(currentUser)
			{
				sprite_index = sprites.idle;
				image_index = 0;
				acting = false;
			}
			if (variable_struct_exists(currentAction, "effectSprite")) && (currentAction.effectSprite != noone)
			{
				if (currentAction.effectOnTarget == MODE.ALWAYS) || ( (currentAction.effectOnTarget == MODE.VARIES) && (array_length(currentTargets) <= 1) )
				{
					for (var i = 0; i <array_length(currentTargets); i++)
					{
						instance_create_depth(currentTargets[i].x,currentTargets[i].y,currentTargets[i].depth-1,oBattleEffect,{sprite_index: currentAction.effectSprite});
					}
				}
				else //play it at 0,0
				{
					var _effectSprite = currentAction.effectSprite
					if(variable_struct_exists(currentAction, "effectSpriteNoTarget")) _effectSprite = currentAction.effectSpriteNoTarget;
					instance_create_depth(x,y,depth-100, oBattleEffect,{sprite_index: _effectSprite});
				}
			}
			//se a ação gasta MP, desconta do usuário
			if (!is_undefined(currentAction[$ "mpCost"]))
			{
				currentUser.mp = max(currentUser.mp - currentAction.mpCost, 0);
			}
			currentAction.func(currentUser, currentTargets);
		}
	}
	else //esperar a animação e o fim do turno
	{
		if(!instance_exists(oBattleEffect))
		{
			battleWaitTimeRemaining--
			if(battleWaitTimeRemaining == 0)
			{
				battleState = BattleStateVictoryCheck;
			}
		}
	}
}

function CheckBattleOutcome()
{
	//o lado inimigo foi derrotado?
	var _enemiesAlive = array_filter(enemyUnits, function(_unit, _index) { return (_unit.hp > 0); });
	if (array_length(_enemiesAlive) == 0) return BattleStateVictory;
	
	//o grupo foi derrotado?
	var _partyAlive = array_filter(partyUnits, function(_unit, _index) { return (_unit.hp > 0); });
	if (array_length(_partyAlive) == 0) return BattleStateDefeat;
	
	return -1;
}

function BattleStateVictoryCheck()
{
	var _outcome = CheckBattleOutcome();
	if (_outcome != -1)
	{
		battleState = _outcome;
		exit;
	}
	
	battleState = BattleStateAdvanceTurn;
}

function BattleStateVictory()
{
	if (!outcomeStarted)
	{
		outcomeStarted = true;
		
		//guarda o HP e o MP finais da batalha na party de verdade
		for (var i = 0; i < array_length(global.party); i++)
		{
			global.party[i].hp = global.party[i].hpMax;
			global.party[i].mp = partyUnits[i].mp;
		}
		
		var _xpGained = 0;
		for (var i = 0; i < array_length(enemyUnits); i++) { _xpGained += enemies[i].xpValue; }
		instance_create_depth(x+150, y+40, depth-1, oBattleFloatingText, {font: Regular_Pixel, col: c_yellow, text: "Vitória! +" + string(_xpGained) + " XP"});
		
	//distribui o xp entre quem sobreviveu e confere quem subiu de nível
	for (var i = 0; i < array_length(global.party); i++)
	{
		var _member = global.party[i];
		var _leveledUp = PartyGainXP(_member, _xpGained);
		if (_leveledUp)
		{
			instance_create_depth(x+150, y+55+(i*12), depth-1, oBattleFloatingText, {font: Regular_Pixel, col: c_aqua, text: _member.name + " subiu de nível!"});
		}
		
	}
		battleWaitTimeRemaining = 90;
	}
	
	battleWaitTimeRemaining--;
	if (battleWaitTimeRemaining <= 0) EndBattle(true);
}

function BattleStateDefeat()
{
	if (!outcomeStarted)
	{
		outcomeStarted = true;
		// Mantém o estado final da batalha disponível para os sistemas do jogo.
		for (var i = 0; i < array_length(global.party); i++)
		{
			global.party[i].hp = global.party[i].hpMax;
			global.party[i].mp = partyUnits[i].mp;
		}
		instance_create_depth(x+150, y+40, depth-1, oBattleFloatingText, {font: Regular_Pixel, col: c_red, text: "Derrota..."});
		battleWaitTimeRemaining = 90;
	}
	battleWaitTimeRemaining--;
	if (battleWaitTimeRemaining <= 0) EndBattle(false);
}

function EndBattle(_won)
{
	view_enabled    = viewAntesAtiva;
	view_visible[0] = viewAntesVisivel;
	MusicaBatalhaFinalizar(_won);
	instance_activate_all();
	
	with (oBattleUnits) instance_destroy();
	with (oBattleEffect) instance_destroy();
	
	if (_won)
	{
		if (instance_exists(creator))
		{
			instance_destroy(creator);
		}
		instance_destroy();
	}
	else
	{
		if (variable_global_exists("entradaSala"))
		{
			global.spawnPorta = { sala: global.entradaSala.sala, x: global.entradaSala.x, y: global.entradaSala.y };
		}
		instance_destroy();
		TransicaoParaSala(room);
	}
}

function BattleStateAdvanceTurn()
{
	turnCount++;
	
	if (phase == "party")
	{
		queueIndex++;
		if (queueIndex >= array_length(partyQueue))
		{
			//acabou o turno da party, começa o dos inimigos
			phase = "enemy";
			enemyIndex = 0;
		}
	}
		else
	{
		enemyIndex++;
		if (enemyIndex >= array_length(enemyUnits))
		{
			//acabou a rodada inteira: aplica os status effects de todo mundo de uma vez
			TickAllStatusEffects(units);
			
			//o dano de status (ex: congelamento) pode ter decidido a batalha
			var _outcome = CheckBattleOutcome();
			if (_outcome != -1)
			{
				battleState = _outcome;
				exit;
			}
			
			roundCount++;
			partyOrder = [];
			battleState = BattleStateChooseOrder;
			exit;
		}
	}
	
	battleState = BattleStateSelectAction;
}

function BattleStateIntro()
{
	introTimer++;
	var _allArrived = true;
	for (var i = 0; i < array_length(units); i++)
	{
		var _unit = units[i];
		var _elapsed = introTimer - _unit.entranceDelay;
		if (_elapsed < 0)
		{
			_allArrived = false;
			continue;
		}
		// Entrada 25% mais lenta que a versão inicial.
		var _progress = clamp(_elapsed / 32, 0, 1);
		// desacelera suavemente ao chegar à formação
		var _ease = 1 - power(1 - _progress, 3);
		_unit.x = lerp(_unit.entranceStartX, _unit.entranceTargetX, _ease);
		_unit.y = _unit.entranceTargetY;
		if (_progress < 1) _allArrived = false;
	}
	if (_allArrived) battleState = BattleStateChooseOrder;
}

battleState = BattleStateIntro;


