draw_sprite_stretched(sBox2, 0, x, y, widthFull, heightFull);
draw_set_color(c_white);
draw_set_font(Regular_Pixel);
draw_set_halign(fa_left);
draw_set_valign(fa_top);

var _desc = !(description == -1);
var _scrollPush = max(0, hover - (visibleOptionsMax-1));

for(l = 0; l < (visibleOptionsMax + _desc); l++)
{
	if(l == 0) && (_desc)
	{
		draw_set_color(c_white);
		draw_text(x + xmargin, y + ymargin, description);
	}
	else
	{
		var _optionToShow = l - _desc + _scrollPush;
		if (_optionToShow >= array_length(options)) break;
		
		draw_set_color(c_white);
		var _str = options[_optionToShow][0];
		if(hover == _optionToShow)
		{
			draw_set_color(c_yellow);
		}
		if (options[_optionToShow][3] == false) draw_set_color(c_gray);
		draw_text(x + xmargin, y + ymargin +l * heightLine, _str);
	}
}

draw_sprite(sPointer, 0, x + 12, y + ymargin + ((hover + _desc - _scrollPush) * heightLine) + (heightLine * 0.5));
if(scrolling && (hover < array_length(options)-1))
{
	draw_sprite(sDownArrow, 0 ,x + widthFull * 0.5, y + heightFull - 7);
}
