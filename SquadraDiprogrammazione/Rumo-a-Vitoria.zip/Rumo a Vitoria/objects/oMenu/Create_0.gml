hover = 0;
active = true
subMenuLevel = 0
optionsAbove = []
descriptionAbove = []
closable = false
