if (instance_exists(oTransicao)) exit;   // já está em transição

if (variable_global_exists("pilhaPortas") && array_length(global.pilhaPortas) > 0)
{
	var _p = array_pop(global.pilhaPortas);
	global.spawnPorta = _p;
	TransicaoParaSala(_p.sala);
}
else if (room_previous(room) != -1)
{
	TransicaoParaSala(room_previous(room));
}