itemNecessario = "";   // chave do item no inventário (ex.: "muleta"). Vazio = porta livre
falasTrancada = ["Sinto, no meu interior, que deveria dar uma olhada antes de sair. Não precisa ser muito boa."];
