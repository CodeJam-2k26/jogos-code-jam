switch (estado)
{
	case 0:   // deita o jogador na cama
		if (instance_exists(oPlayer))
		{
			if (foraX < 0) { foraX = oPlayer.x; foraY = oPlayer.y; }

			with (oPlayer)
			{
				parado = true;
				sprite_index = sBotoIdle;
				image_index = 0;
				image_speed = 0;
				image_angle = other.anguloDeitado;
				x = other.camaX;
				y = other.camaY;
			}

			timer = 90;   // 1,5 s deitado antes da primeira fala
			estado = 1;
		}
	break;

	case 1:   // pausa curta
		timer--;
		if (timer <= 0)
		{
			instance_create_depth(0, 0, -99999, oDialogo, {falas: falas, nome: nome, dono: id});
			estado = 2;
		}
	break;

	case 2:   // espera o diálogo; AoFecharDialogo avança para o pulo
	break;

	case 3:   // pulo para fora da cama (24 quadros, em arco)
		t = min(t + 1 / 24, 1);

		with (oPlayer)
		{
			x = lerp(other.camaX, other.foraX, other.t);
			y = lerp(other.camaY, other.foraY, other.t) - sin(other.t * pi) * 14;
		}

		if (t >= 1)
		{
			with (oPlayer)
			{
				x = other.foraX;
				y = other.foraY;
				PosicaoLivre();   // garante que não termina dentro de colisão
				parado = false;
			}
			instance_destroy();
		}
	break;
}
