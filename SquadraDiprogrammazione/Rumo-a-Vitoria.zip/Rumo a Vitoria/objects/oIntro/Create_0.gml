// cutscene inicial: roda uma única vez por execução do jogo
if (!variable_global_exists("introFeita")) global.introFeita = false;

if (global.introFeita)
{
	instance_destroy();
	exit;
}
global.introFeita = true;

// ajustes (valores lidos da rm_hospital1)
camaX = 34;   
camaY = 63;
foraX = -1;           
foraY = -1;
anguloDeitado = 90;   

nome = "Narrador";
falas = [
	"*Bip... bip... bip...* Ah, o doce som de um hospital. E o cheirinho de sopa de doente.",
	"Você deve estar se perguntando: 'Como eu vim parar aqui?'. Bem, a resposta curta é: o algoritmo do amor.",
	"Vamos recapitular: você conheceu uma mulher chamada Vitória. No Tinder, claro.",
	"Ela era incrivelmente atraente nas fotos. Provavelmente cheia de filtros, mas você não ligou.",
	"O papo fluiu, ela mandou um 'Vem cá', você acelerou igual a um louco e... alcançou com sucesso a traseira de um poste.",
	"O carro deu PT, ela te deu unmatch, mas o seu cérebro de jumento tomou uma decisão.",
	"Você vai atrás dela de novo. Custe o que custar.",
	"Porque, veja bem, o seu plano genial é o seguinte:",
	"Você quer ir atrás da Vitória... que mora na cidade de Vitória... para finalmente alcançar a sua VITÓRIA!",
	"...Sério? Quem escreveu esse roteiro? Um tiozão do pavê?",
	"Enfim, chega de passar vergonha deitado. Levanta logo que a conta do hospital tá rodando e sua jornada rumo ao trocadilho começou!"
];

estado = 0;   // 0 = deita o jogador, 1 = pausa, 2 = diálogo, 3 = pulo
timer = 0;
t = 0;

// a oDialogo chama isto quando a última fala fecha
function AoFecharDialogo()
{
	with (oPlayer)
	{
		sprite_index = sBotoRun;
		image_angle = 0;
		direction = 270;
		image_index = 15;   
	}
	t = 0;
	estado = 3;
}
