/// @description Set up camera
cam = view_camera[0];
follow = oPlayer;
buff = 32;
viewWHalf = camera_get_view_width(cam) * 0.5;
viewHHalf = camera_get_view_height(cam) * 0.5;
xTo = xstart;
yTo = ystart;

display_set_gui_size(320,180);

fixa = false;  
travada = false;   

if (instance_number(oCamera) > 1)
{
	instance_destroy();
	exit;
}

if (!variable_global_exists("janelaOk"))
{
	global.janelaOk = true;

	var _s = min((display_get_width() - 40) / 640, (display_get_height() - 120) / 360);
	_s = max(1, floor(_s * 2) / 2);   
	window_set_size(640 * _s, 360 * _s);
	window_center();
}