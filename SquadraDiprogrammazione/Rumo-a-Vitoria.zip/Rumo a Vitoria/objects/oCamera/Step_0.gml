/// @description Update camera
if (keyboard_check_pressed(vk_f11)) window_set_fullscreen(!window_get_fullscreen());

if (travada)
{
	camera_set_view_size(cam, 320, 180);
	camera_set_view_pos(cam, 0, 0);
	exit;
}

if (fixa)
{
	camera_set_view_size(cam, room_width, room_height);
	camera_set_view_pos(cam, 0, 0);
}
else
{
	if (instance_exists(follow))
	{
		xTo = follow.x;
		yTo = follow.y;
	}

	x += (xTo - x) / 15;
	y += (yTo - y) / 15;

	x = clamp(x,viewWHalf,room_width-viewWHalf);
	y = clamp(y,viewHHalf,room_height-viewHHalf);


	camera_set_view_pos(cam,x-viewWHalf,y-viewHHalf);
}

