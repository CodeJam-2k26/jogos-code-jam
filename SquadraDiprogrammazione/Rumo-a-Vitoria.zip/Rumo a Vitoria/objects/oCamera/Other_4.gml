/// @description Ajusta a câmera a cada room
cam = view_camera[0];

fixa    = (room == rm_hospital2);   // room inteira
travada = (room == rm_hospital1);   // área padrão, como ao iniciar o jogo

if (!fixa && !travada)
{
	camera_set_view_size(cam, 320, 180);
	viewWHalf = 160;
	viewHHalf = 90;

	if (instance_exists(follow))
	{
		x = follow.x;
		y = follow.y;
		xTo = x;
		yTo = y;
	}
}

// música de fundo: só troca se for outra, senão continua tocando
switch (room)
{
	default: MusicaCampo(musCampo); break;
}