itemId = "muleta_hospital2";
nome = "";
falas = ["Uma muleta de andar de patinete!"];
menuAberto = false;
dialogoAberto = false;

function AoFecharDialogo()
{
	show_debug_message("pergunta: pegar muleta");

	var _cam = view_camera[0];
	var _x = camera_get_view_x(_cam) + camera_get_view_width(_cam) / 2 - 40;
	var _y = camera_get_view_y(_cam) + camera_get_view_height(_cam) / 2 - 20;

	var _options = [
		["Sim", MenuColetarItem, [id, "muleta"], true],
		["Não", MenuCancel, -1, true]
	];
	Menu(_x, _y, _options, "Pegar a muleta?", undefined, undefined, true);
}
