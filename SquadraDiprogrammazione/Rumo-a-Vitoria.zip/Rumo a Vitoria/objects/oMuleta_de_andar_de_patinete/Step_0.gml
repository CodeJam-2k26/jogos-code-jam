if (instance_exists(oMenu))
{
	menuAberto = true;
}
else if (menuAberto)
{
	menuAberto = false;   // pula 1 frame depois do menu, o mesmo Z nao reabre o dialogo
}
else if (dialogoAberto && !instance_exists(oDialogo))
{
	// o dialogo desta muleta acabou de fechar
	dialogoAberto = false;
	AoFecharDialogo();
}
else if (instance_exists(oPlayer) && !instance_exists(oBattle) && !instance_exists(oDialogo))
{
	if (distance_to_object(oPlayer) <= 8 && keyboard_check_pressed(ord("Z")))
	{
		instance_create_depth(0, 0, -99999, oDialogo, {falas: falas, nome: nome});
		dialogoAberto = true;
	}
}
