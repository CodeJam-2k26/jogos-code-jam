if (room != rm_hospital6 || !instance_exists(oPlayer) || dialogoAberto
	|| instance_exists(oMenu) || instance_exists(oBattle) || instance_exists(oDialogo)
	|| instance_exists(oTransicao)) exit;

if (!oPlayer.parado && distance_to_object(oPlayer) <= 12 && keyboard_check_pressed(ord("Z")))
{
		dialogoAberto = true;
		pendingKey = global.muletaEntregue && !chaveEntregue;
		var _falas;
		if (!global.muletaEntregue)
		{
			_falas = ["Não há nada de interessante sobre a mesa."];
		}
		else if (pendingKey)
		{
			_falas = ["Você encontrou uma chave sobre a mesa.", "Ela deve abrir uma porta do hospital. Você pegou a chave."];
		}
		else
		{
			_falas = ["A mesa está vazia."];
		}
	instance_create_depth(0, 0, -99999, oDialogo, {
		falas: _falas,
		nome: "",
		dono: id
	});
}
