itemId = "chave_hospital_rm6_mesa";
dialogoAberto = false;
pendingKey = false;
chaveEntregue = global.inventory.chave_hospital.count > 0;

for (var i = 0; i < array_length(global.collectedItems); i++)
{
	if (global.collectedItems[i] == itemId) chaveEntregue = true;
}

function AoFecharDialogo()
{
	dialogoAberto = false;
	if (pendingKey)
	{
		pendingKey = false;
		if (!chaveEntregue)
		{
			chaveEntregue = true;
			global.inventory.chave_hospital.count += 1;
			array_push(global.collectedItems, itemId);
			instance_create_depth(oPlayer.x, oPlayer.y - 24, -99999, oBattleFloatingText, {
				font: Regular_Pixel,
				col: c_lime,
				text: "Obteve Chave do Hospital!"
			});
		}
	}
}
