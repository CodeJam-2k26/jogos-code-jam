sprite_index = sCortina;
image_speed = 0;
image_index = 0;

aberta = false;
grupo = "";   // opcional: cortinas com o mesmo grupo abrem juntas