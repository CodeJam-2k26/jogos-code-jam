if (!aberta && instance_exists(oPlayer) && !instance_exists(oMenu) && !instance_exists(oBattle) && !instance_exists(oDialogo))
{
	if (distance_to_object(oPlayer) <= 10 && keyboard_check_pressed(ord("Z")))
	{
		aberta = true;
		sprite_index = sCortina_Aberta;

		// abre também as outras cortinas do mesmo grupo
		if (grupo != "")
		{
			var _g = grupo;
			with (oCortina)
			{
				if (grupo == _g)
				{
					aberta = true;
					sprite_index = sCortina_Aberta;
				}
			}
		}
	}
}
