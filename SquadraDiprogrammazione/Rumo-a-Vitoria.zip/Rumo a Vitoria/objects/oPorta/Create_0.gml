itemNecessario = "";   
falasTrancada = [""];
NextRoom = ""