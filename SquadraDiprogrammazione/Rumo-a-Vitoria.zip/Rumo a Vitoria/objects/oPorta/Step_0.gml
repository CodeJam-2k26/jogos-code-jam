if (instance_exists(oPlayer) && !instance_exists(oMenu) && !instance_exists(oBattle) && !instance_exists(oDialogo) && !instance_exists(oTransicao))
{
	if (distance_to_object(oPlayer) <= 10 && keyboard_check_pressed(ord("Z")))
	{
		var _liberada = true;

		if (itemNecessario != "")
		{
			var _item = global.inventory[$ itemNecessario];
			_liberada = (!is_undefined(_item) && _item.count > 0);
		}

		if (_liberada)
		{
			var _destino = is_string(NextRoom) ? room_next(room) : NextRoom;

			if (_destino != -1)
			{
				if (!variable_global_exists("pilhaPortas")) global.pilhaPortas = [];

				// ponto de retorno = onde o jogador estava ao usar a porta (sempre livre e visível)
				array_push(global.pilhaPortas, { sala: room, x: oPlayer.x, y: oPlayer.y });

				TransicaoParaSala(_destino);
			}
		}
		else
		{
			instance_create_depth(0, 0, -99999, oDialogo, {falas: falasTrancada, nome: ""});
		}
	}
}
