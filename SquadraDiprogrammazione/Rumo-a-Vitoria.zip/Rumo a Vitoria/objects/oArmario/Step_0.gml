if (!instance_exists(oPlayer) || instance_exists(oMenu) || instance_exists(oBattle)
	|| instance_exists(oDialogo) || instance_exists(oTransicao)) exit;

if (oPlayer.parado || distance_to_object(oPlayer) > 6 || !keyboard_check_pressed(ord("Z"))) exit;

if (vasculhado)
{
	instance_create_depth(0, 0, -99999, oDialogo, {falas: ["Já olhei isso aqui."], nome: ""});
	exit;
}

vasculhado = true;
array_push(global.armariosVasculhados, armarioId);

var _falas = [];
for (var i = 0; i < array_length(conteudo); i++)
{
	var _achado = conteudo[i];
	if (!is_struct(_achado) || !variable_struct_exists(_achado, "itemKey")) continue;
	var _itemKey = _achado.itemKey;
	if (!variable_struct_exists(global.inventory, _itemKey)) continue;

	var _quantidade = 1;
	if (variable_struct_exists(_achado, "quantidade"))
	{
		_quantidade = max(0, floor(_achado.quantidade));
	}
	if (_quantidade <= 0) continue;

	var _item = global.inventory[$ _itemKey];
	_item.count += _quantidade;
	array_push(_falas, "Você encontrou " + _item.name + " x" + string(_quantidade) + ".");
}

if (array_length(_falas) == 0) array_push(_falas, "Não encontrei nada.");
instance_create_depth(0, 0, -99999, oDialogo, {falas: _falas, nome: ""});
