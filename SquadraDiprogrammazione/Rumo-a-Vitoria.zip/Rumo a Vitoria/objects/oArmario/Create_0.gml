// Configure o conteúdo por instância usando código de criação da sala:
// conteudo = [{ itemKey: "potion", quantidade: 1 }];
if (!variable_instance_exists(id, "conteudo")) conteudo = [];

armarioId = room_get_name(room) + "_" + string(x) + "_" + string(y);
vasculhado = false;
for (var i = 0; i < array_length(global.armariosVasculhados); i++)
{
	if (global.armariosVasculhados[i] == armarioId)
	{
		vasculhado = true;
		break;
	}
}
