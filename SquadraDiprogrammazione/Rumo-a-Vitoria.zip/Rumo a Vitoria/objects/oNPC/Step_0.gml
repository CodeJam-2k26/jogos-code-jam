
// Polpo acompanha o jogador com a mesma velocidade e animação direcional.
if (questyCompanion)
{
	if (seguindo && instance_exists(oPlayer))
	{
		var _targetX = oPlayer.x + lengthdir_x(22, oPlayer.direction + 180);
		var _targetY = oPlayer.y + lengthdir_y(22, oPlayer.direction + 180);
		var _distance = point_distance(x, y, _targetX, _targetY);
		if (_distance > 4)
		{
			var _speed = min(oPlayer.spdWalk, _distance);
			var _direction = point_direction(x, y, _targetX, _targetY);
			direction = _direction;
			sprite_index = sPolpoRun;
			image_speed = 1;

			var _framesPerDirection = sprite_get_number(sprite_index) / 4;
			image_index = companionAnimIndex + (((direction div 90) mod 4) * _framesPerDirection);
			companionAnimIndex += sprite_get_speed(sprite_index) / 60;
			if (companionAnimIndex >= _framesPerDirection) companionAnimIndex -= _framesPerDirection;

			MoveAndCollide(lengthdir_x(_speed, _direction), lengthdir_y(_speed, _direction));
		}
		else
		{
			sprite_index = sPolpoIdle;
			image_speed = 0;
			image_index = 0;
			companionAnimIndex = 0;
		}
	}
	else
	{
		sprite_index = sPolpoIdle;
		image_speed = 0;
		image_index = 0;
	}
	exit;
}

if (instance_exists(oPlayer) && !conversando
	&& !instance_exists(oMenu) && !instance_exists(oBattle) && !instance_exists(oDialogo))
{
	if (!oPlayer.parado
		&& distance_to_object(oPlayer) <= distanciaInteracao
		&& keyboard_check_pressed(ord("Z")))
	{
		conversando = true;

		var _falas = jaConversou ? falasRepetidas : falas;

		instance_create_depth(0, 0, -99999, oDialogo, {
			falas: _falas,
			nome: nome,
			dono: id      // necessário para o AoFecharDialogo funcionar
		});
	}
}
