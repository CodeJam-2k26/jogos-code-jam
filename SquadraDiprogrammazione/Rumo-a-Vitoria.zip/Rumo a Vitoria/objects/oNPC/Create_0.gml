nome = "";   // aparece em amarelo na caixa. Use "" para ficar sem nome

// primeira conversa
falas = [
	""
];

// conversas seguintes (opcional)
falasRepetidas = [
	""
];

jaConversou = false;
conversando = false;
distanciaInteracao = 12;
questyCompanion = false;
seguindo = false;
companionAnimIndex = 0;

// o oDialogo chama esta função quando a caixa fecha
function AoFecharDialogo()
{
	conversando = false;
	jaConversou = true;
}
