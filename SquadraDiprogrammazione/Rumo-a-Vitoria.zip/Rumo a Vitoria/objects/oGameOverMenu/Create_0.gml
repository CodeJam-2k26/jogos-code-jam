var _options = [];

if (SaveFileExists(1))
{
	array_push(_options, ["Carregar", MenuLoadGame, [1], true]);
}

array_push(_options, ["Recomeçar", MenuRestartGame, -1, true]);

Menu(room_width/2 - 60, room_height/2, _options, "Fim de jogo...");
