// Configuração inicial do Uranus no mapa.
perseguir = true;
velocidade = 1;
alcanceVisao = 128;

// Ele aparece à direita do jogador nesta sala, então olha para a esquerda.
image_xscale = -1;
