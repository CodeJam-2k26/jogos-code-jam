if (!perseguir || velocidade <= 0) exit;

// Não persegue durante diálogos, batalhas, menus ou transições.
if (!instance_exists(oPlayer) || oPlayer.parado
	|| instance_exists(oMenu) || instance_exists(oBattle)
	|| instance_exists(oDialogo) || instance_exists(oTransicao)) exit;

var _dist = point_distance(x, y, oPlayer.x, oPlayer.y);
if (_dist > alcanceVisao || _dist <= velocidade) exit;
if (!VisaoDesobstruida(x, y, oPlayer.x, oPlayer.y)) exit;

var _dir = point_direction(x, y, oPlayer.x, oPlayer.y);
var _mx = lengthdir_x(velocidade, _dir);
var _my = lengthdir_y(velocidade, _dir);

// Mantém a orientação voltada para o jogador enquanto persegue.
if (abs(oPlayer.x - x) > 0.01) image_xscale = (oPlayer.x < x) ? -1 : 1;

if (!BloqueadoInimigo(x + _mx, y)) x += _mx;
if (!BloqueadoInimigo(x, y + _my)) y += _my;
