if (instance_exists(oTransicao) || instance_exists(oBattle)) exit;

var _encontros = [
[global.enemies.Palito],
[global.enemies.Palito, global.enemies.uranus],
[global.enemies.uranus, global.enemies.Palito]
];
var _sorteado = _encontros[irandom(array_length(_encontros) - 1)];
NewEncounter(_sorteado, GetBattleBackground());
