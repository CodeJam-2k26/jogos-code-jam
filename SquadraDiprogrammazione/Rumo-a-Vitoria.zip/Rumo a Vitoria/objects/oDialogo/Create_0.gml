// Recebe ao ser criado: falas e nome
if (!is_array(falas)) falas = [falas];
pagina = 0;
charCount = 0;
velocidade = 0.6;   
pronto = false;     
fechar = false;

// opcional: funcao chamada quando a caixa fecha
if (!variable_instance_exists(id, "dono")) dono = noone;