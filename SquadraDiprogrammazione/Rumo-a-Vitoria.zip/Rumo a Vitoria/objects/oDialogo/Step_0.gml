if (fechar)
{
	var _dono = dono;
	instance_destroy();

	if (instance_exists(_dono))
	{
		with (_dono)
		{
			if (variable_instance_exists(id, "AoFecharDialogo")) AoFecharDialogo();
		}
	}
}
else if (!pronto)
{
	pronto = true;   // ignora o frame em que a caixa foi criada
}
else
{
	if (keyboard_check_pressed(ord("Z")))
	{
		var _total = string_length(falas[pagina]);

		if (charCount < _total)
		{
			charCount = _total;                    // mostra a fala inteira
		}
		else if (pagina < array_length(falas) - 1)
		{
			pagina++;                              // próxima fala
			charCount = 0;
		}
		else
		{
			fechar = true;                         // última fala: fecha no próximo frame
		}
	}

	charCount = min(charCount + velocidade, string_length(falas[pagina]));
}
