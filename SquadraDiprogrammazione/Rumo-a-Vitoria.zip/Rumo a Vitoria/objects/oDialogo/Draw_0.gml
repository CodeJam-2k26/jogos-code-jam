var _cam = view_camera[0];
var _vx = camera_get_view_x(_cam);
var _vy = camera_get_view_y(_cam);
var _vw = camera_get_view_width(_cam);
var _vh = camera_get_view_height(_cam);

draw_set_font(Regular_Pixel);
draw_set_halign(fa_left);
draw_set_valign(fa_top);

var _w = _vw - 16;
var _largTexto = _w - 20;

// altura necessária: margem + nome + texto da fala INTEIRA + margem
// (mede a fala completa, assim a caixa não cresce enquanto o texto "digita")
var _altNome = (nome != "") ? string_height(nome) + 2 : 0;
var _altTexto = string_height_ext(falas[pagina], -1, _largTexto);
var _h = clamp(8 + _altNome + _altTexto + 8, 56, _vh - 16);   // 56 = altura mínima

var _x = _vx + 8;
var _y = _vy + _vh - _h - 8;

draw_sprite_stretched(sBox2, 0, _x, _y, _w, _h);

var _tx = _x + 10;
var _ty = _y + 8;

if (nome != "")
{
	draw_set_colour(c_yellow);
	draw_text(_tx, _ty, nome);
	_ty += string_height(nome) + 2;
}

draw_set_colour(c_white);
draw_text_ext(_tx, _ty, string_copy(falas[pagina], 1, floor(charCount)), -1, _largTexto);