sprite_index = sPorta;
image_speed = 0;
image_index = 0;

aberta = false;   // porta fechada bloqueia o jogador; ao interagir (Z) ela abre e libera a passagem
