for (var i = 0; i < array_length(global.collectedItems); i++)
{
	if (global.collectedItems[i] == itemId) { instance_destroy(); break; }
}