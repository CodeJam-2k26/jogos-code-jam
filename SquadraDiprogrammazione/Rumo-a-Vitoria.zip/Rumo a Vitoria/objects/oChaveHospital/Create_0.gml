itemId = "chave_hospital";   // precisa ser único no jogo
nome = "";
falas = ["Uma chave. Deve abrir alguma porta do hospital."];
menuAberto = false;
dialogoAberto = false;

function AoFecharDialogo()
{
	var _cam = view_camera[0];
	var _x = camera_get_view_x(_cam) + camera_get_view_width(_cam) / 2 - 40;
	var _y = camera_get_view_y(_cam) + camera_get_view_height(_cam) / 2 - 20;

	var _options = [
		["Sim", MenuColetarItem, [id, "chave_hospital"], true],
		["Não", MenuCancel, -1, true]
	];
	Menu(_x, _y, _options, "Pegar a chave?", undefined, undefined, true);
}
