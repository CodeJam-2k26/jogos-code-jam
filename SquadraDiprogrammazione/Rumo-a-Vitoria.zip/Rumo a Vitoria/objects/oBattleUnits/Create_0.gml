sprite_index = sprites.idle
statusEffects = [];