// Inicia a cena na primeira visita assim que a transição de entrada terminar.
if (room == rm_hospital2 && !global.questyHospitalIntroducaoFeita
	&& !instance_exists(oDialogo) && !instance_exists(oTransicao))
{
	var _questyX = clamp(x + 28, 32, room_width - 32);
	var _questyY = clamp(y, 24, room_height - 24);
	var _questy = instance_create_depth(_questyX, _questyY, depth - 1, oNPC);
	with (_questy)
	{
		questyCompanion = true;
		seguindo = false;
		persistent = false;
		visible = true;
		sprite_index = sPolpoIdle;
		image_speed = 0;
		image_index = 0;
		nome = "Polpo";
		function AoFecharDialogo()
		{
			conversando = false;
			jaConversou = true;
			global.questyHospitalIntroducaoFeita = true;
			global.questyAcompanhando = true;
			seguindo = true;
			persistent = true;
			with (oPlayer) parado = false;
		}
	}
	parado = true;
	instance_create_depth(0, 0, -99999, oDialogo,
	{
		falas: [
			"Acordou Boto? Vambora.",
			"A gente perdeu um tempo bom aqui. Sorte que eu não me machuquei no acidente",
			"Enfim, vamos."
		],
		nome: "Polpo",
		dono: _questy
	});
}

if (parado || instance_exists(oTransicao) || instance_exists(oDialogo))
{
	image_speed = 0;
	exit;   // jogador parado durante cutscene e fade
}

if(!instance_exists(oMenu))
{
	//acabou de fechar o menu nesse frame? pula um frame antes de poder reabrir
	if (menuWasOpen)
	{
		menuWasOpen = false;
	}
	else
	{
		var _inputH = keyboard_check(vk_right) - keyboard_check(vk_left);
		var _inputV = keyboard_check(vk_down) - keyboard_check(vk_up);
		var _inputD = point_direction(0,0,_inputH,_inputV);
		var _inputM = min(1, point_distance(0,0,_inputH,_inputV));

		if (_inputM != 0)
		{
			direction = _inputD;	
			image_speed = 1;
		}
		else
		{
			image_speed = 0;
			animIndex = 0;
		}

		FourDirectionAnimate();

		MoveAndCollide(lengthdir_x(spdWalk*_inputM,_inputD), lengthdir_y(spdWalk*_inputM,_inputD));

		if (keyboard_check_pressed(vk_escape))
		{
			var _options = [
				["Salvar", MenuAskSave, -1, true],
				["Inventário", MenuOpenInventory, -1, true],
			];
		
			var _menuWidth = 96;
			var _menuHeight = 60;

			var _cam = view_camera[0];
			var _menuX = camera_get_view_x(_cam) + camera_get_view_width(_cam) - _menuWidth - 8;
			var _menuY = camera_get_view_y(_cam) + (camera_get_view_height(_cam) - _menuHeight) / 2;

			Menu(_menuX, _menuY, _options, -1, _menuWidth, _menuHeight, true);
		}
	}
}
else
{
	menuWasOpen = true;
}

