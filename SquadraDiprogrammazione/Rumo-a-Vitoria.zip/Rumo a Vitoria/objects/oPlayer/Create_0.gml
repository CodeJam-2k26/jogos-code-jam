spdWalk = 2.5;
animIndex = 0;
menuWasOpen = false


function FourDirectionAnimate() {
	//Update Sprite
	var _animLength = sprite_get_number(sprite_index) / 4;
	image_index = animIndex + (((direction div 90) mod 4) * _animLength);
	animIndex += sprite_get_speed(sprite_index) / 60;

	//If animation would loop on next game step
	if (animIndex >= _animLength)
	{
		animationEnd = true;	
		animIndex -= _animLength;
	}else animationEnd = false;
}

randomize()

if (variable_global_exists("justLoaded") && global.justLoaded)
{
	x = global.loadPlayerX;
	y = global.loadPlayerY;
	PosicaoLivre();
	global.justLoaded = false;
}
else if (variable_global_exists("spawnPorta") && global.spawnPorta != undefined)
{
	if (global.spawnPorta.sala == room)
	{
		x = global.spawnPorta.x;
		y = global.spawnPorta.y;
		PosicaoLivre();   // corrige se o ponto estiver fora da room ou dentro de colisão
	}
	global.spawnPorta = undefined;
}

// Ao iniciar um jogo novo, remove um companheiro persistente da sessão anterior.
if (!global.questyAcompanhando)
{
	with (oNPC)
	{
		if (variable_instance_exists(id, "questyCompanion") && questyCompanion) instance_destroy();
	}
}

// Ao carregar um save, recria Polpo caso o companheiro ainda não exista.
if (global.questyAcompanhando)
{
	var _existente = noone;
	for (var i = instance_number(oNPC) - 1; i >= 0; i--)
	{
		var _npc = instance_find(oNPC, i);
		if (!variable_instance_exists(_npc, "questyCompanion") || !_npc.questyCompanion) continue;
		if (_existente == noone) _existente = _npc;
		else instance_destroy(_npc);
	}
	if (_existente != noone)
	{
		with (_existente)
		{
			x = other.x;
			y = other.y;
			persistent = true;
			visible = true;
			sprite_index = sPolpoIdle;
			image_speed = 0;
			image_index = 0;
		}
	}
	else
	{
		var _questy = instance_create_depth(x, y, depth - 1, oNPC);
		with (_questy)
		{
			questyCompanion = true;
			seguindo = true;
			persistent = true;
			visible = true;
			sprite_index = sPolpoIdle;
			image_speed = 0;
			image_index = 0;
		}
	}
}

global.entradaSala = { sala: room, x: x, y: y };

parado = false;   // true = jogador travado (cutscenes)
