if (!instance_exists(oPlayer) || instance_exists(oMenu) || instance_exists(oBattle)
	|| instance_exists(oDialogo) || instance_exists(oTransicao)) exit;

if (!oPlayer.parado && distance_to_object(oPlayer) <= 12 && keyboard_check_pressed(ord("Z")))
{
	instance_create_depth(0, 0, -99999, oDialogo, {
		falas: [
			"Máquinas de venda.",
			"Só porcaria.",
			"Por que isso tá num hospital mesmo?"
		],
		nome: ""
	});
}
