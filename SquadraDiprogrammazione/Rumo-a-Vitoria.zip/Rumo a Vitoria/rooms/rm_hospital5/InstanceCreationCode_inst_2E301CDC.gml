nome = "Paciente"
falas=
[
	"Bom?",
	"To doente.",
	"Meu nome é paciente.",
	"Já entendeu né? Então picamula."
]

falasRepetidas = 
[
	"...",
	"Faz favor?"
]