nome = "Paciente 4"

falas = 
[
	"Quero que você faça um favor pra mim...",
	"Mete o pé."
]

falasRepetidas =
[
	"M-E-T-E-O-P-É."
]