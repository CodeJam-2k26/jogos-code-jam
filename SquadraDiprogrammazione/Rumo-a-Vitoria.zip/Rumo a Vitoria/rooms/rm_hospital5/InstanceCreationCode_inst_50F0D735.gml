nome = "Paciente 5"

falas = 
[
	"Não entendo os outros, parece que somente eu tenho noção de alguma coisa.",
	"Tipo, aquelas enfermeiras são bizarras..",
	"De lindas."
]

falasRepetidas = 
[
	"Não concorda?"
]