nome = "Paciente 3"
falas = 
[
	"Fala com o caba da sala do lado.",
	"Concordo com tudim que ele disse.."
]
falasRepetidas = 
[
	"Continuo concordando com o caba da sala do lado."
]