conteudo =
[
	{ itemKey: "potion", quantidade: 2 },
]