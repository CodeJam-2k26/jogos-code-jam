nome = "paciente"
falas= [
	"O que é? Tô cadim doente, consegue ver não?"
]
falasRepetidas = [
	"Você pode por favor me deixar sozim?"
]