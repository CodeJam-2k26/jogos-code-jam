falas = 
[
	"Aparelhos... De Hospital.",
	"Eu tenho que me apressar."
]
falasRepetidas = falas