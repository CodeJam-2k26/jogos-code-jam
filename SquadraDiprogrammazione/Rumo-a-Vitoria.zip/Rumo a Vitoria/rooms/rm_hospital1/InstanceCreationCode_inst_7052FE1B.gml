falas = 
[
	"É um dia lindo lá fora. Pássaros cantando, flores desabrochando... ",
	"Em dias como esse...",
	"Eu deveria estar com Vitória."
]

falasRepetidas = 
[
	"É... Está um dia lindo lá fora."
]