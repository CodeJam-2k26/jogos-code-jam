itemNecessario = "chave_hospital";
falasTrancada = ["Preciso achar um jeito de abrir isso."]