falas = 
[
	"Mão de Cabelo",
	"PERIGO, mantenha distância!",
	"Conhecido por ter certos interesses por urina...",
	"Você não vai querer ficar perto dele, vai por mim"
]

falasRepetidas = falas