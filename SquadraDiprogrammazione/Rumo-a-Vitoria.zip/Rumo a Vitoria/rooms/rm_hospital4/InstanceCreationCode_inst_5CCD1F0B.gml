falas =
[
	"A Pisadeira",
	"PERIGO, mantenha distância!",
	"Conhecida por assombrar comilões durante a noite. Pode ocasionar em possível debilitação respiratória permanente."
]

falasRepetidas = falas