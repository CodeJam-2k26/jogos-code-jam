falas = 
[
	"É uma bancada, me estranha estar vazia. Tem alguma coisa de estranha com esse hospital.",
	"Tem algumas folhas em cima do balcão, elas dizem.",
	"Paciente Boto: Estado CRÍTICO, DEVE ficar em repouso durante algumas semanas.",
	"Ninguém vai me impedir."
]
falasRepetidas = falas