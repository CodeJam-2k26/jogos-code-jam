itemNecessario = "muleta"
falasTrancada = ["Sinto que estou esquecendo algo muito importante."]