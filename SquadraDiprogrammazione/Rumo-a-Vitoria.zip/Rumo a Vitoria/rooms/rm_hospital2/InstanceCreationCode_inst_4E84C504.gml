conteudo = 
[
	{ itemKey: "potion", quantidade: 1 },
]