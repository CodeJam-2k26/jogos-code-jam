speed = 10
direction = obj_revolver.image_angle
depth = (obj_revolver.depth) - 1
colidiu = false;
tempo = 0
tempo_max = 60
image_angle = point_direction(x, y, mouse_x, mouse_y)
