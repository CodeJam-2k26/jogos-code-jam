if(global.dialogo or global.pause){ 
	speed = 0
	exit;
}
else{
	speed = 10
}

tempo++
if(tempo >= tempo_max) colidiu = true

if (colidiu) 
{	
	speed = 0;
	sprite_index = spr_bullet_destroy;
	//Sumindo após acabar a animação
	if(image_speed <= 0)
	{
		image_alpha -= 0.10;
	}
	
	//Se sumiu totalmente, se destrói
	if(image_alpha <= 0)
	{
		instance_destroy();
	}
	exit;
}