//Mirando o player
target = obj_player;