if(global.dialogo or global.pause) exit;

//O código só irá rodar se o objeto "player" existir
//Se ele não existir, ele sairá do evento
if(!instance_exists(target) or obj_player.state == player_states.morto) exit;

//Fazendo a camera apontar para o cursor
//Armazenando o x e y do alvo
var _x1 = target.x;
var _y1 = target.y;

//Direção do alvo até o mouse
var _dir = point_direction(_x1, _y1, mouse_x, mouse_y);

//Distância do alvo para o mouse
var _dist = point_distance(_x1, _y1, mouse_x, mouse_y);

//Decidindo que a distancia que a camera se move pra longe do player tem um certo limite
_dist = clamp(_dist, -50, 50)

//x2 = posição do player + distancia até o mouse
var _x2 = _x1 + lengthdir_x(_dist, _dir);

//y2 = posição do player + distancia até o mouse
var _y2 = _y1 + lengthdir_y(_dist, _dir);

//Posicionando a camera + efeitos pra suavização do movimento
x = lerp(x, _x2, 0.1);
y = lerp(y, _y2, 0.1);