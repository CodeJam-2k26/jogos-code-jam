opcao = 0; 

if ( keyboard_check_direct( vk_down ) )
{
	
	opcao++;
	
	if ( opcao > 1 )
	{
		opcao = 0;
	}

}

if ( keyboard_check_direct( vk_up ) )
{
	
	opcao--;
	
	if ( opcao < 0 )
	{
		opcao = 1;
	}

}

