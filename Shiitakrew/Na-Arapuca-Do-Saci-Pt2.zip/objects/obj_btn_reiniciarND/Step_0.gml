var _cor = c_black;
