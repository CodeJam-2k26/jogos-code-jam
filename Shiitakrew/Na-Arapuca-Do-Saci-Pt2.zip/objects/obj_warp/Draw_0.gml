draw_self()
font_enable_effects(fnt_in_game, true, 
	{
		outlineEnable: true,
		outlineDistance: 1,
		outlineColour: c_black
	}
)
draw_set_font(fnt_in_game);
draw_set_halign(fa_center);
draw_set_colour(c_black)
draw_set_alpha(0.5)
draw_text(x + 1, y + 1 + dsin(current_time * 0.1) * 4, warp_text)
draw_set_colour(c_white)
draw_set_alpha(1)
draw_text(x, y + dsin(current_time * 0.1) * 4, warp_text)
draw_set_halign(fa_left);
