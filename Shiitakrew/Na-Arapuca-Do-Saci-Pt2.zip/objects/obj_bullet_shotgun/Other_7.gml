if(sprite_index == spr_bullet_destroy)
{
	image_speed = 0;
	image_index = 3;
}