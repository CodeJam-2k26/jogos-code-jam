speed = 10
depth = (obj_gun_shotgun.depth) - 1
colidiu = false;
tempo = 0
tempo_max = 20
image_angle = point_direction(x, y, mouse_x, mouse_y)
