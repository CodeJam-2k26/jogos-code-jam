draw_set_font(fnt_result_screen)
draw_set_color(c_lime)

if (!start)
{
	draw_set_halign( fa_center)
	draw_text( display_get_gui_width() / 2, display_get_gui_height() / 2, string(contagem_regressiva) + "!")
}
else if ( contagem_regressiva <= 0 && total_cactos == 0 )
{
	draw_set_halign( fa_center )
	draw_text( display_get_gui_width() / 2, display_get_gui_height() / 2, "COMEÇOU!!!")
}