if(total_cactos == limite_cactos and !instance_exists(obj_cactus)){
	jogo_acabou = true
	if(obj_acertos_nordeste.estado = "perdeu" and tocar_som){ 
		audio_play_sound(snd_glass, 10, false)
		tocar_som = false
	}
	if(obj_acertos_nordeste.estado = "ganhou" and tocar_som){ 
		audio_play_sound(snd_intro, 10, false)
		tocar_som = false
	}
}