contagem_regressiva--

if ( contagem_regressiva > 0 )
	{
		alarm[1] = room_speed;
	}
	else
	{
		start = true;
		alarm[0] = room_speed * 0.5;
	}