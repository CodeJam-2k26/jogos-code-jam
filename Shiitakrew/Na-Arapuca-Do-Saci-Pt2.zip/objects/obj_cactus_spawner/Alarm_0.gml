if (start)
{
	if ( total_cactos < limite_cactos )
	{
		var pos_x = [210, 460, 680, 900, 1100 ];
		var pos_y = [ 610, 520, 610, 520, 610 ];

		var rand = irandom(4);
	
		if ( instance_position(pos_x[rand], pos_y[rand], obj_cactus) == noone )
		{
		
		instance_create_layer( pos_x[rand], pos_y[rand], "Instances", obj_cactus );
	
		total_cactos++
	
		}
	
	}
}

alarm[0] = room_speed * 0.5;
