total_cactos = 0;
limite_cactos = 15;

jogo_acabou = false
tocar_som = true

global.acertos_cactos = 0;
global.perdas_cactos = 0;

contagem_regressiva = 3;
start = false;

alarm[1] = room_speed;