if(other.colidiu == false and state != enemy_states.morto)
{
	if(state == enemy_states.idle or state == enemy_states.walk){
		target = obj_player
		state = enemy_states.follow
	}
	tiro_dir = other.direction
	vel_h = lengthdir_x(4, tiro_dir)
	vel_v = lengthdir_y(4, tiro_dir)
	leva_dano(1)
	other.colidiu = true
	obj_boss_saci.state = saci_states.stun
	obj_boss_saci.fakers_spawn = 0
	obj_boss_saci.x = x
	obj_boss_saci.y = y
	audio_play_sound(snd_wind, 10, false)
	instance_destroy()
	instance_destroy(obj_saci_faker_0)
}