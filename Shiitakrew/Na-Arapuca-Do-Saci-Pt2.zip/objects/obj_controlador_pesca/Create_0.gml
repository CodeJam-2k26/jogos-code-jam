contagem_regressiva = 3;
mostrar_comecou = false;
global.start_pesca = false;

alarm[0] = room_speed;