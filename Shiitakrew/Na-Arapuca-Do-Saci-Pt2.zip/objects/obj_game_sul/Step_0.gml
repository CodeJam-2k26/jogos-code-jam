if ( global.start_sul = true ) {
	
	if ( estado == "jogando" ) {
	
	    marcador_x += marcador_vel * marcador_dir;

	    if ( marcador_x >= barra_x + barra_larg ) 
		{
	        marcadaor_x = barra_x + barra_larg;
	        marcador_dir = -1;
	    }
	    if ( marcador_x <= barra_x ) 
		{
	        marcador_x = barra_x;
	        marcador_dir = 1;
	    }

	    if ( keyboard_check_pressed(vk_space) ) 
		{
	        if (marcador_x >= alvo_x && marcador_x <= alvo_x + alvo_larg)
			{
				audio_play_sound(snd_pong, 10, false)
				pontos++
				alvo_larg = alvo_larg - 20;
				marcador_vel = marcador_vel + 5;
	        }
			else
			{
				audio_play_sound(snd_player_dmg, 10, false)
				numero_tentativas--
				alvo_larg = alvo_larg - 20;
	        }
		
			alvo_x = barra_x + irandom_range(0, barra_larg - alvo_larg);
		
		}
	
		if ( pontos >= 3 && numero_tentativas >= 0 ) 
		{
			audio_play_sound(snd_intro, 10, false)
			estado = "ganhou"
		}
		else if ( numero_tentativas == 0 && pontos < 3 )
		{
			audio_play_sound(snd_glass, 10, false)
			estado = "perdeu"
		}
	}

		else
	{
		
		   if (keyboard_check_pressed(vk_down))
		{
		    cont++;
		    if (cont > 2) cont = 2;
		}

		if (keyboard_check_pressed(vk_up))
		{
		    cont--;
		    if (cont < 0) cont = 0;
		}

		if (keyboard_check_pressed(vk_enter))
		{
		    if (cont == 0) room_restart();
		    if (cont == 1) ScriptFade(Room_cont_pong, 30, c_black);   //TROCAR ROOM
		    if (cont == 2) ScriptFade(RoomMenu, 30, c_black);       //TROCAR ROOM
		}
	
	}
	
}