font_enable_effects(fnt_result_screen, true, 
	{
		outlineEnable: true,
		outlineDistance: 2,
		outlineColour: c_black
	}
)

draw_set_font(fnt_result_screen)

draw_set_color(c_gray);
draw_rectangle(400, 400, 1000, 440, false);

draw_set_color(c_lime);
draw_rectangle(alvo_x, 400, alvo_x + alvo_larg, 440, false);
draw_sprite_ext(spr_boi, image_index, alvo_x, 400, 3, 3, image_angle, image_blend, image_alpha)

draw_set_color(c_white);
draw_rectangle(marcador_x - 3, 390, marcador_x + 3, 450, false);

draw_set_halign(fa_center);

draw_text(130, 30, "PONTOS:" + string(pontos));
draw_text(130, 60, "TENTATIVAS:" + string(numero_tentativas));

if (estado == "jogando")
{
    draw_text(700, 140, "Aperte espaço para laçar");
}

else
{
	
    if (estado == "ganhou") draw_text(display_get_gui_width() / 2, 340, "GANHOU!");
    if (estado == "perdeu") draw_text(display_get_gui_width() / 2, 340, "PERDEU!");

    for (var i = 0; i < 3; i++)
    {
        if (i == cont) draw_set_color(c_yellow);
        else draw_set_color(c_white);

        draw_text(display_get_gui_width() / 2, 500 + i * 40, opcoes[i]);
    }
    draw_set_color(c_white);
}

draw_set_halign(fa_left);