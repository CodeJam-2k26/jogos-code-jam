
barra_larg = 600;
barra_alt = 40;
barra_x = room_width / 2 - barra_larg / 2;
barra_y = room_height / 2;

alvo_larg = 100;
alvo_x = barra_x + irandom_range(0, barra_larg - alvo_larg);


marcador_x = barra_x;
marcador_vel = 6;
marcador_dir = 1; 

estado = "jogando";
pontos = 0;
numero_tentativas = 3;

cont = 0;
opcoes = ["Jogar Novamente", "Continuar", "Voltar para o Menu"];
