font_enable_effects(fnt_result_screen, true, 
	{
		outlineEnable: true,
		outlineDistance: 2,
		outlineColour: c_black
	}
)
draw_set_font(fnt_result_screen)
draw_set_color(c_white)
draw_set_halign( fa_left )

draw_text( 30, 30, "Acertos: " + string(global.acertos_cactos))

draw_set_color(c_red)

draw_text( 30, 60, "Perdas: " + string(global.perdas_cactos))

draw_set_color(c_ltgrey)

if ( obj_cactus_spawner.total_cactos == 15 && instance_number(obj_cactus) == 0 )
{
	draw_set_halign( fa_center );
	
	if ( global.acertos_cactos >= 10 && estado == "ganhou" )
	{	
		
			draw_text(display_get_gui_width() / 2, display_get_gui_height() / 2, "GANHOU!");
		 
			for (var i = 0; i < 3; i++)
	{
	    if (i == cont) draw_set_color(c_yellow);
	    else draw_set_color(c_white);

	    draw_text(display_get_gui_width() / 2, 500 + i * 40, opcoes[i]);
	}

	}
	
	else if ( estado == "perdeu")
	{	
		draw_text(display_get_gui_width() / 2, display_get_gui_height() / 2, "PERDEU!");
		 
		for (var i = 0; i < 3; i++)
	{
	    if (i == cont) draw_set_color(c_yellow);
	    else draw_set_color(c_white);

	    draw_text(display_get_gui_width() / 2, 500 + i * 40, opcoes[i]);
		
	}
	
	}
	draw_set_halign( fa_left )
}