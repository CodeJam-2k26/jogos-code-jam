if ( global.acertos_cactos >= 10 )
{
	estado = "ganhou"
	
	 if (keyboard_check_pressed(vk_down))
		{
		    cont++;
		    if (cont > 2) cont = 2;
		}

		if (keyboard_check_pressed(vk_up))
		{
		    cont--;
		    if (cont < 0) cont = 0;
		}

		if (keyboard_check_pressed(vk_enter))
		{
		    if (cont == 0) room_restart();
		    if (cont == 1) ScriptFade(Room_cont_sebo, 30, c_black);   //TROCAR ROOM
		    if (cont == 2) ScriptFade(RoomMenu, 30, c_black);   
		}
		
}
else
{
	estado = "perdeu"
	
	 if (keyboard_check_pressed(vk_down))
		{
		    cont++;
		    if (cont > 2) cont = 2;
		}

		if (keyboard_check_pressed(vk_up))
		{
		    cont--;
		    if (cont < 0) cont = 0;
		}

		if (keyboard_check_pressed(vk_enter))
		{
		    if (cont == 0) room_restart();
		    if (cont == 1) ScriptFade(Room_cont_sebo, 30, c_black);   //TROCAR ROOM
		    if (cont == 2) ScriptFade(RoomMenu, 30, c_black);      
		}
		
}

