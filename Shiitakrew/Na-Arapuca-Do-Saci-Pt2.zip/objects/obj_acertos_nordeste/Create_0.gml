cont = 0;
opcoes = ["Jogar Novamente", "Continuar", "Voltar para o Menu"];

estado = "jogando"