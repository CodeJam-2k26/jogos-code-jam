event_inherited()

if(state == enemy_states.attack_prep){
	drawing_warning()
}
