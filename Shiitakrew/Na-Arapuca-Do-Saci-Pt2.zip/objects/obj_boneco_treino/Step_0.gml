event_inherited()

switch (state)
{
	//Esse código foi adaptado do 'obj_enemy'
	case enemy_states.idle:
		if(sprite_index != spr_boneco_treino){
			sprite_index = spr_boneco_treino
		}
		vel_h = 0
		vel_v = 0
	break;
}