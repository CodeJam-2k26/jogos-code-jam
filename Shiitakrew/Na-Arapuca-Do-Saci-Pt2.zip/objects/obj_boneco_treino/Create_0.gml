event_inherited();

vida_max = 3
vida_atual = vida_max

sprite_morrendo = spr_enemy_defeat
//Contagem de tempo


//Saturação de cor do objeto, utilizada na indicação do estado de preparo do ataque
sat = 0

//Ataque
attack_duration = 1
attack_time = attack_duration
//Definindo estados

state = enemy_states.idle

//Campo de visão
view = function(_width, _height, _xscale){
	var _x1, _x2, _y1, _y2
	
	_x1 = x + sign(image_xscale) * (-100)
	_y1 = y + _height / 2 - sprite_height / 2
	
	_x2 = _x1 + _width * image_xscale
	_y2 = _y1 - _height
	
	draw_rectangle(_x1, _y1, _x2, _y2, false)
	
	var _target = collision_rectangle(_x1, _y1, _x2, _y2, obj_player, 0, 1)
	if(obj_player.state != player_states.morto){
	return _target
	}
}


//Desenhando o sinal de perigo
larg_sinal_i = image_xscale * 0.5
alt_sinal_i = image_yscale * 0.5
larg_sinal_f = image_xscale * 0.8
alt_sinal_f = image_yscale * 0.8
 
alpha_sinal_i = 0
alpha_sinal_f = 1
  
altura_sinal_i = 0
altura_sinal_f = -10
 
larg_sinal = larg_sinal_i
alt_sinal = alt_sinal_i

alpha_sinal = alpha_sinal_i

altura_sinal = altura_sinal_i

drawing_warning = function(){
	draw_sprite_ext(spr_warning, image_index, x, bbox_top + altura_sinal, larg_sinal, alt_sinal, image_angle, image_blend, alpha_sinal);
}
