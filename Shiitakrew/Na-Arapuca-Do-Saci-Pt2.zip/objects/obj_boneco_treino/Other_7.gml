if(sprite_index == spr_enemy_defeat){
	morrendo = false
	morto = true
}

if(sprite_index == spr_enemy_destroyed){
	morto = false
	image_speed = 0
	image_index = 6
}