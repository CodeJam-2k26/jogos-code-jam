if(other.colidiu == false and state != enemy_states.morto)
{
	leva_dano(0)
	other.colidiu = true
}