if (global.jogo_acabou == true) exit;
if ( global.start_pong ) {
	mover = keyboard_check(vk_down) - keyboard_check(vk_up);

	y = y + (mover * vel);

	if ( bbox_bottom > room_height ) y = room_height - ( sprite_height * 0.5 )
	if ( bbox_top < 0 ) y = 0 + ( sprite_height * 0.5 )

}
