image_xscale = 4
image_yscale = 4

vel = 10;

