if(obj_cactus_spawner.jogo_acabou) exit;

x = mouse_x;
cooldown++
if mouse_check_button_pressed(mb_left) and cooldown >= 20
{
	instance_create_depth( mouse_x,mouse_y, depth - 1, obj_tiro)
	cooldown = 0
}