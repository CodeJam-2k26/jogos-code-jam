contagem_regressiva--

if ( contagem_regressiva > 0 )
	{
		alarm[0] = room_speed;
	}
	else
	{
		global.start_sul = true;
		mostrar_comecou = true;
		alarm[1] = room_speed;
	}