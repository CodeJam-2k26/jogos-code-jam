contagem_regressiva = 3;
mostrar_comecou = false;
global.start_sul = false;

alarm[0] = room_speed;