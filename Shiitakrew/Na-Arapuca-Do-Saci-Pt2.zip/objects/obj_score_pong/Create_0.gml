global.vencedor_pong = "";
global.jogo_acabou = false;