draw_set_font(fnt_result_screen)
draw_set_halign(fa_center);
draw_set_colour(c_white)
draw_text(display_get_gui_width() * 0.25, 20, string(global.ponto_player));
draw_text(display_get_gui_width() * 0.75, 20, string(global.ponto_bot));
