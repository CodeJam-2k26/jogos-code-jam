if ( global.start_pesca = true ) {
	sprite_index = spr_chico_puxando

	if ( !jogo_acabou ){

	if (progresso_player >= 100)
	{
	    enchidas_player += 1;
	    progresso_player = 0;
	}

	if (progresso_npc >= 100)
	{
	    enchidas_npc += 1;
	    progresso_npc = 0;
	}

	if (enchidas_player >= 7)
	{
	    jogo_acabou = true;
		estado = "ganhou"
	}

	if (enchidas_npc >= 7)
	{
	    jogo_acabou = true;
		estado = "perdeu";
	}

		peixe_h += peixe_vel * peixe_dir;

		peixe_timer -= 1;

	if (peixe_timer <= 0)
	{
	    peixe_dir = choose(-1, 1);
	    peixe_timer = irandom_range(peixe_timer_min, peixe_timer_max);
	}


		if ( peixe_h <= area_topo )
		{
			peixe_h = area_topo;
			peixe_dir = 1;
		}

		if ( peixe_h >= area_fundo )
		{
			peixe_h = area_fundo;
			peixe_dir = -1;
		}

		if ( keyboard_check(vk_space))
		{
			anz_vel = -anz_vel_sub;
		}
		else
		{
			anz_vel += anz_vel_des * 0.1;
		}

		anz_y += anz_vel;

		if ( anz_y <= area_topo )
		{
		    anz_y = area_topo;
		    anz_vel = 0;
		}

		if ( anz_y >= area_fundo )
		{
		    anz_y = area_fundo;
		    anz_vel = 0;
		}

		var _distancia = abs( anz_y - peixe_h )
		var _validando = anz_tamanho / 2;

		if ( _distancia <= _validando )
		{
			progresso_player += progresso_sub;
		}
		else
		{
			progresso_player -= progresso_des;
		}

		progresso_player = clamp( progresso_player, 0, 100 );

		progresso_npc += progresso_npc_sub;
		progresso_npc = clamp( progresso_npc, 0, 100 );
	}
	
			else
	{
		
		   if (keyboard_check_pressed(vk_down))
		{
		    cont++;
		    if (cont > 2) cont = 2;
		}

		if (keyboard_check_pressed(vk_up))
		{
		    cont--;
		    if (cont < 0) cont = 0;
		}

		if (keyboard_check_pressed(vk_enter))
		{
		    if (cont == 0) room_restart();
		    if (cont == 1) ScriptFade(Room_cont_cacto, 30, c_black);   //TROCAR ROOM
		    if (cont == 2) ScriptFade(RoomMenu, 30, c_black);   
		}			

	
}
}

if (jogo_acabou == true) exit;