//Área de Pesca

area_topo = 250;
area_fundo = 500;

//Peixinho

peixe_h = 250;
peixe_vel = 1;
peixe_dir = 1;

peixe_timer_min = 60;
peixe_timer_max = 180;

peixe_timer = irandom_range(peixe_timer_min, peixe_timer_max);

//ANziol

anz_y = 250;
anz_vel_sub = 2;
anz_vel_des = 2;
anz_vel = 0;
anz_tamanho = 50;

// Progresso

progresso_player = 0;
progresso_npc = 0;

progresso_sub = 0.3;
progresso_des = 0.2;
progresso_npc_sub = 0.18;

enchidas_player = 0;
enchidas_npc = 0;

jogo_acabou = false;

estado = "jogando";
cont = 0;
opcoes = ["Jogar Novamente", "Continuar", "Voltar para o Menu"];
