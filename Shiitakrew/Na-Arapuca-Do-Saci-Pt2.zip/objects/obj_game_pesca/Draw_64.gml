font_enable_effects(fnt_result_screen, true, 
	{
		outlineEnable: true,
		outlineDistance: 2,
		outlineColour: c_black
	}
)

draw_set_font(fnt_result_screen)
draw_sprite(spr_fish, 0, display_get_gui_width() / 2, peixe_h);
draw_sprite(spr_anzol, 0, display_get_gui_width() / 2, anz_y);


draw_set_color(c_lime);
draw_rectangle( (display_get_gui_width() / 2) - 120, area_fundo - progresso_player * 3, (display_get_gui_width() / 2) - 100, area_fundo, false);


draw_set_color(c_red);
draw_rectangle( (display_get_gui_width() / 2) + 100, area_fundo - progresso_npc * 3, (display_get_gui_width() / 2) + 120, area_fundo, false);

draw_set_color(c_white);
draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_text(20, 20, "JOGADOR: " + string(enchidas_player));


draw_text(display_get_gui_width() - 290, 20, "ADVERSÁRIO: " + string(enchidas_npc));

draw_set_halign(fa_center)

if (estado == "jogando")
{
    draw_text(display_get_gui_width() / 2, display_get_gui_height() / 2 + 300, "Segure espaço para subir!");
}

else
{
	
    if (estado == "ganhou") draw_text(display_get_gui_width() / 2, display_get_gui_height() / 2, "GANHOU!");
    if (estado == "perdeu") draw_text(display_get_gui_width() / 2, display_get_gui_height() / 2, "PERDEU!");

    for (var i = 0; i < 3; i++)
    {
        if (i == cont) draw_set_color(c_yellow);
        else draw_set_color(c_white);

        draw_text( display_get_gui_width() / 2 , 500 + i * 30, opcoes[i]);
    }
    draw_set_color(c_white);
}


draw_set_halign(fa_left);
draw_set_valign(fa_top);