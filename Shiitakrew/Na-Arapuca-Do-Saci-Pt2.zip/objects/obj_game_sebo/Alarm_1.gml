estado = "perdeu"
audio_play_sound(snd_glass, 10, false)