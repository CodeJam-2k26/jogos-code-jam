estado = "jogando"
alarm[1] = room_speed * 20;