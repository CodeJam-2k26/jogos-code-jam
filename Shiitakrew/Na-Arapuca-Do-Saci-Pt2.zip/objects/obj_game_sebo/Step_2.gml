global.h_chico = altura_atual;

draw_sprite(spr_player_sebo, 1, room_width / 2, altura_atual )
show_debug_message("Create: " + string(sequencia))


if ( estado == "jogando" && altura_atual >= altura_total )
{
	estado = "venceu";
	audio_play_sound(snd_intro, 10, false)
	alarm[1] = -1;
}
