altura_total = 3600;
altura_atual = 0;
altura_perda = 100;
altura_ganho = 100;

estado = "cutscene"
alarm[0] = room_speed * 5;

player_MNP = instance_create_layer( 680, 4900, "Instances", obj_player_MNP )

global.h_chico = 0;

//sequencia = [ vk_down, vk_up, vk_left, vk_right ]
sequencia = [ 0, 1, 2, 3 ]
teclas = [ vk_down, vk_up, vk_left, vk_right ]
indice = 0

function gerar_seq(_array)
{
	array_sort( _array, function( _a, _b )
	{
		return irandom_range( -1, 1 );
	})
	
	return _array;
}

function desenhar_setas(_seta)
{
	var _sprite
	
	switch (_seta)
	{
		case vk_up: _sprite = spr_seta_up	break
		case vk_down: _sprite = spr_seta_down	break
		case vk_right: _sprite = spr_seta_right	break
		case vk_left: _sprite = spr_seta_left	break
	}
	
	 draw_sprite( _sprite, 0, 500, 500 );
	
}

sequencia = gerar_seq(sequencia)

show_debug_message("Create: " + string(sequencia))

cont = 0;
opcoes = ["Jogar Novamente", "Continuar", "Voltar para o Menu"];










