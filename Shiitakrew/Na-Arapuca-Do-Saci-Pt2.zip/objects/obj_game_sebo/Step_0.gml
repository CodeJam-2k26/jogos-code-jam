if ( global.start_norte )
{
	
	if ( estado == "jogando" )
	{
		
	if ( altura_atual < 0 ) altura_atual = 0;

	seta_certa = teclas[ sequencia[indice]]

	var tecla_press = keyboard_check_pressed(vk_down)
					|| keyboard_check_pressed(vk_up)
					|| keyboard_check_pressed(vk_left)
					|| keyboard_check_pressed(vk_right)

	if ( tecla_press )
	{
		if ( keyboard_check_pressed(seta_certa))
		{
			altura_atual += altura_ganho;
			indice++
			audio_play_sound(snd_dash, 10, false)
		}
	
		else
		{
			altura_atual -= altura_perda;
			audio_play_sound(snd_player_dmg, 10, false)
			gerar_seq(sequencia)
		}
	
		if (indice >= array_length(sequencia))
		{
			indice = 0;
			gerar_seq(sequencia);
		}
	
	}
}
	
	else if ( estado == "venceu" || estado == "perdeu" )
	{
		
		   if (keyboard_check_pressed(vk_down))
		{
		    cont++;
		    if (cont > 2) cont = 2;
		}

		if (keyboard_check_pressed(vk_up))
		{
		    cont--;
		    if (cont < 0) cont = 0;
		}

		if (keyboard_check_pressed(vk_enter))
		{
		    if (cont == 0) room_restart();
		    if (cont == 1) ScriptFade(Room_saci_final, 30, c_black);   //TROCAR ROOM
		    if (cont == 2) ScriptFade(RoomMenu, 30, c_black);       //TROCAR ROOM
		}
	
	}

	player_MNP.y = 4900 - altura_atual
	if( estado == "venceu" || estado == "perdeu" ) exit;
	
}


