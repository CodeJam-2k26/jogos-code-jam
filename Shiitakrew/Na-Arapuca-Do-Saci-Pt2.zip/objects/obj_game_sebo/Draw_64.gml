font_enable_effects(fnt_result_screen, true, 
	{
		outlineEnable: true,
		outlineDistance: 2,
		outlineColour: c_black
	}
)

draw_set_color(c_white);
draw_set_font(fnt_result_screen)
draw_text(250, 20, "Altura Necessaria: " + string(altura_total));
draw_text(250, 80, "Altura Subida: " + string(altura_atual));

//draw_sprite( spr_player, 1, 680, 640 - altura_atual );

if( estado == "cutscene" )
{
	
}

else if ( estado == "jogando" )
{
	desenhar_setas(seta_certa)
	
	var _segundos = ceil( alarm[1] / room_speed );
	draw_set_font(fnt_result_screen)
	draw_text( 1200, 20, string(_segundos));
}

draw_set_halign(fa_center)

if ( estado == "venceu" )
{
	
	 draw_text(display_get_gui_width() / 2, 340, "GANHOU!")
	 
	 
    for (var i = 0; i < 3; i++)
    {
        if (i == cont) draw_set_color(c_yellow);
        else draw_set_color(c_white);

        draw_text(display_get_gui_width() / 2, 500 + i * 40, opcoes[i]);
    }
    draw_set_color(c_white);
	
}

if (estado == "perdeu")
{
	
	 draw_text(display_get_gui_width() / 2, 340, "PERDEU!")
	
    for (var i = 0; i < 3; i++)
    {
        if (i == cont) draw_set_color(c_yellow);
        else draw_set_color(c_white);

        draw_text(display_get_gui_width() / 2, 500 + i * 40, opcoes[i]);
    }
    draw_set_color(c_white);
	
}
