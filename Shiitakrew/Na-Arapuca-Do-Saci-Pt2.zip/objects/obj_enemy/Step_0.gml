event_inherited()

if(sign(vel_h) != 0 and !morrendo and !morto)
		{
			image_xscale = sign(vel_h)
		}

switch (state)
{
	case enemy_states.idle:
		if(sprite_index != spr_enemy_idle){
			sprite_index = spr_enemy_idle
		}
		vel_h = 0
		vel_v = 0
		
		image_blend = c_white
		target = view(300, sprite_height * 2.5, image_xscale)
		move_dir = choose(0, 45, 90, 135, 180, 225, 270, 315)
		
		change_state([enemy_states.walk, enemy_states.idle])
		if(target){
			state = enemy_states.follow
		}
		
	break;
		
		case enemy_states.walk:
		if(sprite_index != spr_enemy_run){
			sprite_index = spr_enemy_run
		}
		if(sign(vel_h) != 0)
		{
			image_xscale = sign(vel_h)
		}

		vel = default_vel
		vel_h = lengthdir_x(vel, move_dir)
		vel_v = lengthdir_y(vel, move_dir)
		target = view(300, sprite_height * 2.5, image_xscale)
		change_state([enemy_states.idle, enemy_states.walk])
		if(target){
			state = enemy_states.follow
		}
		
	break;
	
	case enemy_states.follow:
		if(sprite_index != spr_enemy_run){
			sprite_index = spr_enemy_run
		}
		vel = 3
		if(instance_exists(target))
		{
			var _dir = point_direction(x, y, target.x, target.y)
			vel_h = lengthdir_x(vel, _dir)
			vel_v = lengthdir_y(vel, _dir)
			
			var _dist = point_distance(x, y, target.x, target.y)
			
			if(_dist < 300/2)
			{
				state = enemy_states.attack_prep
				audio_play_sound(snd_enemy_attack_prep, 10, false)
			}
			
			if(_dist > 200*2)
			{
				target = noone
			}
		}
		else
		{
			change_state([enemy_states.idle, enemy_states.walk])
		}
		
		
	break;
	
	case enemy_states.attack_prep:
	if(sprite_index != spr_enemy_idle){
			sprite_index = spr_enemy_idle
		}
	if(sign(vel_h) != 0) image_xscale = sign(target.x - x)
		vel_h = 0
		vel_v = 0
		if(sat < 1)
	{
		sat += (delta_time / 1000000)
	}
	larg_sinal = lerp(larg_sinal, larg_sinal_f, 0.1)
	alt_sinal = lerp(alt_sinal, alt_sinal_f, 0.1)
	alpha_sinal = lerp(alpha_sinal, alpha_sinal_f, 0.2)
	altura_sinal = lerp(altura_sinal, altura_sinal_f, 0.1)
	image_blend = make_color_hsv(45, sat * 255, 255)
	
	if(sat >= 1){
		sat = 0
		target_dir = point_direction(x, y, target.x, target.y)
		state = enemy_states.attack
		audio_play_sound(snd_enemy_dash, 10, false)
		alt_sinal = alt_sinal_i
		larg_sinal = larg_sinal_i
		alpha_sinal = alpha_sinal_i
		altura_sinal = altura_sinal_i
	}
	break;
	
	case enemy_states.attack:
		if(sprite_index != spr_enemy_run){
			sprite_index = spr_enemy_run
		}
		attack_time -= delta_time / 1000000
		vel = 5
		vel_h = lengthdir_x(vel, target_dir)
		vel_v = lengthdir_y(vel, target_dir)
		
		image_blend = c_red
		if(attack_time <= 0){
			state = enemy_states.idle
			attack_time = attack_duration
		}
	break;
	
	case enemy_states.morto:
		image_blend = c_white
		if(morrendo and sprite_index != spr_enemy_defeat){
			sprite_index = spr_enemy_defeat
		}
		if(morto and sprite_index != spr_enemy_destroyed){
			sprite_index = spr_enemy_destroyed
		}
		vel_h = 0
		vel_v = 0
		//Sumindo após acabar a animação
		if(image_speed <= 0)
		{	
			image_alpha -= 0.02
		}
	
		//Se sumiu totalmente, se destrói
		if(image_alpha <= 0)
		{
			instance_destroy();
			exit;
		}
		
	break;
}