tempo_start_anim = 30
image_speed = 0