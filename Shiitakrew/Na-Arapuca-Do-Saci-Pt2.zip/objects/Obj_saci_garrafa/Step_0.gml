tempo_start_anim--
if(tempo_start_anim <= 0){
	image_speed = 1
	if(image_index == 42){
		image_speed = 0
		exit;
	}
}