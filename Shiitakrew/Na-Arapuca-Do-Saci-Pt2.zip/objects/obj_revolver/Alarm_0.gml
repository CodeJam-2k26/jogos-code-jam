//Resetando a munição
ammo = max_ammo
sprite_index = spr_revolver