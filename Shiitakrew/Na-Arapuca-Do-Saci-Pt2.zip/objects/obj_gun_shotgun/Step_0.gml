if(global.dialogo or global.pause) exit;
if (image_xscale < 0.7) image_xscale += 0.1

//X e Y do player
var _x_target = target.x - 10
var _y_target = (target.y) - 15
//Checando o clique do botão esquerdo do mouse
var _click_left = mouse_check_button_pressed(mb_left)

//Fazendo o revólver seguir o ponteiro do mouse, e inverter a imagem quando for necessário
if(mouse_x - x != 0){
image_yscale = sign(mouse_x - x) * 0.7
}
image_angle = point_direction(_x_target, _y_target, mouse_x, mouse_y)
depth = (obj_player.depth) - 10

//Fazendo o revólver seguir o player
x = _x_target
y = _y_target





if(ammo == 0 and alarm[0] = -1 or keyboard_check_pressed(ord("E")) and alarm[0] == -1)
	{
		sprite_index = spr_shotgun_reload
		audio_play_sound(snd_gun_reload, 10, false)
		alarm[0] = current_speed * 1.8;
	}
	
if(shoot_time < 50){
	shoot_time++
}
else{
	can_shoot = true
}

//Atirando com o revólver
if ( global.dialogo == true ) exit;
if(_click_left)
{
	if(ammo > 0 and can_shoot == true and alarm[0] == -1){
	if(can_shoot){
		image_xscale = 0.4
		can_shoot = false
		shoot_time = 0
	//Saber a distância da origem da sprite até onde o tiro deve sair
	var _dist_x = 18
	var _dist_y = -4
	var _dist = point_distance(0, 0, _dist_x, _dist_y)
	
	for(var i = 0; i < 5; i++){
		//Saber a direção da origem da sprite até onde o tiro deve sair
		var _dir = point_direction(0, 0, _dist_x, _dist_y)
		var _dir_bullet = -20 + (i * 10)
		//Posição para a criação dos tiros
		var _x_bullet = lengthdir_x(_dist, image_angle + _dir + _dir_bullet)
		var _y_bullet = lengthdir_y(_dist, image_angle + _dir + _dir_bullet)
	
		//Criando o tiro
		var _bullet = instance_create_layer(x + _x_bullet, y + _y_bullet, "tiros", obj_bullet_shotgun) 
		_bullet.direction = image_angle + _dir_bullet
		audio_play_sound(snd_gunshot, 10, false)
	}
	ammo--
	}
	
	}
}