image_xscale = 0.7
//Mirando o player (para movimentação)
target = obj_player;

//Contagem de tempo
current_speed = game_get_speed(gamespeed_fps);

//Pode atirar
shoot_time = 0
can_shoot = true;

//Contagem de munição
max_ammo = 3



