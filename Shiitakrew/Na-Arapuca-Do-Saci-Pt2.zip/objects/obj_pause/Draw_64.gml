font_enable_effects(fnt_result_screen, true, 
	{
		outlineEnable: true,
		outlineDistance: 4,
		outlineColour: c_black
	}
)
draw_set_halign(fa_center);
draw_set_valign(fa_center);
if(global.pause){
	draw_set_font(fnt_result_screen)
	draw_set_alpha(0.75)
	draw_set_color(c_black)
	draw_rectangle(0, 0, display_get_gui_width(), display_get_gui_height(), false)
	drawing_glass()
	draw_text(
	display_get_gui_width() / 2 + 3, 
	display_get_gui_height() / 2 + 3 + dsin(current_time * 0.1) * 10, 
	"Jogo pausado. \nDescansar né :3 \n\nPressione ESC para voltar ao jogo \n\nPressione M para voltar ao Menu")
	draw_set_alpha(1)
	draw_set_color(c_white)
	draw_text(
	display_get_gui_width() / 2, 
	display_get_gui_height() / 2 + dsin(current_time * 0.1) * 10, 
	"Jogo pausado. \nDescansar né :3 \n\nPressione ESC para voltar ao jogo \n\nPressione M para voltar ao Menu")
}
draw_set_halign(fa_left);
