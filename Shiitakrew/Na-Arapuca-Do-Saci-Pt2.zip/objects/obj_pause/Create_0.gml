global.pause = false

//Efeito de vidro atingido
larg_vidro_i = image_xscale * 10
alt_vidro_i = image_yscale * 10

larg_vidro_f = image_xscale * 11
alt_vidro_f = image_yscale * 11
 
larg_vidro = larg_vidro_i
alt_vidro = alt_vidro_i
 
tempo_pop = 0

drawing_glass = function()
{
	draw_sprite_ext(spr_glass, image_index, display_get_gui_width() / 2, display_get_gui_height() / 2, larg_vidro, alt_vidro, image_angle, image_blend, image_alpha);
}
