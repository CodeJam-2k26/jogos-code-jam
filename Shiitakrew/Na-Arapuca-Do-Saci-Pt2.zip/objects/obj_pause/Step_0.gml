var _btn_pause = keyboard_check_pressed(vk_escape)
var _btn_menu = keyboard_check_pressed(ord("M"))
if(_btn_pause){
	global.pause = !global.pause
}
if(global.pause){
	if(tempo_pop < 3){
				larg_vidro = lerp(larg_vidro, larg_vidro_f, 0.2)
				alt_vidro = lerp(alt_vidro, alt_vidro_f, 0.2)
				tempo_pop++
			}
			else{
				larg_vidro = lerp(larg_vidro, larg_vidro_i, 0.2)
				alt_vidro = lerp(alt_vidro, alt_vidro_i, 0.2)
			}
	if(_btn_menu) 
	{
		global.pause = false
		tempo_pop = 0
		larg_vidro = larg_vidro_i
		alt_vidro = alt_vidro_i
		ScriptFade(RoomMenu, 30, c_black)
	}
}
if(!global.pause)
{	
	tempo_pop = 0
	larg_vidro = larg_vidro_i
	alt_vidro = alt_vidro_i
}