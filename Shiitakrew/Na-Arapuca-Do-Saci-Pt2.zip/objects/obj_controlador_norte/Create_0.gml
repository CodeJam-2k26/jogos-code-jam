contagem_regressiva = 3;
mostrar_comecou = false;
global.start_norte = false;

alarm[0] = room_speed;