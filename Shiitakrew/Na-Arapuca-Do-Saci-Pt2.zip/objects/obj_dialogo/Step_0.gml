if iniciar == false 
{
	scr_dialogo();
	iniciar = true;
	alarm[0] = 1;
}

if mouse_check_button_pressed(mb_left)
{
	if teclado < string_length( texto_grid[# infos.Texto, pagina])
	{
		teclado = string_length( texto_grid[# infos.Texto, pagina])
	}
	else{
		
		alarm[0] = 1;
		teclado = 0;
		
		if pagina < ds_grid_height(texto_grid) - 1
		{
			pagina++;
		}	
		else
		{
			global.dialogo = false;
			instance_destroy();
		}
	}
}