
if iniciar == true {

	if teclado < string_length( texto_grid[# infos.Texto, pagina] ){
	
		if texto_grid[# infos.Lado, pagina] == 1 {
		
		var voz = snd_gaster
		
		if !audio_is_playing(snd_gaster)
		{
		audio_play_sound( voz, 1, 0)
		}
		
		}
	
		teclado++
		alarm[0] = 1;
		
	}
}