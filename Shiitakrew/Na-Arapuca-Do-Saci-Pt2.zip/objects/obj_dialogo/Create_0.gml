enum infos{
	Texto,
	Retrato,
	Frame,
	Lado,
	Nome
}

npc_nome = "";
texto_grid = ds_grid_create( 5, 0 ) // 4 colunas, 0 linhas
texto[0] = "";
pagina = 0;

iniciar = false;

teclado = 0;

alarm[0] = 1;