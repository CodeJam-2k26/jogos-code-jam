if iniciar == true {
	var _guih = display_get_gui_height();
	var _guiw = display_get_gui_width();

	var _xx = 0;
	var _yy = _guih - 200;
	var _sprite = texto_grid[# infos.Retrato, pagina];
	var _texto = string_copy( texto_grid[# infos.Texto, pagina], 0, teclado )
	var _frame = texto_grid[# infos.Frame, pagina]

	//Lado Esquerdo
	if texto_grid[# infos.Lado, pagina] == 0 
	{
		
		draw_sprite_stretched( spr_CaixaDialogo, image_index, _xx + 200, _yy, _guiw - 400, _guih - 510 )
		 
		
		draw_set_font( fnt_in_game )
		
		draw_set_valign(fa_top); 
		draw_text_ext( _xx + 230, _yy + 35, _texto, 20, (_guiw - 400) - 60 )
	
		draw_sprite_ext(_sprite, _frame, 320, _guih - 295, 3, 3, 0, c_white, 1);
	
	}

	//Lado Direito
	else
	{
		draw_sprite_stretched( spr_CaixaDialogo, image_index, _xx + 200, _yy, _guiw - 400, _guih - 510 )

		draw_set_font( fnt_in_game )
		
		
		draw_set_valign(fa_top); 
		draw_text_ext( _xx + 230, _yy + 35, _texto, 20, (_guiw - 400) - 60 )
	
		draw_sprite_ext(_sprite, _frame, _guiw - 320, _guih - 295, -3, 3, 0, c_white, 1);
		
	}

}