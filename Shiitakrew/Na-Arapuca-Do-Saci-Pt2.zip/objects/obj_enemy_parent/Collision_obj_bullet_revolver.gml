if(other.colidiu == false and state != enemy_states.morto)
{
	if(state == enemy_states.idle or state == enemy_states.walk){
		target = obj_player
		state = enemy_states.follow
	}
	tiro_dir = other.direction
	vel_h = lengthdir_x(4, tiro_dir)
	vel_v = lengthdir_y(4, tiro_dir)
	leva_dano(1)
	other.colidiu = true
}