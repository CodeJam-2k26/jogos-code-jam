if(global.dialogo or global.pause) exit;
//Colisão e movimentação

var _velh = sign(vel_h);
repeat(abs(vel_h))
{
	if(place_meeting(x + _velh, y, obj_collision) or place_meeting(x + _velh, y, obj_full_collision))
	{
		vel_h = 0;
		vel_v = 0
		move_dir = choose(0, 45, 90, 135, 180, 225, 270, 315)
	}
	else
	{
		x += _velh
	}
}
var _velv = sign(vel_v);
repeat(abs(vel_v))
{
	if(place_meeting(x, y + _velv, obj_collision) or place_meeting(x, y + _velv, obj_full_collision))
	{
		vel_h = 0
		vel_v = 0;
		move_dir = choose(0, 45, 90, 135, 180, 225, 270, 315)
	}
	else
	{
		y += _velv
	}
}