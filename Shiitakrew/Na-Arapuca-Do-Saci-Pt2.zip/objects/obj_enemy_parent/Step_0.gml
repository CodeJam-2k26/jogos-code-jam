if(global.dialogo or global.pause) {
	image_speed = 0
	exit;
}
else{
	if(sprite_index != spr_enemy_destroyed)image_speed = 1
}

depth = -y

efeito_dano_flash()