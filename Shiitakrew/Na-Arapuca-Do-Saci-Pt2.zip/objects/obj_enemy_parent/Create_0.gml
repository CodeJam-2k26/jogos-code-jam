current_speed = game_get_speed(gamespeed_fps)

sprite_morrendo = asset_sprite
vida_max = 1
vida_atual = vida_max
tempo_dano = current_speed * 1

//Velocidades
vel_h = 0;
vel_v = 0;
vel = 0
default_vel = 2
//Velocidade atual e direção
move_dir = 0;

morrendo = false
morto = false

tiro_dir = 0
leva_dano = function(_dano){
	if(state != enemy_states.morto){
	
	if(_dano == undefined) vida_atual -= 1
	else{
		vida_atual -= _dano
	}
	efeito_flash_ativo = true
	efeito_pop_ativo = true
	if(vida_atual <= 0){
		morrendo = true
		state = enemy_states.morto
	}
	}
}

player_knock_dir = 0


//Estados padrão
enum enemy_states
{
	idle,
	walk,
	follow,
	attack_prep,
	attack,
	morto
}

state = noone

time_of_state = current_speed * 4
current_state_time = time_of_state
timer_state = 0

change_state = function(_state){
		current_state_time--
		timer_state = irandom(current_state_time)
		
		if(current_state_time == timer_state or current_state_time <= 0)
		{
			state = _state[irandom(array_length(_state) - 1)]
			current_state_time = time_of_state
		}
}

//Marcando alvo
target = noone
target_dir = 0

//Função para desenhar a sprite da sombra do inimigo
drawing_shadow = function()
{
	draw_sprite_ext(spr_shadow, image_index, x, y, 0.85, image_yscale, image_angle, image_blend, 0.5);
}

//Efeitos visuais ao tomar dano
alpha_dano = 0
color_dano = c_white
valor_efeito = -0.08
efeito_flash_ativo = false
efeito_dano_flash = function(){
	if (!efeito_flash_ativo) return;
	
	if(alpha_dano <= 0) valor_efeito *= -1 
	
	if(alpha_dano > 1) valor_efeito *= -1 
	
	alpha_dano += valor_efeito
	
	if(alpha_dano <= 0) efeito_flash_ativo = false
}

//Desenhando o sinal de perigo
larg_sinal_i = image_xscale * 0.5
alt_sinal_i = image_yscale * 0.5
larg_sinal_f = image_xscale * 0.8
alt_sinal_f = image_yscale * 0.8
 
alpha_sinal_i = 0
alpha_sinal_f = 1
  
altura_sinal_i = 0
altura_sinal_f = -10
 
larg_sinal = larg_sinal_i
alt_sinal = alt_sinal_i

alpha_sinal = alpha_sinal_i

altura_sinal = altura_sinal_i

drawing_warning = function(){
	draw_sprite_ext(spr_warning, image_index, x, bbox_top + altura_sinal, larg_sinal, alt_sinal, image_angle, image_blend, alpha_sinal);
}


//Saturação de cor do objeto, utilizada na indicação do estado de preparo do ataque
sat = 0

//Ataque
attack_duration = 1
attack_time = attack_duration
//Definindo estados

state = enemy_states.idle

//Campo de visão
view = function(_width, _height, _xscale){
	var _x1, _x2, _y1, _y2
	
	_x1 = x + sign(image_xscale) * (-100)
	_y1 = y + _height / 2 - sprite_height / 2
	
	_x2 = _x1 + _width * image_xscale
	_y2 = _y1 - _height
	
	draw_rectangle(_x1, _y1, _x2, _y2, false)
	
	var _target = collision_rectangle(_x1, _y1, _x2, _y2, obj_player, 0, 1)
	if(obj_player.state != player_states.morto){
	return _target
	}
}
