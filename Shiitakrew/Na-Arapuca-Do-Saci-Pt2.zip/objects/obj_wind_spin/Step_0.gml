if(global.dialogo or global.pause or obj_player.vida <= 0) {
	image_speed = 0
	exit;
	
}

event_inherited()

switch (state){
	case "follow":
	
	tempo --
	if(instance_exists(target) and tempo > 0)
		{
			if(sprite_index != spr_wind){
			sprite_index = spr_wind;
			}
			
		}
	else{
		if(sprite_index != spr_enemy_destroyed){
		sprite_index = spr_enemy_destroyed;
		}
		vel = 0
		vel_h = 0
		vel_v = 0
	}
	
	break;
	
	case "destroy":
	if(image_speed <= 0)
		{	
			image_alpha -= 0.02
		}
	
		//Se sumiu totalmente, se destrói
		if(image_alpha <= 0)
		{
			instance_destroy();
			exit;
		}
	break;
}