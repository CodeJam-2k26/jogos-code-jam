drawing_shadow();
draw_self();
if(alpha_dano > 0){
gpu_set_fog(true, color_dano, 0, 0);

draw_sprite_ext(sprite_index, image_index, x, y, image_xscale, image_yscale, image_angle, image_blend, alpha_dano - 0.2);

gpu_set_fog(false, color_dano, 0, 0);
}