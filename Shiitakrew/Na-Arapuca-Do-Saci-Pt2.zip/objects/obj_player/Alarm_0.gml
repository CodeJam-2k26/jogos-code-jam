//Alarme para o dash
can_dash = true