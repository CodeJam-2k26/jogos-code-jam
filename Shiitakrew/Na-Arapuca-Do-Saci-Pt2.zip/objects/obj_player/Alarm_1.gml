//Resetando o tempo de invulnerabilidade
nao_toma_dano = false;
alpha_dano = 0