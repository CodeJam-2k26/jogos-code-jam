if(global.pause) exit;
font_enable_effects(fnt_ui, true, 
	{
		outlineEnable: true,
		outlineDistance: 2,
		outlineColour: c_black
	}
)
font_enable_effects(fnt_result_screen, true, 
	{
		outlineEnable: true,
		outlineDistance: 4,
		outlineColour: c_black
	}
)
draw_set_font(fnt_ui);
draw_set_halign(fa_left);
draw_set_valign(fa_top);
if(state != player_states.morto){
	//Desenhando as barras da HUD
	var _amount = (vida / vida_max) * barra_larg
	
	var _amount_dash = (dash_time / dash_cooldown) * barra_larg
	var _empty_bar = (vida_max / vida_max) * barra_larg
	
	var _empty_dash_bar = (dash_distance / dash_distance) * barra_larg
	
	//Barra de vida
	draw_sprite_stretched_ext(spr_empty_bar, image_index, 21, 11, 21 + _empty_bar, 21 + barra_alt, c_black, 0.5)
	draw_sprite_stretched(spr_empty_bar, image_index, 20, 10, 20 + _empty_bar, 20 + barra_alt)
		
	if(vida > 0){
	draw_sprite_stretched(spr_lifebar, image_index, 20, 10, 20 + _amount, 20 + barra_alt)
	}
	
	draw_set_alpha(0.75)
	draw_set_color(c_black)
	draw_set_halign(fa_center)
	draw_text(165 + 2, 20 + 2, "Vida: " + string(obj_player.vida) + "/" + string(obj_player.vida_max));
	draw_set_alpha(1)
	draw_set_color(c_white)
	draw_text(165, 20, "Vida: " + string(obj_player.vida) + "/" + string(obj_player.vida_max));
	
	//Barra de munição
	//Munição revólver
	if(instance_exists(obj_revolver)){
	var _amount_ammo = (obj_revolver.ammo / obj_revolver.max_ammo) * barra_larg
	var _empty_ammo_bar = (obj_revolver.max_ammo / obj_revolver.max_ammo) * barra_larg
	
	draw_sprite_ext(spr_revolver, image_index, 372, 97, 2, 2, 20, c_black, 0.5)
	draw_sprite_ext(spr_revolver, image_index, 370, 95, 2, 2, 20, c_white, image_alpha)
	
	draw_sprite_stretched_ext(spr_empty_bar, image_index, 21, 71, 21 + _empty_bar, 21 + barra_alt, c_black, 0.5)
	draw_sprite_stretched(spr_empty_bar, image_index, 20, 70, 20 + _empty_ammo_bar, 20 + barra_alt)
		
	if(obj_revolver.ammo > 0){
	draw_sprite_stretched(spr_ammo_bar, image_index, 20, 70, 20 + _amount_ammo, 20 + barra_alt)
	}
	
	if(obj_revolver.ammo > 0){	
	
	draw_set_alpha(0.75)
	draw_set_color(c_black)
	draw_text(165 + 2, 80 + 2, "Munição: " + string(obj_revolver.ammo))
	draw_set_alpha(1)
	draw_set_color(c_white)
	draw_text(165, 80, "Munição: " + string(obj_revolver.ammo))
}
else{
	draw_set_alpha(0.75)
	draw_set_color(c_black)
	draw_text(180 + 2, 80 + 2, "Munição: 0...")
	draw_set_alpha(1)
	draw_set_color(c_white)
	draw_text(180, 80, "Munição: 0...")
}
	}
	//Munição escopeta
	if(instance_exists(obj_gun_shotgun)){
	var _amount_ammo = (obj_gun_shotgun.ammo / obj_gun_shotgun.max_ammo) * barra_larg
	var _empty_ammo_bar = (obj_gun_shotgun.max_ammo / obj_gun_shotgun.max_ammo) * barra_larg
	
	draw_sprite_ext(spr_shotgun, image_index, 372, 107, 2, 2, 20, c_black, 0.5)
	draw_sprite_ext(spr_shotgun, image_index, 370, 105, 2, 2, 20, c_white, image_alpha)
	
	draw_sprite_stretched_ext(spr_empty_bar, image_index, 21, 71, 21 + _empty_bar, 21 + barra_alt, c_black, 0.5)
	draw_sprite_stretched(spr_empty_bar, image_index, 20, 70, 20 + _empty_ammo_bar, 20 + barra_alt)
		
	if(obj_gun_shotgun.ammo > 0){
	draw_sprite_stretched(spr_ammo_bar, image_index, 20, 70, 20 + _amount_ammo, 20 + barra_alt)
	}
	
	if(obj_gun_shotgun.ammo > 0){	
	
	draw_set_alpha(0.75)
	draw_set_color(c_black)
	draw_text(165 + 2, 80 + 2, "Munição: " + string(obj_gun_shotgun.ammo))
	draw_set_alpha(1)
	draw_set_color(c_white)
	draw_text(165, 80, "Munição: " + string(obj_gun_shotgun.ammo))
}
else{
	draw_set_alpha(0.75)
	draw_set_color(c_black)
	draw_text(180 + 2, 80 + 2, "Munição: 0...")
	draw_set_alpha(1)
	draw_set_color(c_white)
	draw_text(180, 80, "Munição: 0...")
}
	}

	//Barra de esquiva
	draw_sprite_stretched_ext(spr_empty_bar, image_index, 21, 131, 21 + _empty_bar, 21 + barra_alt, c_black, 0.5)
	draw_sprite_stretched(spr_empty_bar, image_index, 20, 130, 20 + _empty_dash_bar, 20 + barra_alt)
		
	if(dash_time > 0 and dash_time <= 60){
	draw_sprite_stretched(spr_dash_bar, image_index, 20, 130, 20 + _amount_dash, 20 + barra_alt)
	}

if(can_dash){
	draw_set_alpha(0.75)
	draw_set_color(c_black)
	draw_text(170 + 2, 140 + 2, "Esquiva: Pronta")
	draw_set_alpha(1)
	draw_set_color(c_white)
	draw_text(170, 140, "Esquiva: Pronta")
}
else{
	draw_set_alpha(0.75)
	draw_set_color(c_black)
	draw_text(170 + 2, 140 + 2, "Esquiva: ...")
	draw_set_alpha(1)
	draw_set_color(c_white)
	draw_text(170, 140, "Esquiva: ...")
}
}
draw_set_halign(fa_center);
draw_set_valign(fa_center);


//Tela de morte
if(state == player_states.morto){
	draw_set_font(fnt_result_screen)
	draw_set_alpha(0.75)
	draw_set_color(c_black)
	draw_rectangle(0, 0, display_get_gui_width(), display_get_gui_height(), false)
	drawing_glass()
	draw_text(
	display_get_gui_width() / 2 + 3, 
	display_get_gui_height() / 2 + 3 + dsin(current_time * 0.1) * 10, 
	"Você morreu... \nQue pena :3 \n\nPressione R para reiniciar")
	draw_set_alpha(1)
	draw_set_color(c_white)
	draw_text(
	display_get_gui_width() / 2, 
	display_get_gui_height() / 2 + dsin(current_time * 0.1) * 10, 
	"Você morreu... \nQue pena :3 \n\nPressione R para reiniciar")
}
