if(global.dialogo or global.pause) {
	image_speed = 0
	exit;
	
}
else{
	image_speed = 1
}

//SISTEMA DE DIALOGO


if distance_to_object(obj_pai_npcs) <= 10
{
	if keyboard_check_pressed(ord("F")) && global.dialogo == false
	{
		var _npc = instance_nearest( x, y, obj_pai_npcs);
		var _dialogo = instance_create_layer( x, y, "dialogos", obj_dialogo );
		_dialogo.npc_nome = _npc.nome;
	}
}


//Desenhando o player na profundidade certa
depth = -bbox_bottom;
//Efeito visual de tomar dano
efeito_dano()
arma_tempo++
//Controle de estados
switch (state){
	//Estado padrão
	case player_states.free:
		//Controles
		var _left, _right, _up, _down;

		_left = keyboard_check(inputs.left);
		_right = keyboard_check(inputs.right);
		_up = keyboard_check(inputs.up);
		_down = keyboard_check(inputs.down);

		
//Checando se o player está tentando se mover na horizontal ou na vertical
		var _horizontal = (_right-_left)
		var _vertical = (_down - _up)
//Armazenando a direção
		move_dir = point_direction(0,0, _horizontal, _vertical)
		
		//Checando a direção de movimento do player e se ele está dando algum comando
		if(_up or _down or _left or _right)
		{	
			//Aceleração
			vel = lerp(vel, max_vel, 0.1)
		}
		else
		{
			vel = 0
		}
		//Aplicando a velocidade horizontal e vertical
			vel_h = lengthdir_x(vel, move_dir)
			vel_v = lengthdir_y(vel, move_dir)
		if(mouse_x - x != 0)
		{
			if(vel_v != 0 or vel_h != 0)
			{
				if(sprite_index != spr_chico_sides_run) sprite_index = spr_chico_sides_run
			}
			else
			{
				if(sprite_index != spr_chico_sides_idle)sprite_index = spr_chico_sides_idle
			}
			image_xscale = sign(mouse_x - x) * 2
		}
		
		if(keyboard_check_pressed(ord("Q")) and arma_tempo >= 120){
			arma_tempo = 0
			if(arma == obj_revolver){
			instance_destroy(obj_revolver);
			instance_create_layer(x, y, "player", obj_gun_shotgun, {ammo: 0, sprite_index: spr_shotgun_reload});
			arma = obj_gun_shotgun
			}
			else{
			instance_destroy(obj_gun_shotgun);
			instance_create_layer(x, y, "player", obj_revolver, {ammo: 0, sprite_index: spr_revolver_reload});
			arma = obj_revolver
			}
		}
		if(dash_time < 60){
		dash_time++
			if(dash_time >= 60){
			can_dash = true
			}
		}
		
		
		if(keyboard_check_pressed(vk_space) and can_dash){
			if(_horizontal or _vertical){
			vel = 12
			vel_h = lengthdir_x(vel, move_dir)
			vel_v = lengthdir_y(vel, move_dir)
			can_dash = false
			dash_time = 0
			
			state = player_states.dash
			audio_play_sound(snd_dash, 10, false)
			}
			else{
			dash_time = 0
			vel = 12
			if(sign(image_xscale) == -1){
				vel_h = lengthdir_x(vel, 180)
				vel_v = lengthdir_y(vel, move_dir)
				can_dash = false
				
				state = player_states.dash
				audio_play_sound(snd_dash, 10, false)
			}
			if(sign(image_xscale) == 1){
				vel_h = lengthdir_x(vel, move_dir)
				vel_v = lengthdir_y(vel, move_dir)
				can_dash = false
				
				state = player_states.dash
				audio_play_sound(snd_dash, 10, false)
			}
			}
		}
		
	break;
		//Estado de dash
		case player_states.dash:
			if(sprite_index != spr_dash) sprite_index = spr_dash
			vel = 12
			dash_time++
			
			if(dash_time >= dash_distance)
			{
				state = player_states.free
			}
	break;
	
	case player_states.morto:
			vel_h = 0
			vel_v = 0
			if(sprite_index != spr_chico_defeated) sprite_index = spr_chico_defeated
			if(tempo_pop < 3){
				larg_vidro = lerp(larg_vidro, larg_vidro_f, 0.2)
				alt_vidro = lerp(alt_vidro, alt_vidro_f, 0.2)
				tempo_pop++
			}
			else{
				larg_vidro = lerp(larg_vidro, larg_vidro_i, 0.2)
				alt_vidro = lerp(alt_vidro, alt_vidro_i, 0.2)
			}
			image_xscale = 1
			instance_destroy(obj_revolver)
			instance_destroy(obj_gun_shotgun)
			if(keyboard_check_pressed(ord("R"))){
				room_restart()
			}
	break;
}



