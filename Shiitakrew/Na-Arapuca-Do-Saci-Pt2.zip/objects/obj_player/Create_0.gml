image_yscale = 2

//Velocidades
vel_h = 0;
vel_v = 0;
max_vel = 4;

//Velocidade atual 
vel = 0; 
//Direção
move_dir = 0;

//Arma do player atual
arma = obj_revolver
arma_tempo = 0

//Contagem de tempo
current_speed = game_get_speed(gamespeed_fps);


//Sistema de dano
nao_toma_dano = false
vida_max = 100
vida = vida_max
barra_alt = 35
barra_larg = 290

tempo_iframe = current_speed * 1

//Efeito visual ao tomar dano
alpha_dano = 0
color_dano = c_white


efeito_dano = function(){
	static _valor = -0.08
	
	if(!nao_toma_dano) return;
	
	if(alpha_dano <= 0) _valor *= -1 
	
	if(alpha_dano > 1) _valor *= -1 
	
	alpha_dano += _valor
}

toma_dano = function(){
	//Enquanto estiver no dash ele não toma dano, ou seja, o código restante não roda
	if(state == player_states.dash or state = player_states.morto) return;
	//Se ele estiver invulnerável, o código restante não roda
	if(nao_toma_dano) return;
	//Se ele NÃO estiver invulnerável, o código restante roda
	if(vida > 0){
	audio_play_sound(snd_player_dmg, 10, false)
	vida -= 10
	nao_toma_dano = true
	alpha_dano = 1
	alarm[1] = tempo_iframe
	}
	if(vida <= 0){
		audio_play_sound(snd_gunshot_2, 10, false)
		audio_play_sound(snd_glass, 10, false)
		
		state = player_states.morto
	}
}



//Dash
can_dash = true
dash_distance = 12
dash_cooldown = 60
dash_time = dash_cooldown
//Estados
enum player_states{
	free,
	dash,
	morto
}

state = player_states.free;



//Criando os objetos junto do player
instance_create_layer(x, y, "camera", obj_cam);
instance_create_layer(x, y, "camera", obj_aim);

instance_create_layer(x, y, layer, obj_revolver);

//Função para desenhar a sprite da sombra do player
drawing_shadow = function()
{
	draw_sprite_ext(spr_shadow, image_index, x, y, 0.5, 0.5, image_angle, image_blend, 0.5);
}
//Efeito de vidro atingido
larg_vidro_i = image_xscale * 10
alt_vidro_i = image_yscale * 10

larg_vidro_f = image_xscale * 11
alt_vidro_f = image_yscale * 11
 
larg_vidro = larg_vidro_i
alt_vidro = alt_vidro_i
 
tempo_pop = 0

drawing_glass = function()
{
	draw_sprite_ext(spr_glass, image_index, display_get_gui_width() / 2, display_get_gui_height() / 2, larg_vidro, alt_vidro, image_angle, image_blend, image_alpha);
}
//Entrada de comandos
inputs = {
	left : ord("A"),
	right : ord("D"),
	up: ord("W"),
	down: ord("S"),
	click_left: mb_left
}