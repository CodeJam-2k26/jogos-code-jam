image_xscale = 4
image_yscale = 4

vel = 5;
zona_morta = 40;
tempo_reacao = 0;