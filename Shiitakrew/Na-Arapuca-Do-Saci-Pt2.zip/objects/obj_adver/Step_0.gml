if (global.jogo_acabou == true) exit;
if ( global.start_pong ) {

	tempo_reacao--;
	if (tempo_reacao <= 0) {
	    if ( obj_ball.y > y + zona_morta )
		{
			 mover = 1;
		}
	    else if (obj_ball.y < y - zona_morta )
		{ 
			mover = -1;
		}
	
	    else 
		{
			mover = 0;
		}
	
	    tempo_reacao = 20;
	}

	y = y + (mover * vel);

	if ( bbox_bottom > room_height ) y = room_height - ( sprite_height * 0.5 );
	if ( bbox_top < 0 ) y = 0 + ( sprite_height * 0.5 );

}
