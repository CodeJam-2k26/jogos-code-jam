tempo_start = 60
if(room == Room_intro1) {
	tempo_start = 30
}
if(room == Room_intro2) {
	tempo_start = 180
}