tempo_start--
if (tempo_start <= 0 and room == Room_intro1){
	ScriptFade(Room_intro2, 30, c_black)
}
if(tempo_start == 140 and room == Room_intro2){
	audio_play_sound(snd_intro, 10, false)
}
if (tempo_start <= 0 and room == Room_intro2){
	ScriptFade(RoomMenu, 30, c_black)
}