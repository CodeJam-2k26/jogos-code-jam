contagem_regressiva = 3;
mostrar_comecou = false;
global.start_pong = false;

alarm[0] = room_speed;