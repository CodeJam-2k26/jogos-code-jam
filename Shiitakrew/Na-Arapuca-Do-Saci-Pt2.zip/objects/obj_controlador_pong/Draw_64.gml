draw_set_font(fnt_result_screen)

if (!global.start_pong)
{
	draw_set_halign( fa_center)
	draw_text( display_get_gui_width() / 2, display_get_gui_height() / 2, string(contagem_regressiva) + "!")
}
else if (mostrar_comecou)
{
	draw_set_halign( fa_center )
	draw_text( display_get_gui_width() / 2, display_get_gui_height() / 2, "COMEÇOU!!!")
}