//Estado inicial
if(state == 0)
{
	timer ++
	
	//Trocar sala
	if(timer >= duracao){
		room_goto(alvo)
		
		//Mudar estado
		state = 1
	}
}

//Estado final
else if(state == 1){
	timer --
	
	//Destruir instância
	if(timer <= 0){
		instance_destroy()
	}
}

//Mudar alpha
alpha = timer / duracao