duracao = 60
alvo = room
cor = c_black

timer = 0
alpha = 0
state = 0