if(sprite_index == spr_enemy_destroyed){
	image_speed = 0
	image_index = 6
	state = "destroy"
}