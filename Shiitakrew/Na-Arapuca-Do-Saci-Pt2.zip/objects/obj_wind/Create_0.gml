event_inherited()
target = obj_player
vel = 5
vel_h = 0
vel_v = 0
state = "follow"
tempo = 180