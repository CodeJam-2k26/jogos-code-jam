if(sprite_index != spr_enemy_destroyed){
		sprite_index = spr_enemy_destroyed;
}
vel = 0
vel_h = 0
vel_v = 0