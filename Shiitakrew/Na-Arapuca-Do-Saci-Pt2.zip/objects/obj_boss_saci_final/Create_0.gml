image_xscale = 2

// Inherit the parent event
event_inherited();

vida_max = 60
vida_atual = vida_max
vida_rage = 15
tempo_spawn = 180
tempo_spawn_spin = 300
wind_spin_phase = 1
tempo_fakers_start = 420
tempo_fakers_end = 360
fakers_sequence = [0,0,0,0,0,0,0,1]
fakers_spawn = 0
barra_alt = 80
barra_larg = 1000
target = obj_player
tempo_stun = 120

state = saci_states.start

