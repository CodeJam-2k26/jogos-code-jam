// Inherit the parent event
if(global.dialogo or global.pause or obj_player.vida <= 0) {
	image_speed = 0
	exit;
	
}

event_inherited();
if(sign(vel_h) != 0 and state != saci_states.morto)
		{
			image_xscale = sign(vel_h) * 2
		}
if(vida_atual <= 0 and state != saci_states.morto){
			state = saci_states.morto
		}

switch (state)
{
	case saci_states.start:
		if(sprite_index != spr_boss_saci){
			sprite_index = spr_boss_saci
		}
		vel_h = 0
		vel_v = 0
		if(alarm[0] == -1){
			alarm[0] = current_speed * 2
		}
		
	break;
	
	case saci_states.follow:
		if(sprite_index != spr_boss_saci_wind){
			sprite_index = spr_boss_saci_wind
		}
		if(vida_atual < vida_rage and state != saci_states.rage_transition){
			state = saci_states.rage_transition
		}
		vel = 4
		if(instance_exists(target))
		{
			var _dir = point_direction(x, y, target.x, target.y)
			vel_h = lengthdir_x(vel, _dir)
			vel_v = lengthdir_y(vel, _dir)
			
			var _dist = point_distance(x, y, target.x, target.y)
			
			tempo_spawn --
			if(tempo_spawn == 0){
				state = saci_states.spawns
				tempo_spawn = 180
			}
			tempo_spawn_spin --
			if(tempo_spawn_spin == 0){
				state = saci_states.spawns_spin
				wind_spin_phase = 1
				tempo_spawn_spin = 360
			}
			tempo_fakers_start --
			if(tempo_fakers_start == 0){
				state = saci_states.fakers
				tempo_fakers_start = 540
				fakers_sequence = array_shuffle(fakers_sequence)
			}
		}
	break;
	
	case saci_states.spawns:
	if(vida_atual < vida_rage and state != saci_states.rage_transition){
			state = saci_states.rage_transition
		}
		
	vel_h = 0
	vel_v = 0
	//Saber a distância da origem da sprite até onde o tiro deve sair
	var _dist_x = 100
	var _dist_y = 0
	var _dist = point_distance(0, 0, _dist_x, _dist_y)
	audio_play_sound(snd_wind, 10, false)
	for(var i = 0; i < 4; i++){
		//Saber a direção da origem da sprite até onde o tiro deve sair
		var _dir = point_direction(0, 0, _dist_x, _dist_y)
		var _dir_bullet = 0 + (i * 90)
		//Posição para a criação dos tiros
		var _x_bullet = lengthdir_x(_dist, image_angle + _dir + _dir_bullet)
		var _y_bullet = lengthdir_y(_dist, image_angle + _dir + _dir_bullet)
	
		//Criando o tiro
		var _bullet = instance_create_layer(x + _x_bullet, y + _y_bullet, "tiros", obj_wind) 
		_bullet.direction = _dir_bullet
		
	}
	state = saci_states.follow
	
	break;
	
	case saci_states.spawns_spin:
	if(vida_atual < vida_rage and state != saci_states.rage_transition){
			state = saci_states.rage_transition
		}
	if(sprite_index != spr_boss_saci_rage){
			sprite_index = spr_boss_saci_rage
		}
	vel_h = 0
	vel_v = 0
	//Saber a distância da origem da sprite até onde o tiro deve sair
	
	_dist_x = 100
	_dist_y = 0
	_dist = point_distance(0, 0, _dist_x, _dist_y)
	if(wind_spin_phase == 1 and alarm[1] = -1){
	alarm[1] = current_speed * 0.5;
	audio_play_sound(snd_wind, 10, false)
	for(var i = 0; i < 4; i++){
		//Saber a direção da origem da sprite até onde o tiro deve sair
		var _dir = point_direction(0, 0, _dist_x, _dist_y)
		var _dir_bullet = 0 + (i * 90)
		//Posição para a criação dos tiros
		var _x_bullet = lengthdir_x(_dist, image_angle + _dir + _dir_bullet)
		var _y_bullet = lengthdir_y(_dist, image_angle + _dir + _dir_bullet)
	
		//Criando o tiro
		var _bullet = instance_create_layer(x + _x_bullet, y + _y_bullet, "tiros", obj_wind_spin) 
		_bullet.direction = _dir_bullet
		_bullet.speed = 4
		
		}
		
	}
	if(wind_spin_phase == 2 and alarm[1] = -1){
	alarm[1] = current_speed * 0.5;
	audio_play_sound(snd_wind, 10, false)
	for(var i = 0; i < 4; i++){
		//Saber a direção da origem da sprite até onde o tiro deve sair
		var _dir = point_direction(0, 0, _dist_x, _dist_y)
		var _dir_bullet = 45 + (i * 90)
		//Posição para a criação dos tiros
		var _x_bullet = lengthdir_x(_dist, image_angle + _dir + _dir_bullet)
		var _y_bullet = lengthdir_y(_dist, image_angle + _dir + _dir_bullet)
	
		//Criando o tiro
		var _bullet = instance_create_layer(x + _x_bullet, y + _y_bullet, "tiros", obj_wind_spin) 
		_bullet.direction = _dir_bullet
		_bullet.speed = 4
		
		}
		
	}
	if(wind_spin_phase == 3 and alarm[1] = -1){
		alarm[1] = current_speed * 0.5;
	audio_play_sound(snd_wind, 10, false)
	for(var i = 0; i < 4; i++){
		//Saber a direção da origem da sprite até onde o tiro deve sair
		var _dir = point_direction(0, 0, _dist_x, _dist_y)
		var _dir_bullet = 0 + (i * 90)
		//Posição para a criação dos tiros
		var _x_bullet = lengthdir_x(_dist, image_angle + _dir + _dir_bullet)
		var _y_bullet = lengthdir_y(_dist, image_angle + _dir + _dir_bullet)
	
		//Criando o tiro
		var _bullet = instance_create_layer(x + _x_bullet, y + _y_bullet, "tiros", obj_wind_spin) 
		_bullet.direction = _dir_bullet
		_bullet.speed = 4
		
		}
		
	}
	if(wind_spin_phase == 4 and alarm[1] = -1){
	alarm[1] = current_speed * 0.5;
	audio_play_sound(snd_wind, 10, false)
	for(var i = 0; i < 4; i++){
		//Saber a direção da origem da sprite até onde o tiro deve sair
		var _dir = point_direction(0, 0, _dist_x, _dist_y)
		var _dir_bullet = 45 + (i * 90)
		//Posição para a criação dos tiros
		var _x_bullet = lengthdir_x(_dist, image_angle + _dir + _dir_bullet)
		var _y_bullet = lengthdir_y(_dist, image_angle + _dir + _dir_bullet)
	
		//Criando o tiro
		var _bullet = instance_create_layer(x + _x_bullet, y + _y_bullet, "tiros", obj_wind_spin) 
		_bullet.direction = _dir_bullet
		_bullet.speed = 4
		
		}
		state = saci_states.follow
	}
	
	
	break;
	
	case saci_states.fakers:
	if(vida_atual < vida_rage and state != saci_states.rage_transition){
			state = saci_states.rage_transition
		}
	image_alpha = 0
	
	vel_h = 0
	vel_v = 0
	_dist_x = 100
	_dist_y = 0
	_dist = point_distance(0, 0, _dist_x, _dist_y)
	if(fakers_spawn = 0){
		audio_play_sound(snd_wind, 10, false)
	for(var i = 0; i < 4; i++){
		//Saber a direção da origem da sprite até onde o tiro deve sair
		var _dir = point_direction(0, 0, _dist_x, _dist_y)
		var _dir_bullet = 0 + (i * 90)
		//Posição para a criação dos tiros
		var _x_bullet = lengthdir_x(_dist, image_angle + _dir + _dir_bullet)
		var _y_bullet = lengthdir_y(_dist, image_angle + _dir + _dir_bullet)
	
		if (fakers_sequence[i] == 1){
		var _bullet = instance_create_layer(x + _x_bullet, y + _y_bullet, "tiros", obj_saci_faker_1) 
		
		_bullet.angle_spin = _dir_bullet
		
		}
		else {
		var _bullet = instance_create_layer(x + _x_bullet, y + _y_bullet, "tiros", obj_saci_faker_0) 
		
		_bullet.angle_spin = _dir_bullet
		
		}
	}
	fakers_spawn = 1
	}
	
	break;
	
	case saci_states.rage_transition:
		if(sprite_index != spr_boss_saci_wind){
			sprite_index = spr_boss_saci_wind
		}
		
		vel_h = 0
		vel_v = 0
		if(alarm[2] == -1){
			alarm[2] = current_speed * 2
			tempo_spawn_spin = 120
		}
		
	break;
	
	case saci_states.rage:
		if(sprite_index != spr_boss_saci_rage){
			sprite_index = spr_boss_saci_rage
		}
		if(vida_atual <= 0 and state != saci_states.morto){
			state = saci_states.morto
		}
		vel = 4
		if(instance_exists(target))
		{
			var _dir = point_direction(x, y, target.x, target.y)
			vel_h = lengthdir_x(vel, _dir)
			vel_v = lengthdir_y(vel, _dir)
			
			_dist = point_distance(x, y, target.x, target.y)
		}
		tempo_spawn_spin --
		//Saber a distância da origem da sprite até onde o tiro deve sair
	if(tempo_spawn_spin <= 0)
	{
		wind_spin_phase = 1
		tempo_spawn_spin = 180
	}
	_dist_x = 100
	_dist_y = 0
	_dist = point_distance(0, 0, _dist_x, _dist_y)
	if(wind_spin_phase == 1 and alarm[1] = -1){
	alarm[1] = current_speed * 1;
	audio_play_sound(snd_wind, 10, false)
	for(var i = 0; i < 4; i++){
		//Saber a direção da origem da sprite até onde o tiro deve sair
		var _dir = point_direction(0, 0, _dist_x, _dist_y)
		var _dir_bullet = 0 + (i * 90)
		//Posição para a criação dos tiros
		var _x_bullet = lengthdir_x(_dist, image_angle + _dir + _dir_bullet)
		var _y_bullet = lengthdir_y(_dist, image_angle + _dir + _dir_bullet)
	
		//Criando o tiro
		var _bullet = instance_create_layer(x + _x_bullet, y + _y_bullet, "tiros", obj_wind_spin) 
		_bullet.direction = _dir_bullet
		_bullet.speed = 4
		
		}
		
	}
	if(wind_spin_phase == 2 and alarm[1] = -1){
	alarm[1] = current_speed * 1;
	audio_play_sound(snd_wind, 10, false)
	for(var i = 0; i < 4; i++){
		//Saber a direção da origem da sprite até onde o tiro deve sair
		var _dir = point_direction(0, 0, _dist_x, _dist_y)
		var _dir_bullet = 45 + (i * 90)
		//Posição para a criação dos tiros
		var _x_bullet = lengthdir_x(_dist, image_angle + _dir + _dir_bullet)
		var _y_bullet = lengthdir_y(_dist, image_angle + _dir + _dir_bullet)
	
		//Criando o tiro
		var _bullet = instance_create_layer(x + _x_bullet, y + _y_bullet, "tiros", obj_wind_spin) 
		_bullet.direction = _dir_bullet
		_bullet.speed = 4
		
		}
		
	}
	if(wind_spin_phase == 3 and alarm[1] = -1){
		
	audio_play_sound(snd_wind, 10, false)
	for(var i = 0; i < 4; i++){
		//Saber a direção da origem da sprite até onde o tiro deve sair
		var _dir = point_direction(0, 0, _dist_x, _dist_y)
		var _dir_bullet = 0 + (i * 90)
		//Posição para a criação dos tiros
		var _x_bullet = lengthdir_x(_dist, image_angle + _dir + _dir_bullet)
		var _y_bullet = lengthdir_y(_dist, image_angle + _dir + _dir_bullet)
	
		//Criando o tiro
		var _bullet = instance_create_layer(x + _x_bullet, y + _y_bullet, "tiros", obj_wind_spin) 
		_bullet.direction = _dir_bullet
		_bullet.speed = 4
		
		}
		wind_spin_phase = 0;
	}
	
	break;
	
	case saci_states.stun:
	if(vida_atual < 5 and state != saci_states.rage_transition){
			state = saci_states.rage_transition
		}
	if(sprite_index != spr_boss_saci_stun){
		sprite_index = spr_boss_saci_stun
	}
	image_alpha = 1
	
	vel_h = 0
	vel_v = 0
	tempo_stun --
	if(tempo_stun == 0){
		tempo_stun = 120
		state = saci_states.follow
	}
	break;
	
	case saci_states.morto:
		if(sprite_index != spr_boss_saci_stun){
			sprite_index = spr_boss_saci_stun
		}
		vel = 0
		vel_h = 0
		vel_v = 0
		ScriptFade(Room_cont_pesca, 30, c_black)
		
	break;
}