// Inherit the parent event
if(global.dialogo or global.pause or obj_player.vida <= 0) {
	image_speed = 0
	exit;
	
}
event_inherited();

