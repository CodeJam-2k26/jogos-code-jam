if(other.colidiu == false and state != saci_states.morto and state != saci_states.fakers and state != saci_states.rage_transition)
{
	tiro_dir = other.direction
	vel_h = lengthdir_x(4, tiro_dir)
	vel_v = lengthdir_y(4, tiro_dir)
	leva_dano(1)
	other.colidiu = true
}