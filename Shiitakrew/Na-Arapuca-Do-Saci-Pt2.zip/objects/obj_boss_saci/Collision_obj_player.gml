//Rodando o código de dano ao player

if (state != saci_states.morto and state != saci_states.fakers and other.state != player_states.dash) 
{
	player_knock_dir = point_direction(x, y, other.x, other.y)
	other.vel_h = lengthdir_x(2, player_knock_dir)
	other.vel_v = lengthdir_y(2, player_knock_dir)
	other.toma_dano();
}
