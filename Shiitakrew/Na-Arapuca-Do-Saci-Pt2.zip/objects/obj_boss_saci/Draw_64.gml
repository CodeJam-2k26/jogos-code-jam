if(global.dialogo or global.pause or obj_player.vida <= 0) {
	image_speed = 0
	exit;
	
}
var _altura = display_get_gui_height()
var _comprimento = display_get_gui_width()

var _x1 = (_comprimento / 2) - (barra_larg / 2);
var _x2 = (_comprimento / 2) + (barra_larg / 2);

var _y1 = _altura - barra_alt 
var _y2 = barra_alt - 10

var _txt_x = _comprimento / 2
var _txt_y = _altura - 50

var _amount = (vida_atual / vida_max) * barra_larg
	
	var _empty_bar = barra_larg
	
	
	//Barra de vida
	draw_sprite_stretched_ext(spr_empty_bar, image_index, _x1 + 1, _y1 +1 , _x1 +1, _y2 +1, c_black, 0.5)
	draw_sprite_stretched(spr_empty_bar, image_index, _x1, _y1, _empty_bar, _y2)
		
	if(vida_atual > 0){
	draw_sprite_stretched(spr_lifebar, image_index, _x1, _y1,_amount, _y2)
	}
	
	draw_set_font(fnt_ui)
	draw_set_alpha(0.75)
	draw_set_color(c_black)
	draw_set_halign(fa_center)
	draw_text(_txt_x + 2, _txt_y + 2, "- Saci -");
	draw_set_alpha(1)
	draw_set_color(c_white)
	draw_text(_txt_x, _txt_y, "- Saci -");