if (room == Room_controles) global.campanha = true
if (room == Room_minigames) global.campanha = false

switch (room){
	case Room_controles:
		ScriptFade(RoomTutorial, 30, c_black)
	break;
	
	case RoomPrologo:
		ScriptFade(Room_controles, 30, c_black)
	break;
	
	case RoomEquipe:
		ScriptFade(RoomMenu, 30, c_black)
	break;
	
	case RoomSacigarrafa:
		ScriptFade(RoomFinalJogo, 30, c_black)
	break;
	
	case RoomFinalJogo:
		ScriptFade(RoomEquipe, 30, c_black)
	break;
	
	case Room_cont_pesca:
		ScriptFade(Room_MG_Pesca, 30, c_black)
	break;
	
	case Room_cont_cacto:
		ScriptFade(RoomMiniNordeste, 30, c_black)
	break;
	
	case Room_cont_laco:
		ScriptFade(RoomSul, 30, c_black)
	break;
	
	case Room_cont_pong:
		ScriptFade(Room_MG_Pong, 30, c_black)
	break;
	
	case Room_cont_sebo:
		ScriptFade(Room_MG_paudesebo, 30, c_black)
	break;
}