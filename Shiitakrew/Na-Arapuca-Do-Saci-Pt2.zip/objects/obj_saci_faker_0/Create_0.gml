image_xscale = 2
image_yscale = 2

// Inherit the parent event
event_inherited();

target = obj_player
vel_spin = 2
angle_spin = 0
distance_spin = 120
x = target.x + lengthdir_x(distance_spin, angle_spin)
y = target.y + lengthdir_y(distance_spin, angle_spin)