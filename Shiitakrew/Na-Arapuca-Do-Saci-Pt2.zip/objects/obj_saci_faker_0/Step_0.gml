// Inherit the parent event
event_inherited();

if (instance_exists(target)){
	angle_spin += vel_spin
	
	x = target.x + lengthdir_x(distance_spin, angle_spin)
	y = target.y + lengthdir_y(distance_spin, angle_spin)
}