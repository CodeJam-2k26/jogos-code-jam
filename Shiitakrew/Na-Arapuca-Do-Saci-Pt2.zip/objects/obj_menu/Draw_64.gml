
//Definindo o Diametro:

var _larg = 360 / qtd;

//Desenhando o Texto do Menu:
for ( var i = 0; i < qtd; i++)
{
	var _dir = ( i - pos ) * _larg;
	
	var _x = room_width - 250 - lengthdir_x(200, _dir);
	var _y = room_height / 2 + ( i - pos ) * 50;	
	var _cor = c_black;
	
	var _h = alt_ini;
	var _w = larg_ini;
	
	//Sabendo qual é a caixa atual:
	if ( i == indice )
	{
		_cor = c_white;
		_h = alt;
		_w = larg;
		font_enable_effects(fnt_result_screen, true, 
		{
		outlineEnable: true,
		outlineDistance: 2,
		outlineColour: c_black
		})
		draw_set_font(fnt_result_screen);
	}
	else{
		draw_set_font(fnt_ui);
	}
	
	//Desenhando a caixa das opções:
	draw_sprite_stretched( spr_Menu_panel, 0, _x - _w / 2, _y - _h / 2, _w, _h);

	
	
	draw_set_halign(1);
	draw_set_valign(1);
	draw_set_color(_cor);
	
	draw_text( _x, _y, menu[i] ); 
	
	//Resetando os Draw Sets
	draw_set_font(-1);
	draw_set_halign(-1);
	draw_set_valign(-1);
	draw_set_color(-1);
	font_enable_effects(fnt_ui, false)
}