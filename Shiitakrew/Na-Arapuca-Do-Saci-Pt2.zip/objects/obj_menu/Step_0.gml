//Mexendo o Menu
var _up = keyboard_check_pressed( vk_up );
var _down = keyboard_check_pressed( vk_down );

var _input = _down - _up;

if ( _input != 0 )
{
	
	indice += _input;
	
	larg = larg_ini;
	alt = alt_ini;
	
	audio_play_sound( Snd_Option, 0, 0 );
	
}

//Voltando para o início quando eu chego ao fim do menu:

if ( indice > qtd - 1 ) indice = 0;
if ( indice < 0 ) indice = qtd - 1;

larg = lerp( larg, larg_fim, .3 );

if ( larg > larg_fim - 4 )
{

alt = lerp(alt, alt_fim, .1 );

}

//Fazendo o Pos chegar o Indice

pos = lerp( pos, indice, .1 );
