//iniciando o Menu:

menu = ["Principal", "Minigames", "Equipe", "Sair"];
qtd = 4;

//Preenchendo o Menu:

for ( var i = 0; i < qtd; i++)
{
	menu[i] = menu[i];
}

//Posição selecionada do Menu:

indice = 15;

//Posição espacial do Menu:
pos = indice;

//Definindo a Largura e Altura da caixa do menu
//Valores Finais:

larg_fim = 360;
alt_fim = 120;

//Valores Atuais:

larg = larg_fim;
alt = alt_fim;



//Valores quando ele não está selecionado:

larg_ini = larg_fim / 2;
alt_ini = alt_fim / 2;


