if ( indice == 0 )
{
	ScriptFade(RoomPrologo, 30, c_black)
}

else if ( indice == 1 )
{
	ScriptFade(Room_minigames, 30, c_black)
}

else if ( indice == 2 )
{
	ScriptFade(RoomEquipe, 30, c_black)
}

else if ( indice == 3 )
{
	game_end();
}