instance_destroy();

