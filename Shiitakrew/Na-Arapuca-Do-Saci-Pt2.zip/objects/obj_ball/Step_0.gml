if ( global.start_pong == true and !global.jogo_acabou) {
	
if (!comecou)
{
    comecou = true;
    hspeed = choose(10, -10);
}


if ( bbox_bottom > room_height ) or ( bbox_top < 0 ) vspeed = -vspeed;

if (bbox_right < 0) {
	    global.ponto_bot += 1;
	    x = room_width * 0.5;
	    y = room_height * 0.5;
	    hspeed = 10;
	    vspeed = random_range(-5, 5);
	
		  if (global.ponto_bot >= 7) {
			audio_play_sound(snd_glass, 10, false)
	        global.jogo_acabou = true;
	        global.vencedor_pong = "BOT";
			estado = "perdeu"
		}
	
}

if (bbox_left > room_width) {
	    global.ponto_player += 1;
	    x = room_width * 0.5;
	    y = room_height * 0.5;
	    hspeed = -10;
	    vspeed = random_range(-5, 5);
	
		 if (global.ponto_player >= 7) {
			audio_play_sound(snd_intro, 10, false)
	        global.jogo_acabou = true;
	        global.vencedor_pong = "PLAYER";
			estado = "ganhou"
		}
}
	

}

if(global.jogo_acabou){
		
		   if (keyboard_check_pressed(vk_down))
		{
		    cont++;
		    if (cont > 2) cont = 2;
		}

		if (keyboard_check_pressed(vk_up))
		{
		    cont--;
		    if (cont < 0) cont = 0;
		}

		if (keyboard_check_pressed(vk_enter))
		{
		    if (cont == 0) room_restart();
		    if (cont == 1) ScriptFade(Room_saci, 30, c_black);   //TROCAR ROOM
		    if (cont == 2) ScriptFade(RoomMenu, 30, c_black);      //TROCAR ROOM
		}
		hspeed = 0
		vspeed = 0
		if (global.jogo_acabou == true) exit;
	}
	