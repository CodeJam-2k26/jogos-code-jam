draw_set_font(fnt_result_screen)

if (global.jogo_acabou == true)
{
	
	draw_set_halign( fa_center )
	
    if (estado == "ganhou") draw_text(display_get_gui_width() / 2, 340, "GANHOU!");
    if (estado == "perdeu") draw_text(display_get_gui_width() / 2, 340, "PERDEU!");

    for (var i = 0; i < 3; i++)
    {
        if (i == cont) draw_set_color(c_yellow);
        else draw_set_color(c_white);
		
        draw_text( display_get_gui_width() / 2 , 500 + i * 30, opcoes[i]);
    }

    draw_set_color(c_white);
}

draw_set_halign(fa_left);