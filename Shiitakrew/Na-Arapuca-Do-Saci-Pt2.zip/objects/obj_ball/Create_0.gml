
randomize()
hspeed = 0;
comecou = false;

if (!variable_global_exists("ponto_player")) {
    global.ponto_player = 0;
    global.ponto_bot = 0;
}

estado = "jogando";

cont = 0;
opcoes = ["Jogar Novamente", "Continuar", "Voltar para o Menu"];
