

instance_destroy();

global.acertos_cactos++