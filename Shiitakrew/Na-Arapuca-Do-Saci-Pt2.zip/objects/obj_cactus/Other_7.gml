if ( agindo == "descendo" )
{
	instance_destroy();
	global.perdas_cactos++
}