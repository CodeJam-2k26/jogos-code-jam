agindo = "descendo";

image_speed = -1;