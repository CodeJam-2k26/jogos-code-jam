if(image_yscale < 1) image_yscale = lerp(image_yscale, 1, 0.3)
if ( agindo == "subindo" )
{
	if (image_index >= image_number - 1)
	{
	    image_index = image_number - 1;
	    image_speed = 0;
	}
}