agindo = "subindo"
image_yscale = 0
image_speed = 1;

alarm[0] = room_speed * 1;