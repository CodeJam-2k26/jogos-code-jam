var _musica_atual

switch (room){
	case RoomMenu:
		_musica_atual = snd_background_menu
		if(!audio_is_playing(_musica_atual)){
			audio_stop_all()
			audio_play_sound(_musica_atual, 10, true)
		}
	break;
	
	case Room_cont_cacto:
		_musica_atual = snd_background_menu
		if(!audio_is_playing(_musica_atual)){
			audio_stop_all()
			audio_play_sound(_musica_atual, 10, true)
		}
	break;
	
	case Room_cont_pesca:
		_musica_atual = snd_background_menu
		if(!audio_is_playing(_musica_atual)){
			audio_stop_all()
			audio_play_sound(_musica_atual, 10, true)
		}
	break;
	
	case Room_cont_sebo:
		_musica_atual = snd_background_menu
		if(!audio_is_playing(_musica_atual)){
			audio_stop_all()
			audio_play_sound(_musica_atual, 10, true)
		}
	break;
	
	case Room_cont_laco:
		_musica_atual = snd_background_menu
		if(!audio_is_playing(_musica_atual)){
			audio_stop_all()
			audio_play_sound(_musica_atual, 10, true)
		}
	break;
	
	case Room_cont_pong:
		_musica_atual = snd_background_menu
		if(!audio_is_playing(_musica_atual)){
			audio_stop_all()
			audio_play_sound(_musica_atual, 10, true)
		}
	break;
	
	case Room_saci:
		_musica_atual = snd_background_fight1
		if(!audio_is_playing(_musica_atual)){
			audio_stop_all()
			audio_play_sound(_musica_atual, 10, true)
		}
	break;
	
	case Room_saci_final:
		_musica_atual = snd_background_fight2
		if(!audio_is_playing(_musica_atual)){
			audio_stop_all()
			audio_play_sound(_musica_atual, 10, true)
		}
	break;
	
	case RoomMiniNordeste:
		_musica_atual = snd_background_MgNordeste
		if(!audio_is_playing(_musica_atual)){
			audio_stop_all()
			audio_play_sound(_musica_atual, 10, true)
		}
	break;
	
	case RoomSul:
		_musica_atual = snd_background_MgSul
		if(!audio_is_playing(_musica_atual)){
			audio_stop_all()
			audio_play_sound(_musica_atual, 10, true)
		}
	break;
	
	case Room_MG_Pong:
		_musica_atual = snd_background_MgSudeste
		if(!audio_is_playing(_musica_atual)){
			audio_stop_all()
			audio_play_sound(_musica_atual, 10, true)
		}
	break;
	
	case Room_MG_Pesca:
		_musica_atual = snd_background_MgCentrooeste
		if(!audio_is_playing(_musica_atual)){
			audio_stop_all()
			audio_play_sound(_musica_atual, 10, true)
		}
	break;
	
	case Room_MG_paudesebo:
		_musica_atual = snd_background_MgNorte
		if(!audio_is_playing(_musica_atual)){
			audio_stop_all()
			audio_play_sound(_musica_atual, 10, true)
		}
	break;
}

