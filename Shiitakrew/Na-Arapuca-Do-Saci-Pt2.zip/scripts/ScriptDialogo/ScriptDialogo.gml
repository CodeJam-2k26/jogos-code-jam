function scr_dialogo(){
	switch npc_nome {
		
		case "npcguy01":
			ds_grid_add_text("...Quem diacho é tu homi?", spr_chico_speak, 9, 0, "Chico")
			ds_grid_add_text("Olá Companheiro! Meu nome é Tregas... Sou um placeholder neste mundo virtual tão maravilhoso... E agora estouo dizendo coisas aleatórias para testar a caixa de dialogo!!! O ciclo de vida de uma tartaruga marinha compreende quatro fases principais: a desova e incubação, o nascimento e corrida ao mar, a fase juvenil no oceano e a fase adulta com reprodução.", spr_npcguy_speak, 0, 1, "Tregas")
		break;
		
		case "john_npc":
			ds_grid_add_text("...Louro?", spr_chico_speak, 9, 0, "Chico")
			ds_grid_add_text("Cebolas HAHAHHAHAHAHAHHAAHHAHAH", spr_john_npc_speak, 0, 1, "JohnNPC")
		break;
		
	}
}

function ds_grid_add_row()
{
	
var grid = argument[0];
ds_grid_resize( grid,ds_grid_width( grid),ds_grid_height( grid)+1);
return(ds_grid_height( grid)-1); //Adicionando linhas ao Grid

}

function ds_grid_add_text(){

var grid = texto_grid;
var _y = ds_grid_add_row(grid);

grid[# 0, _y] = argument[0];
grid[# 1, _y] = argument[1];
grid[# 2, _y] = argument[2];
grid[# 3, _y] = argument[3];
grid[# 4, _y] = argument[4];


}