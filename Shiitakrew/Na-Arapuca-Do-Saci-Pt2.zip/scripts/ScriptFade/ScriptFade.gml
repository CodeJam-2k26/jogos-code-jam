function ScriptFade(){
	///@arg room
	///@arg duração
	///@arg cor
	
	//Argumentos
	
	var _room = argument[0]
	var _dur = argument[1]
	var _cor = argument[2]
	
	//Criar
	var _inst = instance_create_depth(0, 0, 0, obj_transicao)
	
	//Propriedades
	
	with (_inst) {
		alvo = _room
		duracao = _dur
		cor = _cor
	}
}