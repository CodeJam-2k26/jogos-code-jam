function scr_textos(){
	switch npc_nome{
	
		case "npcman01":
			texto[0] = "Olá companheiro, sou um [PLACEHOLDER]"
		break;
	
	
	
	
	
	
	}
}