if (array_contains(global.cogumelos_pego, id_cogumelo))
{
    instance_destroy();
}
else if (place_meeting(x, y, Obj_player))
{
    global.cogumelos += 1;
    array_push(global.cogumelos_pego, id_cogumelo);
    audio_play_sound(Som_Coleta, 1, false);
    instance_destroy();
}
