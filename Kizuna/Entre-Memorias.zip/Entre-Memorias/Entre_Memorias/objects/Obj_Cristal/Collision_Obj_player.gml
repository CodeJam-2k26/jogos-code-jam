if (!global.tem_cristal &&
    !global.cristal_altar_aceso)
{
    global.tem_cristal = true;

    if (!global.dialogo_aberto)
    {
        var _caixa = instance_create_layer(0, 0, layer, Obj_Dialogo);

        _caixa.nome_interacao = "Narrador";
        _caixa.sprite_retrato = -1;
        _caixa.texto_array = [
            "Você encontrou um cristal antigo.",
            "Talvez ele pertença ao altar do Templo de Cristal."
        ];
        _caixa.nomes_array = ["Narrador", "Narrador"];
        _caixa.pagina_atual = 0;
    }

    instance_destroy();
}
