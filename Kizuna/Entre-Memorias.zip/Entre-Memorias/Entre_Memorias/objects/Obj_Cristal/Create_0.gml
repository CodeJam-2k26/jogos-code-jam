if (global.tem_cristal || global.cristal_altar_aceso)
{
    instance_destroy();
}
