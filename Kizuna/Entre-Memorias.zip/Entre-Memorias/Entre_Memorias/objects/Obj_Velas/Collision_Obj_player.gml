if (global.cogumelos >= 6 &&
    id_vela >= 1 &&
    id_vela <= 6 &&
    !global.velas_acesas[id_vela])
{
    global.velas_acesas[id_vela] = true;

    if (global.velas_acesas[1] &&
        global.velas_acesas[2] &&
        global.velas_acesas[3] &&
        global.velas_acesas[4] &&
        global.velas_acesas[5] &&
        global.velas_acesas[6])
    {
        global.templo_velas_aceso = true;

        if (!global.dialogo_aberto)
        {
            var _caixa = instance_create_layer(
                0, 0, layer, Obj_Dialogo
            );

            _caixa.nome_interacao = "Narrador";
            _caixa.sprite_retrato = -1;

            _caixa.texto_array = [
                "A sexta chama se acende.",
                "As velas iluminam o altar, e uma luz envolve todo o templo."
            ];

            _caixa.nomes_array = [
                "Narrador",
                "Narrador"
            ];

            _caixa.pagina_atual = 0;
        }
    }
}