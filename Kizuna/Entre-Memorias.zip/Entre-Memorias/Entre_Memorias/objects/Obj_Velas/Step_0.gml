if (global.velas_acesas[id_vela])
{
    if (sprite_index != Spr_Vela_Acesa)
    {
        sprite_index = Spr_Vela_Acesa;
        image_speed = 1;
    }
}
else if (sprite_index != Spr_Vela_Apagada)
{
    sprite_index = Spr_Vela_Apagada;
    image_speed = 0;
}
