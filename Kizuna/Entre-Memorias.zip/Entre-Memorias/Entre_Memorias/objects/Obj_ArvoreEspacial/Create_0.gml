// Opacidade padrão (100% visível)
alpha_normal = 1.0; 

// Opacidade quando o jogador estiver atrás (Ex: 40% visível)
alpha_transparente = 0.4; 

// Velocidade do efeito de fade (suavização)
velocidade_fade = 0.1; 

// Define o alpha inicial
image_alpha = alpha_normal;
