if (!instance_exists(Obj_player))
{
    exit;
}

if (Obj_player.y < y &&
    Obj_player.x > x - 40 &&
    Obj_player.x < x + 40)
{
    image_alpha = lerp(image_alpha, alpha_transparente, 0.05);
}
else
{
    image_alpha = lerp(image_alpha, alpha_normal, 0.05);
}
