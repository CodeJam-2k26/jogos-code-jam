if (!variable_global_exists("falou_amelia"))
{
    global.falou_amelia = false;
}
