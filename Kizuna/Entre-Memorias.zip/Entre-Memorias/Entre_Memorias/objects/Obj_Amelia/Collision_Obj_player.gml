if (!global.falou_amelia && !instance_exists(Obj_Dialogo))
{
    var _caixa = instance_create_layer(0, 0, layer, Obj_Dialogo);

    _caixa.nome_interacao = "Amelia";
    _caixa.sprite_retrato = -1;

    _caixa.texto_array = [
        "Bienvenido, caminante!",
        "Sua memória desapareceu..",
		"Mas isso não significa que o passado deixou de existir.",
        "Então existe uma maneira de recuperar minhas lembrancas?",
        "Talvez..",
		"Dois templos antigos guardam vestigios...",
		"..do que foi esquecido..",
		"o brilho das pedras e a luz das velas.",
        "Que debo hacer? ",
        "Observe os altares. Não tenha pressa.",
		"Poco a poco, as lembrancas encontrarão o caminho.",
        "E se eu não gostar do que encontrar?",
        "La verdad puede doler...",
		"Mas só voce pode decidir o que fará com ela.."
    ];

    _caixa.nomes_array = [
        "Amelia",
        "Amelia",
        "Amelia",
        "Elian",
        "Amelia",
        "Amelia",
        "Amelia",
        "Amelia",
        "Elian",
        "Amelia",
        "Amelia",
        "Elian",
        "Amelia",
        "Amelia"
    ];

    _caixa.pagina_atual = 0;

    global.falou_amelia = true;
}