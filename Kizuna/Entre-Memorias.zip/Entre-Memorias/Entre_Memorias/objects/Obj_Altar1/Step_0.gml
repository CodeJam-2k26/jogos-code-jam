if (global.templo_velas_aceso && sprite_index != Spr_Templo1_Aceso)
{
    sprite_index = Spr_Templo1_Aceso;
    image_index = 0;
    image_speed = 0.15;
    audio_play_sound(Som_Ativacao, 1, false);
}
