image_speed = 0;

if (global.templo_velas_aceso)
{
    sprite_index = Spr_Templo1_Aceso;
    image_speed = 0.15;
}
