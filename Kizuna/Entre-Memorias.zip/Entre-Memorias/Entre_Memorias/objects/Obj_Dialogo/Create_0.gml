texto_array = [""];
nomes_array = [];

pagina_atual = 0;
nome_interacao = "";
sprite_retrato = -1;

global.dialogo_aberto = true;