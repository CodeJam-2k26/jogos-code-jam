// Protege o dialogo contra arrays vazios ou pagina fora dos limites.
var _total = array_length(texto_array);

if (_total <= 0)
{
    global.dialogo_aberto = false;
    instance_destroy();
    exit;
}

pagina_atual = clamp(pagina_atual, 0, _total - 1);

if (keyboard_check_pressed(vk_space) || keyboard_check_pressed(vk_enter))
{
    if (pagina_atual < _total - 1)
    {
        pagina_atual++;
        audio_play_sound(Som_Dialogo, 1, false);
    }
    else
    {
        global.dialogo_aberto = false;
        instance_destroy();
    }
}
