var _total = array_length(texto_array);
if (_total <= 0) exit;

pagina_atual = clamp(pagina_atual, 0, _total - 1);

var largura = display_get_gui_width();
var altura = display_get_gui_height();
var cx = round((largura - sprite_get_width(Spr_Dialogo)) / 2);
var cy = round(altura - sprite_get_height(Spr_Dialogo) - 16);

draw_sprite(Spr_Dialogo, 0, cx, cy);
draw_set_font(Fnt_Dialogo);
draw_set_color(c_white);

if (array_length(nomes_array) == _total)
{
    draw_text(cx + 24, cy + 12, nomes_array[pagina_atual]);
}
else
{
    draw_text(cx + 24, cy + 12, nome_interacao);
}

draw_text_ext(
    cx + 24,
    cy + 36,
    texto_array[pagina_atual],
    20,
    sprite_get_width(Spr_Dialogo) - 48
);
draw_set_color(c_white);
