if (!global.falou_mirasol && !instance_exists(Obj_Dialogo))
{
    var _caixa = instance_create_layer(0, 0, layer, Obj_Dialogo);

    _caixa.nome_interacao = "Mirasol";
    _caixa.sprite_retrato = -1;

    _caixa.texto_array = [
        "Ay,que alivio! Você acordou!",
        "Encontrei você perto do caminho.",
		"Não sabia se acordaria..",
        "Recuerdas tu nombre?",
        "Não... nao lembro de nada.",
		"¿Donde estoy?",
        "Você esta numa vila.",
		"Calma, poco a poco, vamos..",
		"Entender o que aconteceu.",
		"Após as ofrendas",
        "Ofrendas?",
        "Si!Estamos preparando as ofrendas!",
		"Para o Dia de Los  Muertos!",
		"Dizem que as flores de cempasuchil",
		"Guiam os espiritos ate os altares.",
        "Será que minhas lembranças..",
		"Também estão escondidas neste lugar?",
        "Não sei..Mas a anciã conhece as histórias antigas.",
		"Talvez ela possa ajudar você.",
        "Vou falar com ela. Gracias por me ajudar."
    ];

   _caixa.nomes_array = [
    "Mirasol", 
    "Mirasol", 
    "Mirasol",
    "Mirasol", 
    "Elian",   
    "Elian",   
    "Mirasol", 
    "Mirasol", 
    "Mirasol", 
    "Mirasol",
    "Elian",   
    "Mirasol", 
    "Mirasol",
    "Mirasol", 
    "Mirasol", 
    "Elian",   
    "Elian",   
    "Mirasol",
    "Mirasol",
    "Elian"    
];

    _caixa.pagina_atual = 0;

    global.falou_mirasol = true;
}