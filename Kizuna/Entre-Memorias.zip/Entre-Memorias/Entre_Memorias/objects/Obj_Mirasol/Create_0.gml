if (!variable_global_exists("falou_mirasol"))
{
    global.falou_mirasol = false;
}
