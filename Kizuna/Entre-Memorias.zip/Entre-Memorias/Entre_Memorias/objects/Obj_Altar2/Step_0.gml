if (global.tem_cristal &&
    !global.cristal_altar_aceso &&
    !global.dialogo_aberto &&
    instance_exists(Obj_player) &&
    distance_to_object(Obj_player) < 24)
{
    global.tem_cristal = false;
    global.cristal_altar_aceso = true;

    sprite_index = Spr_Templo2_Aceso;
    image_index = 0;
    image_speed = 0.15;
    audio_play_sound(Som_Ativacao, 1, false);

    var _caixa = instance_create_layer(0, 0, layer, Obj_Dialogo);
    _caixa.nome_interacao = "Narrador";
    _caixa.sprite_retrato = -1;
    _caixa.texto_array = [
        "Você coloca o cristal sobre o altar.",
        "Uma luz violeta percorre as pedras. O altar desperta!"
    ];
    _caixa.nomes_array = ["Narrador", "Narrador"];
    _caixa.pagina_atual = 0;
}
