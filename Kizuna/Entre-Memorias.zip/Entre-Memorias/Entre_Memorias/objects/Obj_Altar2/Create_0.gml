image_speed = 0;

if (global.cristal_altar_aceso)
{
    sprite_index = Spr_Templo2_Aceso;
    image_speed = 0.15;
}
