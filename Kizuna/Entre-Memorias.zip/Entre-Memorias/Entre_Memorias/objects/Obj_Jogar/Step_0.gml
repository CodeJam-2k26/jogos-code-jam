var largura = display_get_gui_width();
var altura = display_get_gui_height();

var centro_x = largura / 2;
var centro_y = altura * 0.78;

var mouse_x_gui = device_mouse_x_to_gui(0);
var mouse_y_gui = device_mouse_y_to_gui(0);


if (mouse_check_button_pressed(mb_left) &&
    point_in_rectangle(
        mouse_x_gui,
        mouse_y_gui,
        centro_x - 110,
        centro_y - 28,
        centro_x + 110,
        centro_y + 28
    ))
{
    room_goto(Rm_Casa);
    exit;
}