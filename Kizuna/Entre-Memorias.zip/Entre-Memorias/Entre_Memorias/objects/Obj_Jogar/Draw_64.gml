var largura = display_get_gui_width();
var altura = display_get_gui_height();


var centro_x = largura / 2;
var centro_y = altura * 0.78;


var x1 = centro_x - 110;
var y1 = centro_y - 28;
var x2 = centro_x + 110;
var y2 = centro_y + 28;


var mouse_x_gui = device_mouse_x_to_gui(0);
var mouse_y_gui = device_mouse_y_to_gui(0);


var mouse_sobre = point_in_rectangle(
    mouse_x_gui, mouse_y_gui,
    x1, y1, x2, y2
);


draw_set_color(make_color_rgb(100, 45, 25));
draw_rectangle(x1, y1 + 5, x2, y2 + 5, false);


if (mouse_sobre)
{
    draw_set_color(make_color_rgb(245, 140, 50));
}
else
{
    draw_set_color(make_color_rgb(205, 95, 35));
}

draw_rectangle(x1, y1, x2, y2, false);


draw_set_color(make_color_rgb(255, 215, 140));
draw_rectangle(x1, y1, x2, y2, true);


draw_set_font(Fnt_Dialogo);
draw_set_halign(fa_center);
draw_set_valign(fa_middle);
draw_set_color(c_white);

draw_text(centro_x, centro_y, "JOGAR");

draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_set_color(c_white);