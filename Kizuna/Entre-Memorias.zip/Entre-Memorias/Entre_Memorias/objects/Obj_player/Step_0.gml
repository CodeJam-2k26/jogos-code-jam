if (global.transicao_ativa)
{
    if (passo_som != -1)
    {
        audio_stop_sound(passo_som);
        passo_som = -1;
    }

    exit;
}

if (global.dialogo_aberto)
{
    estado = "idle";
    sprite_index = Spr_Player_Parado;
    image_speed = 0.9;

    if (passo_som != -1)
    {
        audio_stop_sound(passo_som);
        passo_som = -1;
    }

    exit;
}

var _x_inicio = x;
var _y_inicio = y;

if (estado == "idle")
{
    if (keyboard_check(vk_up) ||
        keyboard_check(vk_down) ||
        keyboard_check(vk_left) ||
        keyboard_check(vk_right))
    {
        estado = "walk";
    }
}


if (estado == "walk")
{
   if (keyboard_check(vk_up))
{
    if (!place_meeting(x, y - velocidade, Obj_Colisao) &&
        !place_meeting(x, y - velocidade, Obj_Arvore)) 
       
    {
        y -= velocidade;
    }

    direcao = "cima";
}

    if (keyboard_check(vk_down))
{
    if (!place_meeting(x, y + velocidade, Obj_Colisao) &&
        !place_meeting(x, y + velocidade, Obj_Arvore) 
        )
    {
        y += velocidade;
    }

    direcao = "baixo";
}

   if (keyboard_check(vk_left))
{
    if (!place_meeting(x - velocidade, y, Obj_Colisao) &&
        !place_meeting(x - velocidade, y, Obj_Arvore))
    {
        x -= velocidade;
    }
	
	

    direcao = "esquerda";
}

   if (keyboard_check(vk_right))
{
    if (!place_meeting(x + velocidade, y, Obj_Colisao) &&
        !place_meeting(x + velocidade, y, Obj_Arvore))
    {
        x += velocidade;
    }

    direcao = "direita";
}

    if (!keyboard_check(vk_up) &&
        !keyboard_check(vk_down) &&
        !keyboard_check(vk_left) &&
        !keyboard_check(vk_right))
    {
        estado = "idle";
    }
}


if (estado == "idle")
{
    sprite_index = Spr_Player_Parado;
    image_speed = 0.90;
}


if (estado == "walk")
{
    if (direcao == "cima")
    {
        sprite_index = Spr_Player_Cima;
    }

    if (direcao == "baixo")
    {
        sprite_index = Spr_Player_Baixo;
    }

    if (direcao == "esquerda")
    {
        sprite_index = Spr_Player_Esquerda;
    }

    if (direcao == "direita")
    {
        sprite_index = Spr_Player_Direita;
    }

    image_speed = 0.90;
}

if (x != _x_inicio || y != _y_inicio)
{
    if (passo_som == -1 || !audio_is_playing(passo_som))
    {
        passo_som = audio_play_sound(Som_Passos, 1, true);
    }
}
else if (passo_som != -1)
{
    audio_stop_sound(passo_som);
    passo_som = -1;
}


if (!global.transicao_ativa && room == Rm_Casa)
{
    if (place_meeting(x, y, Obj_Porta_Casa_Vila))
    {
        global.origem = "casa";
        global.room_destino = Rm_Vila;
        global.transicao_ativa = true;

        instance_create_layer(x, y, layer, Obj_Transicao);
        exit;
    }
}


if (!global.transicao_ativa && room == Rm_Vila)
{
    if (place_meeting(x, y, Obj_Porta_Vila_Casa))
    {
        global.origem = "vila";
        global.room_destino = Rm_Casa;
        global.transicao_ativa = true;

        instance_create_layer(x, y, layer, Obj_Transicao);
        exit;
    }
}


if (!global.transicao_ativa && room == Rm_Vila)
{
    if (place_meeting(x, y, Obj_Porta_Vila_Caminho1))
    {
        global.origem = "vila_caminho1";
        global.room_destino = Rm_Caminho1;
        global.transicao_ativa = true;

        instance_create_layer(x, y, layer, Obj_Transicao);
        exit;
    }
}


if (!global.transicao_ativa && room == Rm_Caminho1)
{
    if (place_meeting(x, y, Obj_Porta_Caminho1_Vila))
    {
        global.origem = "caminho1_vila";
        global.room_destino = Rm_Vila;
        global.transicao_ativa = true;

        instance_create_layer(x, y, layer, Obj_Transicao);
        exit;
    }
}


if (!global.transicao_ativa && room == Rm_Caminho1)
{
    if (place_meeting(x, y, Obj_Porta_Caminho1_Caminho2))
    {
        global.origem = "caminho1_caminho2";
        global.room_destino = Rm_Caminho2;
        global.transicao_ativa = true;

        instance_create_layer(x, y, layer, Obj_Transicao);
        exit;
    }
}


if (!global.transicao_ativa && room == Rm_Caminho2)
{
    if (place_meeting(x, y, Obj_Porta_Caminho2_Caminho1))
    {
        global.origem = "caminho2_caminho1";
        global.room_destino = Rm_Caminho1;
        global.transicao_ativa = true;

        instance_create_layer(x, y, layer, Obj_Transicao);
        exit;
    }
}

if (!global.transicao_ativa && room == Rm_Caminho2)
{
    if (place_meeting(x, y, Obj_Porta_Caminho2_Cristal))
    {
        global.origem = "caminho2_cristal";
        global.room_destino = Rm_Templo_Cristal;
        global.transicao_ativa = true;

        instance_create_layer(x, y, layer, Obj_Transicao);
        exit;
    }
}

if (!global.transicao_ativa && room == Rm_Templo_Cristal)
{
    if (place_meeting(x, y, Obj_Porta_Cristal_Caminho2))
    {
        global.origem = "cristal_caminho2";
        global.room_destino = Rm_Caminho2;
        global.transicao_ativa = true;

        instance_create_layer(x, y, layer, Obj_Transicao);
        exit;
    }
}

if (!global.transicao_ativa && room == Rm_Vila)
{
    if (place_meeting(x, y, Obj_Porta_Vila_Caminho3))
    {
        global.origem = "vila_caminho3";
        global.room_destino = Rm_Caminho3;
        global.transicao_ativa = true;

        instance_create_layer(x, y, layer, Obj_Transicao);
        exit;
    }
}


if (!global.transicao_ativa && room == Rm_Caminho3)
{
    if (place_meeting(x, y, Obj_Porta_Caminho3_Vila))
    {
        global.origem = "caminho3_vila";
        global.room_destino = Rm_Vila;
        global.transicao_ativa = true;

        instance_create_layer(x, y, layer, Obj_Transicao);
        exit;
    }
}


if (!global.transicao_ativa && room == Rm_Caminho3)
{
    if (place_meeting(x, y, Obj_Porta_Caminho3_Caminho4))
    {
        global.origem = "caminho3_caminho4";
        global.room_destino = Rm_Caminho4;
        global.transicao_ativa = true;

        instance_create_layer(x, y, layer, Obj_Transicao);
        exit;
    }
}


if (!global.transicao_ativa && room == Rm_Caminho4)
{
    if (place_meeting(x, y, Obj_Porta_Caminho4_Caminho3))
    {
        global.origem = "caminho4_caminho3";
        global.room_destino = Rm_Caminho3;
        global.transicao_ativa = true;

        instance_create_layer(x, y, layer, Obj_Transicao);
        exit;
    }
}

if (!global.transicao_ativa && room == Rm_Caminho4)
{
    if (place_meeting(x, y, Obj_Porta_Caminho4_Velas))
    {
        global.origem = "caminho4_velas";
        global.room_destino = Rm_Templo_Velas;
        global.transicao_ativa = true;

        instance_create_layer(x, y, layer, Obj_Transicao);
        exit;
    }
}


if (!global.transicao_ativa && room == Rm_Templo_Velas)
{
    if (place_meeting(x, y, Obj_Porta_Velas_Caminho4))
    {
        global.origem = "velas_caminho4";
        global.room_destino = Rm_Caminho4;
        global.transicao_ativa = true;

        instance_create_layer(x, y, layer, Obj_Transicao);
        exit;
    }
}

