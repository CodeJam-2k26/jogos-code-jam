if (instance_number(Obj_player) > 1)
{
    instance_destroy();
    exit;
}

persistent = true;

estado = "idle";
direcao = "baixo";
velocidade = 2;

if (!variable_global_exists("origem"))
{
    global.origem = "";
}

if (!variable_global_exists("cogumelos"))
{
    global.cogumelos = 0;
}

if (!variable_global_exists("cogumelos_pego"))
{
    global.cogumelos_pego = [];
}

if (!variable_global_exists("dialogo_aberto"))
{
    global.dialogo_aberto = false;
}

if (!variable_global_exists("tem_cristal"))
{
    global.tem_cristal = false;
}

if (!variable_global_exists("cristal_altar_aceso"))
{
    global.cristal_altar_aceso = false;
}

if (!variable_global_exists("velas_acesas"))
{
    global.velas_acesas = array_create(7, false);
}

if (!variable_global_exists("templo_velas_aceso"))
{
    global.templo_velas_aceso = false;
}

if (!variable_global_exists("transicao_ativa"))
{
    global.transicao_ativa = false;
}

passo_som = -1;