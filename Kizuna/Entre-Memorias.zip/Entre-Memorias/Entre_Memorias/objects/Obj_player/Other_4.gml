if (room == Rm_Vila)
{
    if (global.origem == "casa")
    {
        x = 335;
        y = 250;
    }
}

if (room == Rm_Casa)
{
    if (global.origem == "vila")
    {
        x = 480;
        y = 700;
    }
}

 if (global.origem == "caminho1_vila")
    {
        x = 1240;
        y = 320;
    }

    if (global.origem == "caminho3_vila")
    {
        x = 335;
        y = 740;
    }

if (room == Rm_Caminho1)
{
    if (global.origem == "vila_caminho1")
    {
        x = 100;
        y = 330;
    }

    if (global.origem == "caminho2_caminho1")
    {
        x = 680;
        y = 740;
    }
}

if (room == Rm_Caminho2)
{
    if (global.origem == "caminho1_caminho2")
    {
        x = 320;
        y = 80;
    }

    if (global.origem == "cristal_caminho2")
    {
        x = 1240;
        y = 600;
    }
}

if (room == Rm_Templo_Cristal)
{
    if (global.origem == "caminho2_cristal")
    {
        x = 140;
        y = 320;
    }
}

if (room == Rm_Caminho3)
{
    if (global.origem == "vila_caminho3")
    {
        x = 330;
        y = 80;
    }

    if (global.origem == "caminho4_caminho3")
    {
        x = 1240;
        y = 580;
    }
}

if (room == Rm_Caminho4)
{
    if (global.origem == "caminho3_caminho4")
    {
        x = 90;
        y = 280;
    }

    if (global.origem == "velas_caminho4")
    {
        x = 1200;
        y = 660;
    }
}

if (room == Rm_Templo_Velas)
{
    if (global.origem == "caminho4_velas")
    {
        x = 200;
        y = 300;
    }
}