// 1. Desativa o filtro de textura via código por segurança
gpu_set_texfilter(false);

// 2. Define o tamanho da resolução nativa (sua Câmera)
var _largura_base = 640;
var _altura_base = 384;

// 3. Redimensiona a superfície base onde o jogo é desenhado
surface_resize(application_surface, _largura_base, _altura_base);

// 4. Ajusta o tamanho real da janela para o seu Viewport (1280x768)
window_set_size(1280, 768);