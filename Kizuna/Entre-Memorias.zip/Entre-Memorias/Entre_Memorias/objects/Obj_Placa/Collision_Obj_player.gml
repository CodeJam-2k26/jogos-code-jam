if (!falou && !instance_exists(Obj_Dialogo))
{
    var _caixa = instance_create_layer(0, 0, layer, Obj_Dialogo);

    _caixa.nome_interacao = "Placa";
    _caixa.sprite_retrato = -1;
    _caixa.texto_array = minhas_falas;
    _caixa.pagina_atual = 0;

    falou = true;
}