minhas_falas = ["Esta é uma placa padrão."];
falou = false;
