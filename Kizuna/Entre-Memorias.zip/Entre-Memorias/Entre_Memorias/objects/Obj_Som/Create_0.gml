if (instance_number(Obj_Som) > 1)
{
    instance_destroy();
    exit;
}

persistent = true;

musica_id = -1;
musica_recurso_atual = -1;
