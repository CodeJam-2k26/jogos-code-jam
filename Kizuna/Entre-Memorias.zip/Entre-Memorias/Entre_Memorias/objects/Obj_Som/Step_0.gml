var musica_desejada = Som_Fundo;


if (room == Rm_Templo_Cristal ||
    room == Rm_Templo_Velas)
{
    musica_desejada = Som_Templo;
}


if (musica_desejada != musica_recurso_atual)
{
  
    if (musica_id != -1)
    {
        audio_stop_sound(musica_id);
    }

    musica_id = audio_play_sound(
        musica_desejada,
        0,
        true
    );

   
    audio_sound_gain(musica_id, 0.30, 0);

    musica_recurso_atual = musica_desejada;
}