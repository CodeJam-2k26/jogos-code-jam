persistent = true;

etapa = 0;
alpha_tela = 0;

if (variable_global_exists("room_destino"))
{
    room_destino = global.room_destino;
}
else
{
    room_destino = Rm_Casa;
}