// Transicao suave entre salas. A logica deve executar apenas uma vez por Step.
if (etapa == 0)
{
    alpha_tela = min(1, alpha_tela + 0.06);

    if (alpha_tela >= 1)
    {
        etapa = 1;
        room_goto(room_destino);
    }
}
else if (etapa == 1)
{
    alpha_tela = max(0, alpha_tela - 0.06);

    if (alpha_tela <= 0)
    {
        global.transicao_ativa = false;
        instance_destroy();
    }
}
