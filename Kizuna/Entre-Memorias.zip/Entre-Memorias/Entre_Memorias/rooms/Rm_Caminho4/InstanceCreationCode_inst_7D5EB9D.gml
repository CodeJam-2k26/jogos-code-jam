minhas_falas = [
    "Cada chama testemunhou algo que o tempo tentou apagar..",
	"Siga em frente",
	"Abre bien los ojos!.."
];