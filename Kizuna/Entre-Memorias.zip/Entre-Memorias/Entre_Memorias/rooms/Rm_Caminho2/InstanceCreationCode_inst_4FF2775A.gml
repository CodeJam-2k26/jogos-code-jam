minhas_falas = [
   "La memoria nunca desaparece del todo.",
   "Às vezes, espera por alguém que a encontre"
];


 