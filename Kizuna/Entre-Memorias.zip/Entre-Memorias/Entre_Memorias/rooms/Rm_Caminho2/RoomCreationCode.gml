minhas_falas = [
    "As pedras guardam ecos de quem passou por aqui. Algumas memórias ainda brilham em seu interior.",
    "O que foi perdido ainda pode ser encontrado.",
	"Mas você está preparado para se lembrar?"
];