minhas_falas = [
    "Entre raízes e sombras, pequeñas setas crecen longe da luz.",
    "Observe bem os arredores...",
    "Seis pequenos chapeus dormem escondidos sob as arvores.",
    "Tres en este sendero y tres en el siguiente.",
    "Encontre todos, e a floresta revelara seu segredo."
];
