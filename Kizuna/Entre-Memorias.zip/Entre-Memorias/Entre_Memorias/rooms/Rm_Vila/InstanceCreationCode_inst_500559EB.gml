minhas_falas = [
   "Além destas casas, os caminhos levam a lugares que poucos se atrevem a visitar",
   "Dos caminos se abren ante ti. Um guarda o brilho das pedras; o outro, a chama que nunca descansa.",
   "Nem tudo o que foi esquecido deixou de existir."
];