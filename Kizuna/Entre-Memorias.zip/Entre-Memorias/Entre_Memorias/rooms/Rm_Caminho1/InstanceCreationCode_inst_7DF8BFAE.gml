minhas_falas = [
    "A trilha parece familiar... No puedes recordar por qué...",
    "Siga em frente com cuidado.."
];