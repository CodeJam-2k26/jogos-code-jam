textos = [];
pag = 0;
fala_atual = noone;

nome_atual = "";
foto_atual = noone;
texto_atual = "";
direcao_atual = "";

opcoes_atuais = [];
desenhar_opcoes = false;
atual = 0;
margem = 0;

iniciar_dialogo = function(_array_dialogo)
{
    textos = _array_dialogo;
    pag = 0;
    atualiza_fala();
}

atualiza_fala = function()
{
    if (pag < array_length(textos))
    {
        fala_atual = textos[pag];
        nome_atual = fala_atual.nome;
        foto_atual = fala_atual.foto_dialogo;
        texto_atual = fala_atual.texto_dialogo;
        direcao_atual = fala_atual.direcao;
        
        // Verifica se esta fala tem a opcao 
        if (variable_struct_exists(fala_atual, "opcoes"))
        {
            opcoes_atuais = fala_atual.opcoes;
            desenhar_opcoes = true;
            atual = 0; 
        }
        else
        {
            opcoes_atuais = [];
            desenhar_opcoes = false;
        }
    }
    else
    {
        global.dialogo = false;
        instance_destroy();
    }
}

proxima_pagina = function()
{
    pag++;
    atualiza_fala();
}