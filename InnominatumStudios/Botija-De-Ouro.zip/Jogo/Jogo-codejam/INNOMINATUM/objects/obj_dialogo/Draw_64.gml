draw_set_font(fnt_dialogo);

//Desenhando a caixa de diálogo
var _larg = display_get_gui_width();
var _alt = display_get_gui_height();

var _marg = 10;
var _padd = 5;

var _caixa_larg = _larg;
var _caixa_alt = 200;

var _x1 = _marg;
var _x2 = _caixa_larg - _marg * 2;

var _y1 = _alt - _marg - _caixa_alt;
var _y2 = _y1 + _caixa_alt;

draw_sprite_stretched(spr_dialogo, 0, _x1, _y1, _x2, _caixa_alt);

var _txt_x = _x1 + _padd + 10;
var _txt_y = _y1 + _padd + 10;

//Desenhando o texto
draw_text_ext(_txt_x, _txt_y, texto_atual, 30, _caixa_larg - 30);

//desenhando o espaço do retrato
var _escala = 4;

var _larg_retrato = 38 * _escala;
var _alt_retrato = 38 * _escala;

var _ret_x = _larg - (_marg * 2) - _larg_retrato;
var _ret_y = _y1 - (_marg * 2) - _alt_retrato;

if(direcao_atual == "direita")
{
	draw_sprite_stretched(spr_dialogo, 0, _ret_x - _marg, _caixa_alt + 65, _larg_retrato + _marg * 2, 50);
	draw_text_ext(_ret_x - _marg + 40, _caixa_alt + 75, nome_atual, 30, _caixa_larg - 30);
	draw_sprite_stretched(spr_dialogo_moldura, 0, _ret_x - _marg, _ret_y - _marg - 5, _larg_retrato + _marg * 2, _alt_retrato + _marg * 2);
	draw_sprite_stretched(foto_atual, 0, _ret_x , _ret_y - 3, _larg_retrato, _alt_retrato);
}
else if(direcao_atual == "esquerda")
{
	draw_sprite_stretched(spr_dialogo, 0, _ret_x - _larg + _larg_retrato + 20 + _marg, _caixa_alt + 65, _larg_retrato + _marg * 2, 50);
	draw_text_ext(_ret_x - _larg + _larg_retrato + 65 + _marg, _caixa_alt + 75, nome_atual, 30, _caixa_larg - 30);
	draw_sprite_stretched(spr_dialogo_moldura, 0, _ret_x - _larg + _larg_retrato + 20 + _marg, _ret_y - _marg - 5, _larg_retrato + _marg * 2, _alt_retrato + _marg * 2);
	draw_sprite_stretched(foto_atual, 0, _ret_x - _larg + _larg_retrato + 32 + _marg, _ret_y - 3, _larg_retrato, _alt_retrato);
}

draw_set_font(-1);

if (desenhar_opcoes)
{
    for (var i = 0; i < array_length(opcoes_atuais); i++) {
        var _cor = c_white;
        draw_set_font(fnt_dialogo);
        var _altura = string_height("I");
        var _margem_op = 0;
    
        if (i == atual){
            _cor = c_red;
            _margem_op = margem;
        }
    
        draw_set_colour(_cor);
        draw_text(20 + _margem_op, 20 + _altura * i, opcoes_atuais[i].texto);
        
        draw_set_colour(-1);
        draw_set_font(-1);
    }
}