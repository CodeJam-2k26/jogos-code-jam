var _action = keyboard_check_pressed(ord("T"));
var _enter = keyboard_check_pressed(vk_enter);
var _up = keyboard_check_pressed(vk_up) or keyboard_check_pressed(ord("W"));
var _down = keyboard_check_pressed(vk_down) or keyboard_check_pressed(ord("S"));

if (desenhar_opcoes)
{
    if (_down) { atual++; margem = 0; }
    if (_up) { atual--; margem = 0; }
    
    atual = clamp(atual, 0, array_length(opcoes_atuais) - 1);
    margem = lerp(margem, 20, .2);
    
    if (_enter || _action) {
        opcoes_atuais[atual].funcao(); 
    }
}
else 
{
    if (_action || _enter) {
        proxima_pagina();
    }
}