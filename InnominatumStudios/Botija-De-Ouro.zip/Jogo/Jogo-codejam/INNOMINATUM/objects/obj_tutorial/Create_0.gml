alfa_texto = 1;
piscar = -0.05;

