if (keyboard_check_pressed(vk_enter))
{
  
    if (!instance_exists(obj_transicao)) 
    {
        var _trans = instance_create_depth(0, 0, -9999, obj_transicao);
        _trans.destino = rm_jogo;
    }
}