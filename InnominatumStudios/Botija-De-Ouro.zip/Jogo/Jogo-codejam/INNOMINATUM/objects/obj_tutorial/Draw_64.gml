var _meio_w = display_get_gui_width() / 2;
var _meio_h = display_get_gui_height() / 2;


draw_set_font(fnt_menu);
draw_set_halign(fa_center);
draw_set_valign(fa_middle);
draw_set_color(c_white);

draw_text(_meio_w, _meio_h - 100, "--- CONTROLES ---");

draw_text(_meio_w, _meio_h - 40, "W A S D / Setas - Movimento");
draw_text(_meio_w, _meio_h, "Espaço / J - Ataque Corpo-a-Corpo");
draw_text(_meio_w, _meio_h + 40, "TAB / L - Atirar");
draw_text(_meio_w, _meio_h + 80, "T / Enter - Falar com NPCS");

alfa_texto += piscar;
if (alfa_texto >= 1 || alfa_texto <= 0) piscar *= -1;

draw_set_color(c_yellow);
draw_set_alpha(alfa_texto);
draw_text(_meio_w, _meio_h + 160, "Pressione ENTER para jogar");
draw_set_alpha(1);

draw_set_color(c_white);
draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_set_font(-1);
