event_inherited();
//vida do boss
vida=3;


timer_ataque = 0;



#region //estado_idle
estado_idle.inicia=function()
{
	//definindo a sprite
	sprite_index=spr_idle;
	
	//iniciar animação no começo 
	image_index=0;
}

estado_idle.roda=function()
{
	// Diminui o timer de ataque gradativamente se for maior que zero
	if (timer_ataque > 0)
	{
		timer_ataque--;
	}

	//Checando se o player está na tela 
	if(instance_exists(obj_player) && global.vida_atual > 0)
	{
		// Se o timer zerou, ele ataca
		if (timer_ataque <= 0)
		{
			troca_estado(estado_attack);
		}
	}
}
#endregion


#region //esado_death
estado_death.inicia=function()
{
	//definindo a sprite
	sprite_index=spr_morte;
	
	//iniciar animação no começo 
	image_index=0;
}

estado_death.roda=function()
{
	if(image_index>=image_number-.5)
	{
		instance_destroy();
	}
	

}
#endregion 

#region //estado attack
estado_attack.inicia=function()
{
	
	sprite_index=spr_attack;
	
	//iniciar animação no começo 
	image_index=0;
	
	dano=noone;
	
}

estado_attack.roda=function()
{
	//Criando o dano 
		
	if(dano == noone)
	{
		
		dano=instance_create_depth(x-160,y, depth, obj_dano_boss2);
		
		dano.image_xscale = xscale;
	}
	
	if (image_index >=image_number-.5)
	{
		troca_estado(estado_idle);
	}
	
}
estado_attack.finaliza=function(){
	if(instance_exists(dano))
	{
	instance_destroy(dano);
	}
	dano=noone;
	timer_ataque = 240;
}

#endregion

#region //esado_hurt
estado_hurt.inicia=function()
{
	//definindo a sprite
	sprite_index=spr_idle;
	
	//iniciar animação no começo 
	image_index=0;
	
	//perdendo vida
	vida--;
	
	if (vida <= 0)
	{
		troca_estado(estado_death);
	}
}

estado_hurt.roda=function()
{
 
	//saindo do estado hurt
	//checando se a animação acabou 
	if(image_index>=image_number-.5)
	{	
		troca_estado(estado_idle);
	}
	

}
#endregion
