// pegando os inputs do usuário
up		=keyboard_check(vk_up) or keyboard_check(ord("W"));
down	=keyboard_check(vk_down) or keyboard_check(ord("S")); 
left	=keyboard_check(vk_left) or keyboard_check(ord("A"));
right	=keyboard_check(vk_right) or keyboard_check(ord("D"));
attack  =keyboard_check_pressed(vk_space) or keyboard_check(ord("J"));
tiro	=keyboard_check(vk_tab)or keyboard_check(ord("L"));

// Trava global do diálogo (congela as ações do player)
if (global.dialogo)
{
    velh = 0;
    velv = 0;

    return; // Cancela a execução do resto do Step
}

// Checkpoint de posição segura
if (global.vida_atual > 0) {
    global.safe_player_x = x;
    global.safe_player_y = y;
}
depth=-y;

// Rodando a minha maquina de estados 
roda_estado();
