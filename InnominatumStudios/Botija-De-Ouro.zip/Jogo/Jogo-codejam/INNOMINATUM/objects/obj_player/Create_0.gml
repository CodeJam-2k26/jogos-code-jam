//Iniciar variáveis
mask_index = spr_player_idle_front;

window_set_size(960, 675);

// Centraliza a janela na sua tela
window_center();

meu_dano=noone;
vida_inimigo=noone;
global.municao=noone;
global.armado=false;

global.dialogo=false;


if (instance_number(obj_player) > 1) {
    instance_destroy();
    exit;
}



#region // iniciando estados
//iniciando primeiro estado 
estado_idle= new estado();

//iniciando estado walk 
estado_walk=new estado();

//iniciando o estado de ataque 
estado_attack = new estado();

//estado de tiro
estado_tiro= new estado();

//estado hurt
estado_hit=new estado();

//estado death
estado_death=new estado();
#endregion

#region //estado idle
//Meu estado _idle precissa de um inicio 
estado_idle.inicia=function()
{ 
	//ajustando o sprite  
	sprite_index=spr_player_idle_front;
	
	//garantindo que a animação começo no primeiro frame 
	image_index=0;
}

estado_idle.roda=function()
{
 if(timer_ataque > 0) timer_ataque--;

 //se eu estiver em movimento 
 if ((right - left) != 0 || (down - up) != 0)
 {
	troca_estado(estado_walk);
 }
 
 // condição de attack 
 if (attack && timer_ataque <= 0)
 {
 troca_estado(estado_attack);
 }
 
 if(tiro){
 troca_estado(estado_tiro);
 }
}
#endregion

#region //estado walk 

estado_walk.inicia= function()
{
	dir=(point_direction(0, 0, right-left, down-up )div 90);
	//definindo a sprite 

	//configurando a sprit 
	sprite_index=spr_player_walk_front;
	
	//começando  a animação do começo 
	image_index=0;
}


estado_walk.roda = function() {
	if(timer_ataque > 0) timer_ataque--;
		
	velv=(down-up)*vel;
	velh=(right-left)*vel;
    
	
	if (velh == 0 && velv == 0) {
        troca_estado(estado_idle);
		return;
    }
	
	dir = (point_direction(0, 0, velh, velv) div 90);
	//Ajustando o lado que ele olha 
	if (velh!=0)
	{
		var _novo_scale = sign(velh);
		
		// Se ele mudou de direção
		if (image_xscale != _novo_scale) {
			// Aplica o empurrão de 2 pixels para longe da parede ANTES de mudar a escala
			x += _novo_scale * 2; 
			image_xscale = _novo_scale;
		}
	}

	
    // Condição para sair
	//se eu estou parado eu vou para o estado idle 
	
	if(attack && timer_ataque <= 0)
	{
		troca_estado(estado_attack)		
	}
}
#endregion

#region // estado attack
estado_attack.inicia=function()
{
	
	//ajustando o sprite  
	sprite_index=spr_player_attack_front;
	
	//garantindo que a animação começo no primeiro frame 
	image_index=0;
	
	velh=0;
	velv=0;

	//Tempo do timer de ataque (cooldown)
	timer_ataque = 15;
	
	//Criando o dano 
	var _x= x + lengthdir_x(16, dir*90);
	var _y= y + lengthdir_y (16, dir*90);


	meu_dano=instance_create_depth(_x,_y, depth, obj_dano);
	
	audio_play_sound(snd_attack, 1, false);
}

//saindo do estado attack

estado_attack.roda=function()
{	
	//compara o número de imagens com a imagem de ataque 
	if(image_index>=image_number-0.2)
	{
		troca_estado(estado_idle);	
	}
}
estado_attack.finaliza= function()
{
	//Encerro o meu dano 
	instance_destroy(meu_dano); 
	audio_stop_sound(snd_attack);
}

#endregion

#region //estado hit

estado_hit.inicia=function()
{
	velh=0;
	velv=0;
	global.vida_atual--;
	
}

estado_hit.roda=function()
{
	if (global.vida_atual>0)
	{
		troca_estado(estado_idle);
	}
	else
	{
		troca_estado(estado_death);
	}
}

#endregion

#region // estado tiro
	estado_tiro.inicia=function()
	{
	//ajustando o sprite  
	sprite_index=definindo_sprite(dir, spr_player_attack_side,spr_player_attack_front, spr_player_attack_back)
	
	//garantindo que a animação começo no primeiro frame 
	image_index=0;
	
	velh=0;
	velv=0;	
	
	var _x=x+lengthdir_x(30, dir*90);
	var _y=y+lengthdir_y(28, dir*90);
	
	
	if(global.armado==true and global.municao>0 &&image_index!=spr_player_attack_back && dir*90!=90){
	
	
	var _tiro=instance_create_depth(_x,_y,depth+1, obj_tiro);
	
	
	// Define a direção exata para onde o tiro deve ir 
	_tiro.direction = dir * 90;
	
	//definada a velocidade 
	_tiro.speed=vel_tiro;
	
	global.municao--;
	
	audio_play_sound(snd_tiro,1,false);
	}
	}
	
	
estado_tiro.roda=function()
{	
	//compara o número de imagens com a imagem de ataque 
	if(image_index>=image_number-0.2)
	{
		troca_estado(estado_idle);	
		audio_stop_sound(snd_tiro);
	}
}
#endregion

#region //esado_death
estado_death.inicia=function()
{
	
	//definindo a sprite
	sprite_index=spr_player_death;
	
	//iniciar animação no começo 
	image_index=0;
}

estado_death.roda = function()
{
    // avisa o controlador 
    with(obj_game_controller)
    {
        global.game_over = true;
    }

    // quando a animação chegar ao fim destrói o player 
    if(image_index >= image_number - 0.5)
    {
		audio_stop_all(); 
        
        audio_play_sound(snd_musica_morte, 1, false);
        instance_destroy();
    }
}

#endregion

#region // iniciando variáveis 



matar_player = function() {
    troca_estado(estado_death);
}


//Controles sendo iniciados sem valor 

up=noone;
down=noone;
left=noone;
right=noone;
attack=noone;
tiro=noone;
//Variáveis de movimento
//iniciando parado 

velh=0;
velv=0;


//velocidade do jogador
vel=2;

//velocidade do tiro
vel_tiro=3;

//controlando a direção que o player está olhando 
dir =0;

//vida do player 
global.vida_atual = 2;
global.vida_maxima=2;

//timer do golpe
timer_ataque = 0;


#endregion


//inicia minha maquina de estados 
inicia_estado(estado_idle);