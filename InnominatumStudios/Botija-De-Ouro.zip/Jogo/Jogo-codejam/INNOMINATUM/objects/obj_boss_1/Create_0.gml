event_inherited()

estado_espera=new estado();


//vida do boss
vida=3;

//velocidades 
max_velh=3;
max_velv=3;


timer_estado=random_range(2 , 3);


ataque=irandom(2);




#region //estado_idle
estado_idle.inicia=function()
{
	
	//logica do estado 
	
	//definindo a sprite
	sprite_index=spr_idle_m;
	
		
	//iniciar animação no começo 
	image_index=0;
	
	
}

estado_idle.roda=function()
{
	//Checando se o player está na tela 
	
	if(instance_exists(obj_player) && global.vida_atual>0)
	{
		//se o player estiver perto do boss 
		
		var _dist=point_distance(x, y, obj_player.x, obj_player.y);
		if(_dist<300){
				troca_estado(estado_walk);
		}

	}
		
}

#endregion

#region //esado_walk
estado_walk.inicia=function()
{
	//esse estado de caçar o playe
	//definindo a sprite
	sprite_index=spr_walk_m;
	
	//iniciar animação no começo 
	image_index=0;
}

estado_walk.roda=function()
{
	if(!instance_exists(obj_player)	)
	{	
		troca_estado(estado_idle);
		return;
	}
		
	var _dir =point_direction(x, y, obj_player.x, obj_player.y);
	//distância do player 
	var _dist=point_distance(x, y, obj_player.x, obj_player.y);
	
	mp_potential_step_object(obj_player.x,obj_player.y,1,obj_colisor);
	
	if(_dist>20)
	{
		//definindo minha velocidade 
		velh=lengthdir_x(max_velh, _dir)
	}
	else
	{
		velh=0;
		troca_estado(estado_attack);
	}
	
	//definindo o xscale com base no destino x
	var _lado = sign(obj_player.x - x);
	
	if (_lado != 0) 
	{
		xscale = -_lado; 
	}
}
#endregion

#region //esado_hurt
estado_hurt.inicia=function()
{
	//definindo a sprite
	sprite_index=spr_idle_m;
	
	//iniciar animação no começo 
	image_index=0;
	
	
	//perdendo vida
	vida--;
	
	if (vida <= 0)
	{
		troca_estado(estado_death);
	}
}

estado_hurt.roda=function()
{
 
	//saindo do estado hurt
	//checando se a animação acabou 
	if(image_index>=image_number-.5)
	{	
		troca_estado(estado_walk);
	}
	

}
#endregion

#region //esado_death
estado_death.inicia=function()
{
	sprite_index=spr_idle_m; // spr_morreu_m nao existe no projeto; usa sprite existente para evitar crash.
	
	//iniciar animação no começo 
	image_index=0;
}

estado_death.roda=function()
{
	if(image_index>=image_number-.5)
	{
		instance_destroy();
	}
	

}
#endregion 

#region //estado attack
estado_attack.inicia=function()
{
	
	sprite_index=spr_attack_m;
	
	//iniciar animação no começo 
	image_index=0;
	
	dano=noone;
	
}

estado_attack.roda=function()
{
	//Criando o dano 
		
	if(dano == noone)
	{
		
		dano=instance_create_depth(x,y, depth, obj_dano_boss);
		
		dano.image_xscale = xscale;
	}
	
	if (image_index >=image_number-.5)
	{
		troca_estado(estado_espera);
	}
	
}
estado_attack.finaliza=function(){
	if(instance_exists(dano))
	{
	instance_destroy(dano);
	}
	dano=noone;
}

#endregion

#region //Estado espera

estado_espera.inicia=function()
{
	sprite_index=spr_idle_m;
	image_index=0;
	
	timer_estado = irandom_range(90, 180);
}
estado_espera.roda=function()
{
	timer_estado--;
	if(timer_estado<=0)
	{
		troca_estado(estado_walk);
	}
	
}


#endregion


dir=xscale;
