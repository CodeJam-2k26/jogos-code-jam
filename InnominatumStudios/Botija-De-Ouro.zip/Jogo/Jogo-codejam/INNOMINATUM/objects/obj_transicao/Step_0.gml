if (entrando == true) 
{
    // Avança a animação
    img += img_vel;
    
    // Checa se a transição cobriu a tela inteira (passou do total de colunas)
    if (img - img_num > colunas + 1) 
	{
        entrando = false; // Começa a sair (limpar a tela)
        
        // Vai para a próxima room se o destino existir
        if (room_exists(destino)) 
		{
            room_goto(destino);
        }
    }
} 
else 
{
    // Retrocede a animação para limpar a tela
    img -= img_vel;
    
    // Quando a animação zerar (usamos -5 para dar um delayzinho charmoso), o objeto se destrói
    if (img < -5) 
	{ 
        instance_destroy();
    }
}