var _largura_janela = window_get_width();
var _altura_janela = window_get_height();
display_set_gui_size(_largura_janela, _altura_janela);

//O tamanho da sua sprite
tamanho = 64; 


colunas = ceil(display_get_gui_width() / tamanho);
linhas = ceil(display_get_gui_height() / tamanho);

img = 0;
img_vel = sprite_get_speed(spr_quadradinhos) > 0 ? (sprite_get_speed(spr_quadradinhos) / game_get_speed(gamespeed_fps)) : (30 / game_get_speed(gamespeed_fps));
img_num = sprite_get_number(spr_quadradinhos) - 1; 

entrando = true;
destino = noone;