// Rodando por todas as linhas e colunas para desenhar a malha de quadrados
for (var i = 0; i < linhas; i++) 
{
    for (var j = 0; j < colunas; j++) 
	{
        // Limita o frame entre 0 e o frame máximo
        // O "- j" cria o efeito de escada, fazendo as colunas da direita animarem com atraso
        var _img = clamp(img - j, 0, img_num);
        
        // Desenha o quadrado
        // c_black pinta o quadrado de preto, mude para c_white se quiser a cor original da sprite
        draw_sprite_ext(spr_quadradinhos, _img, j * tamanho, i * tamanho, 1, 1, 0, c_black, 1);
    }
}