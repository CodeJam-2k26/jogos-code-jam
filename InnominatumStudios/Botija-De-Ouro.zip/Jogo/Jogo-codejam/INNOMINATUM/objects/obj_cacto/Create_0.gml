//escolhendo sprite 
sprite_index=spr_cacto1_fruta;