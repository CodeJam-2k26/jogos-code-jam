global.game_over = false;
global.sala_salva = room;
