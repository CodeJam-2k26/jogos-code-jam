//verificar a morte do player 
global.game_over=false;

if (!variable_global_exists("sala_salva")) {
    global.sala_salva = room;
}

//para o desenho do retângulo
valor=0;
contador=0;