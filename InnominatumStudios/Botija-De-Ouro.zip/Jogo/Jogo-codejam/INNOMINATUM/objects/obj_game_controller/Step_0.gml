//Definisfo a morte 
var _room_id = asset_get_index(global.room_nome);

if (instance_exists(obj_game_controller)) {
    if (!instance_exists(obj_player)) {
        if (global.game_over == true) {
            if (keyboard_check_pressed(vk_enter)) {
				audio_stop_sound(snd_musica_morte);
                global.reiniciando_morte = true;
                global.vida_atual = global.vida_maxima;
                
                // Vai para a sala atual/salva
                room_goto(global.sala_salva);
                global.game_over = false;
            }
        }
    }
}

/*Caso pressionar enter 
if(keyboard_check(vk_enter))
{
	game_over=true;
}
else
{
	game_over=false;
}


*/