dialogo = [
	{
		nome: "NPC 1",
		foto_dialogo: spr_npc2_dialogo,
		texto_dialogo: "Pois comadre, tu ficaste sabendo daquela tal cidade feita de ouro?",
		direcao: "direita"
	},
	{
		nome: "NPC 2",
		foto_dialogo: spr_player_neutro_dialogo,
		texto_dialogo: "Oxe mulher, é não, é?",
		direcao: "esquerda"
	},
	{
		nome: "NPC 3",
		foto_dialogo: spr_npc2_dialogo,
		texto_dialogo: "Pois é,dizem que a cidade inteira é feita de ouro.",
		direcao: "direita"
	},
];

// Inherit the parent event
event_inherited();

