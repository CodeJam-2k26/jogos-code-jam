if (npc_obrigatorio != noone)
{
    // Verifica se o NPC exigido está na sala
    if (instance_exists(npc_obrigatorio))
    {
        if (npc_obrigatorio.ja_conversou == false)
        {
            _liberado = false; 
        }
		else
		{
			_liberado=true;
		}
    }
}
if (!instance_exists(npc_obrigatorio) || _liberado)
{
    // Salva os dados
    global.sala_salva = destino;
    global.checkpoint_x = posicao_x;
    global.checkpoint_y = posicao_y;

    global.target_x = posicao_x;
    global.target_y = posicao_y;

    // checa a transição
    if (!instance_exists(obj_transicao)) 
    {
        var _trans = instance_create_depth(0, 0, -9999, obj_transicao);
        _trans.destino = destino; 
    }
}
