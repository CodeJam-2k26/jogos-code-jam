depth = -y;	

// Só interage se não houver diálogo aberto e se o NPC ainda não conversou
if (!global.dialogo && !ja_conversou)
{
    if (distance_to_object(obj_player) <= 20) // Ajuste a distância se precisar
    {
        if (keyboard_check_pressed(ord("T")))
        {
            global.dialogo = true; 
            ja_conversou = true; // NPC marca que já falou
            
            // Cria a caixa e inicia
            var _diag = instance_create_depth(0, 0, -9999, obj_dialogo);
            _diag.iniciar_dialogo(dialogo); 
        }
    }
}