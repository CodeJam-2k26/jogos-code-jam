limite_pagina = array_length(dialogo);
ja_conversou = false; 