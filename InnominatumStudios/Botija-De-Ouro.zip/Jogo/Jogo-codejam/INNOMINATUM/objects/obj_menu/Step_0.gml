//Mudando de opção 
//descendo
if (keyboard_check_pressed(vk_down))
{
	atual++;
}

if (keyboard_check_pressed(vk_up)) 
{
	atual--;
}


//limitando a variável atual 
atual =clamp(atual, 0, array_length(menu)-1);

//Ao selecionar clicar enter, executa a função 
if(keyboard_check_pressed(vk_enter))
{
	menu[atual].funcao(); 
}

