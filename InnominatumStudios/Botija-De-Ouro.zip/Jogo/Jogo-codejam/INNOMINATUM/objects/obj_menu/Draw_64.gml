//desenhando os itens do menu

draw_sprite(spr_nome,0,300, y+(margem)+50);
for (var i=0; i<array_length(menu);i++){
	draw_sprite(menu[i].sprite,0,350, y+(margem*i)+450);
	if(i == 0 and atual==0)
	{
		menu[0].sprite=spr_caixa_menu_jogo;
		menu[1].sprite=spr_caixa_sair2;
	}
	else if(i==1 and atual==1)
	{
		menu[0].sprite=spr_botao_jogar;
		menu[1].sprite=spr_botao_sair;
	}
}