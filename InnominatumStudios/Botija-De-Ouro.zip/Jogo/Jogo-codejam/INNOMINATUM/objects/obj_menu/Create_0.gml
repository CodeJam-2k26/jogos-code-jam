// Menu

//A música 
if (!audio_is_playing(snd_musica_menu))
{
    audio_play_sound(snd_musica_menu, 1, true); 
}



// criando as estruturas do menu
opcao1 =
{
	
	sprite: spr_caixa_menu_jogo,
	funcao: function(){
		audio_stop_sound(snd_musica_menu);
			
		if (!instance_exists(obj_transicao)) 
        {
			var _trans = instance_create_depth(0, 0, -9999, obj_transicao);
            
			_trans.destino = rm_tutorial;
		}
	},
}

opcao2 =
{
	sprite: spr_botao_sair,
	funcao: function(){
		audio_stop_sound(snd_musica_menu);
		game_end();
	}
}

menu = [opcao1, opcao2];

// variavel para saber qual indice atual 
atual = 0;

// criando margem
margem = 110;