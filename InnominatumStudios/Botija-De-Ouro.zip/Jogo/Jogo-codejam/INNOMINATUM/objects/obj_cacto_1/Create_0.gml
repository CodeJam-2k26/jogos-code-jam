//escolhendo sprite 
sprite_index=spr_cacto_2;