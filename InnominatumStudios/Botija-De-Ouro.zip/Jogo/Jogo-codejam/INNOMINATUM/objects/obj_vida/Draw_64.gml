switch (global.vida_atual)
{
	case 2: 
		global._sprite_vida=spr_vida_cheia;
	break;
	
	case 1: 
		global._sprite_vida=spr_vida_metade;
	break;
	
	case 0: 
		global._sprite_vida=spr_vida_pouca;
	break;
}

draw_sprite(global._sprite_vida, 0, 20, 10);