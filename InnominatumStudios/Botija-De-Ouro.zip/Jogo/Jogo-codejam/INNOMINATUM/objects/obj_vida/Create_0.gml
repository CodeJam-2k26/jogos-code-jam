// Força a interface a ter sempre o mesmo tamanho
display_set_gui_size(960, 675);

global._sprite_vida= spr_vida_cheia;