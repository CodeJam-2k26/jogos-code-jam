var vida_player=global.vida_atual;

instance_destroy();

if(vida_player>0)
{
with(other)
{
troca_estado(estado_hit);
}
}