// Define as variáveis globais de salvamento
// Começa salvando a sala inicial
global.sala_salva = room; 
global.checkpoint_x = -1;
global.checkpoint_y = -1;
// Exemplo de status do jogador
global.vida_maxima = 3;
global.vida_atual = global.vida_maxima;
