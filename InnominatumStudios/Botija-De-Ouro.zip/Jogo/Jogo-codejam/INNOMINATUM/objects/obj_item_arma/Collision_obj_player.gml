if(instance_exists(obj_player))
{
	instance_destroy();
	global.armado=true;
	global.municao=5;
}