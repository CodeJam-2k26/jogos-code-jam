if (global.vida_atual > 0)
{
    with (other)
    {
        troca_estado(estado_hit);
    }
}


instance_destroy();