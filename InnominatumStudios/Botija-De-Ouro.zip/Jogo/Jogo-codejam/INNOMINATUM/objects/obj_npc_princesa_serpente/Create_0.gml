dialogo = [
	{
		nome: "Princesa",
		foto_dialogo: spr_npc_princesa_dialogo,
		texto_dialogo: "Por favor! Alguém me ajude!",
		direcao: "direita"
	},
	{
		nome: "Princesa Serpente",
		foto_dialogo: spr_npc_princesa_serpente_dialogo,
		texto_dialogo: "A ganância há de ser a ruína dos tolos.",
		direcao: "direita"
	},
	{
		nome: "Cícero",
		foto_dialogo: spr_player_neutro_dialogo,
		texto_dialogo: "Diacho!!!",
		direcao: "esquerda"
	},
	{
		nome: "Cícero",
		foto_dialogo: spr_player_neutro_dialogo,
		texto_dialogo: "Como que eu mato a serpente e liberto a Princesa se esse djabo é uma só?",
		direcao: "esquerda"
	},
	{
		nome: "Princesa Serpente",
		foto_dialogo: spr_npc_princesa_serpente_dialogo,
		texto_dialogo: "Tu não há de sair daqui nunca mais!!",
		direcao: "direita"
	},
];

// Inherit the parent event
event_inherited();
