switch (room)
{
    case Room1: // Tela de Menu
        if (!audio_is_playing(snd_musica_menu))
        {
            audio_stop_all(); // Para qualquer outra música que tenha vazado
            audio_play_sound(snd_musica_menu, 1, true);
        }
        break;

    case rm_jogo: // Tela de Jogo
        if (!audio_is_playing(snd_cenario))
        {
            audio_stop_all(); 
            audio_play_sound(snd_cenario, 1, true);
        }
        break;
}
