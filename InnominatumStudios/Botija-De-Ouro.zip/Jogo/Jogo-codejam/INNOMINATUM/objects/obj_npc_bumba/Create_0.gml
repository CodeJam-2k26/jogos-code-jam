dialogo = [
	{
		nome: "Bumba",
		foto_dialogo: spr_npc_bumba_feliz,
		texto_dialogo: "Olha se não é o tal bichinho arretado, Cícero né?",
		direcao: "direita"
	},
	{
		nome: "Cícero",
		foto_dialogo: spr_player_neutro_dialogo,
		texto_dialogo: "Oxente, por que tu sabe meu nome cabra?",
		direcao: "esquerda"
	},
	{
		nome: "Bumba",
		foto_dialogo: spr_npc_bumba_feliz,
		texto_dialogo: "A pergunta é o que eu não sei, mas deixe de besteira macho, fala o que veio procurar",
		direcao: "direita"
	},
	{
		nome: "Cícero",
		foto_dialogo: spr_player_neutro_dialogo,
		texto_dialogo: "Eu ouvi falar de uma tal cidade feita de ouro.. deve ser uma boa botija.",
		direcao: "esquerda"
	},
	{
		nome: "Bumba",
		foto_dialogo: spr_npc_bumba_feliz,
		texto_dialogo: "É um tesouro cabuloso, mas só se revela aos puros de coração, aqueles que sabem o verdadeiro valor de liberdade..",
		direcao: "direita"
	},
	{
		nome: "Cícero",
		foto_dialogo: spr_player_neutro_dialogo,
		texto_dialogo: "Pois deixe de buliça e diga logo como eu chego nessa cidade aí.",
		direcao: "esquerda"
	},
	{
		nome: "Bumba",
		foto_dialogo: spr_npc_bumba_feliz,
		texto_dialogo: "Oxe nego, deixe de ser avexado e escute o que eu vou te dizer, essa cidade aí que tu procura é muito antiga, guardada por uma serpente muito perigosa..",
		direcao: "direita"
	},
	{
		nome: "Bumba",
		foto_dialogo: spr_npc_bumba_feliz,
		texto_dialogo: "Para conseguir encontrar a cidade de ouro precisa libertar a princesa destruindo essa cobra aí, mas é aperreio de se fazer isso, você vai precisar de uma coisa que eu não posso te dar..",
		direcao: "direita"
	},
	{
		nome: "Cícero",
		foto_dialogo: spr_player_neutro_dialogo,
		texto_dialogo: "Então desembuche e me diga que que é essa tal coisa",
		direcao: "esquerda"
	},
	{
		nome: "Bumba",
		foto_dialogo: spr_npc_bumba_feliz,
		texto_dialogo: "Um bracelete...",
		direcao: "direita"
	},
	{
		nome: "Cícero",
		foto_dialogo: spr_player_neutro_dialogo,
		texto_dialogo: "Bracelete? Ora, macho, bracelete tem em todo canto",
		direcao: "esquerda"
	},
	{
		nome: "Bumba",
		foto_dialogo: spr_npc_bumba_feliz,
		texto_dialogo: "Não qualquer bracelete cabra lesado, um bracelete encantado, que só a bela dama pode te oferecer",
		direcao: "direita"
	},
	{
		nome: "Cícero",
		foto_dialogo: spr_player_neutro_dialogo,
		texto_dialogo: "E quem que é essa tal de bela dama aí?",
		direcao: "esquerda"
	},
	{
		nome: "Bumba",
		foto_dialogo: spr_npc_bumba_feliz,
		texto_dialogo: "Uma linda mulher que vive no pico de um moro, porém cê tem que ficar de butuca, por que essa mulher tem uma beleza mortal em todos os sentidos.",
		direcao: "direita"
	},
]

// Inherit the parent event
event_inherited();
