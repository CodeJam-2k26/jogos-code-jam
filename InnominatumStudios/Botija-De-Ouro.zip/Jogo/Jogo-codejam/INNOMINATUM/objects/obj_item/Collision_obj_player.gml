if(instance_exists(obj_player))
{
	instance_destroy();
	global.vida_atual++;

}