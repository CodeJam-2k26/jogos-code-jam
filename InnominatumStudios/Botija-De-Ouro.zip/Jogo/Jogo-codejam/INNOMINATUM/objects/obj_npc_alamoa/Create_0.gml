dialogo = [
    {
        nome: "Alamoa",
        foto_dialogo: spr_npc_alamoa_neutro_dialogo,
        texto_dialogo: "Ora ora, eu sabia que você viria.",
        direcao: "direita"
    },
    {
        nome: "Cícero",
        foto_dialogo: spr_player_neutro_dialogo,
        texto_dialogo: "Vixe Maria, e como que tu sabia?",
        direcao: "esquerda"
    },
    {
        nome: "Alamoa",
        foto_dialogo: spr_npc_alamoa_feliz_dialogo,
        texto_dialogo: "Segredo. Mas então, me diga, você me acha bonita?",
        direcao: "direita",
        // ARRAY DE OPÇÕES ANINHADO NA FALA
	
        opcoes: [
            {
                texto: "Sim, você é uma belezura que só",
                funcao: function(){
                    global.vida_atual = 0;
                    global.dialogo = false; // Destranca o jogador para que ele possa morrer
                    obj_player.matar_player(); // Chama a função blindada contra escopo
                    instance_destroy(obj_dialogo);
                }
            },
            {
                texto: "Não, você é a bichinha mais judiada que eu já vi",
                funcao: function(){
                    global.vida_atual = 0;
                    global.dialogo = false; 
                    obj_player.matar_player();
                    instance_destroy(obj_dialogo);
                }
            },
            {
                texto: "A beleza não está nos olhos, e sim no coração daqueles que se dispõe a buscá-la",
                funcao: function(){
                    obj_dialogo.proxima_pagina(); // Continua o diálogo vivo
                }
            }
        ]
    },
    {
        nome: "Alamoa",
        foto_dialogo: spr_npc_alamoa_feliz_dialogo,
        texto_dialogo: "Você é puro de coração. Diga-me do que precisas, e eu ajudarei.",
        direcao: "direita"
    },
	{
		nome: "Cícero",
		foto_dialogo: spr_player_feliz_dialogo,
		texto_dialogo: "Vim atrás de um objeto, a mando daquele boi lá da festa.",
		direcao: "esquerda"
	},
	{
		nome: "Cícero",
		foto_dialogo: spr_player_feliz_dialogo,
		texto_dialogo: "O bichinho disse que esse objeto poderia destruir aquela cobrona lá.",
		direcao: "esquerda"
	},
	{
		nome: "Alamoa",
		foto_dialogo: spr_npc_alamoa_feliz_dialogo,
		texto_dialogo: "Ah, você deve estar se referindo ao bracelete.",
		direcao: "direita"
	},
	{
		nome: "Cícero",
		foto_dialogo: spr_player_feliz_dialogo,
		texto_dialogo: "Deve ser esse treco aí mesmo.",
		direcao: "esquerda"
	},
	{
		nome: "Alamoa",
		foto_dialogo: spr_npc_alamoa_feliz_dialogo,
		texto_dialogo: "Antes de entregar, você irá passar por uma provação.",
		direcao: "direita"
	},
	{
		nome: "Alamoa",
		foto_dialogo: spr_npc_alamoa_caveira_dialogo,
		texto_dialogo: "...",
		direcao: "direita"
	},
	{
		nome: "Cícero",
		foto_dialogo: spr_player_neutro_dialogo,
		texto_dialogo: "...",
		direcao: "esquerda"
	},
	{
		nome: "Cícero",
		foto_dialogo: spr_player_feliz_dialogo,
		texto_dialogo: "Bichinha, mas tu tá judiada, visse?",
		direcao: "esquerda"
	},
	{
		nome: "Alamoa",
		foto_dialogo: spr_npc_alamoa_caveira_dialogo,
		texto_dialogo: "Pegue logo esse bracelete e se vá daqui, antes que eu reconsidere.",
		direcao: "direita"
	},
	
];

event_inherited();

