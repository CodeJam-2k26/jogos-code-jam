global.levelData=
{
	level_1:0,
	level_2:0,
	level_3:0,
	level_4:0,
	level_5:0,
	level_6:0,
}

global.room_nome=room_get_name(room);