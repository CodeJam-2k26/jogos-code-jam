//carregar o último estado da sala 
load_room(); 

if (instance_exists(obj_player))
{
    if (variable_global_exists("target_x") && variable_global_exists("target_y"))
    {
        if (global.target_x != noone && global.target_y != noone)
        {
            if (global.target_x != 0 && global.target_y != 0)
            {
                // Move o player
                obj_player.x = global.target_x;
                obj_player.y = global.target_y;
            }
            
            // Limpa as variáveis para não bugar no futuro
            global.target_x = noone;
            global.target_y = noone;
        }
    }
}